#!/usr/bin/env bash
set -euo pipefail

# Files are already placed by unzip. This script only updates aggregate build files
# and records checksums for the newly added R2072D/R2073D layers.
# It is intentionally idempotent and does not self-copy directories.

python3 - <<'PYAPPLY'
from pathlib import Path
import re

R2071 = 'R2071DLeanEndpointFirstConcreteObligationEndpointTheoremProofBoundary'
R2072 = 'R2072DLeanEndpointFirstConcreteObligationEndpointProofTermCandidate'
R2073 = 'R2073DLeanEndpointFirstConcreteObligationEndpointProofTermCheckGate'

lake = Path('lakefile.lean')
text = lake.read_text()
text = re.sub(r'package «[^»]+» where', f'package «{R2073}» where', text, count=1)

for m in (R2072, R2073):
    text = re.sub(rf'\n?@\[default_target\]\nlean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m}\n?', '\n', text)

lines = [line for line in text.splitlines() if line.strip() != '@[default_target]']
text = '\n'.join(lines).rstrip() + '\n'

if f'lean_lib {R2071} where' not in text:
    text += f"\nlean_lib {R2071} where\n  roots := #[`{R2071}]\n"

text += f"\nlean_lib {R2072} where\n  roots := #[`{R2072}]\n\n@[default_target]\nlean_lib {R2073} where\n  roots := #[`{R2073}]\n"
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2072 in line or R2073 in line:
        continue
    mlines.append(line)
mt = '\n'.join(mlines).rstrip()
block = f"""
import {R2072}
import {R2073}
#check {R2072}.endpoint_first_concrete_obligation_endpoint_proof_term_candidate_to_actual_li_target
#check {R2072}.endpoint_first_concrete_obligation_endpoint_proof_term_candidate_statement
#check {R2072}.endpoint_first_concrete_obligation_endpoint_proof_term_candidate_term
#check {R2072}.endpoint_first_concrete_obligation_endpoint_proof_term_candidate_ready_for_check_gate
#check {R2072}.endpoint_first_concrete_obligation_endpoint_proof_term_candidate_keeps_endpoint_theorem_unclaimed
#check {R2073}.endpoint_first_concrete_obligation_endpoint_proof_term_check_gate_to_actual_li_target
#check {R2073}.endpoint_first_concrete_obligation_endpoint_proof_term_check_gate_statement
#check {R2073}.endpoint_first_concrete_obligation_endpoint_proof_term_check_gate_checked_candidate
#check {R2073}.endpoint_first_concrete_obligation_endpoint_proof_term_check_gate_executed
#check {R2073}.endpoint_first_concrete_obligation_endpoint_proof_term_check_gate_keeps_candidate_uncertified
"""
main.write_text(mt + block)
PYAPPLY

sha256sum \
  R2072DLeanEndpointFirstConcreteObligationEndpointProofTermCandidate.lean \
  R2072DLeanEndpointFirstConcreteObligationEndpointProofTermCandidate/*.lean \
  R2073DLeanEndpointFirstConcreteObligationEndpointProofTermCheckGate.lean \
  R2073DLeanEndpointFirstConcreteObligationEndpointProofTermCheckGate/*.lean \
  R2072D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_PROOF_TERM_CANDIDATE_LEDGER.md \
  R2073D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_PROOF_TERM_CHECK_GATE_LEDGER.md \
  R2072D_ONE_HUNDRED_ELEVENTH_BEST_STEP.md \
  R2073D_ONE_HUNDRED_TWELFTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2072D_R2073D.md \
  VERIFY_STATUS_R2072D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_PROOF_TERM_CANDIDATE.md \
  VERIFY_STATUS_R2073D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_PROOF_TERM_CHECK_GATE.md \
  > SHA256SUMS_R2073D_COMBINED_ENDPOINT_PROOF_TERM_CANDIDATE_CHECK_GATE.txt

bash -n APPLY_R2073D_COMBINED_ENDPOINT_PROOF_TERM_CANDIDATE_CHECK_GATE_PATCH.sh
