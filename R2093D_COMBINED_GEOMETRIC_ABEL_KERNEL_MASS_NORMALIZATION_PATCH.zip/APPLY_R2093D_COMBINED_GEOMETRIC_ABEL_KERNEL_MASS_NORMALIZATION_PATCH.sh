#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f lake-manifest.json
test -f R2091DLeanConcreteRealAbelBoundary.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
grep -q 'require mathlib from git' lakefile.lean
grep -q '"inputRev": "v4.31.0"' lake-manifest.json

sha256sum -c SHA256SUMS_R2093D_COMBINED_GEOMETRIC_ABEL_KERNEL_MASS_NORMALIZATION.txt

grep -q 'R2091DLeanConcreteRealAbelBoundary' lakefile.lean
grep -q 'import R2091DLeanConcreteRealAbelBoundary' Main.lean

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2093DLeanGeometricAbelKernelInfiniteNormalization» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2092DLeanGeometricAbelKernelMassLimit where"
block = """

@[default_target]
lean_lib R2092DLeanGeometricAbelKernelMassLimit where
  roots := #[`R2092DLeanGeometricAbelKernelMassLimit]

@[default_target]
lean_lib R2093DLeanGeometricAbelKernelInfiniteNormalization where
  roots := #[`R2093DLeanGeometricAbelKernelInfiniteNormalization]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2092DLeanGeometricAbelKernelMassLimit"
block = """

import R2092DLeanGeometricAbelKernelMassLimit
import R2093DLeanGeometricAbelKernelInfiniteNormalization
#check R2092DLeanGeometricAbelKernelMassLimit.geometric_abel_kernel_nonneg
#check R2092DLeanGeometricAbelKernelMassLimit.finite_geometric_abel_kernel_mass_nonneg
#check R2092DLeanGeometricAbelKernelMassLimit.finite_geometric_abel_kernel_mass_le_one
#check R2092DLeanGeometricAbelKernelMassLimit.finite_geometric_abel_kernel_mass_tendsto_one
#check R2092DLeanGeometricAbelKernelMassLimit.GeometricAbelKernelMassLimitWitness
#check R2092DLeanGeometricAbelKernelMassLimit.geometricAbelKernelMassLimitWitness
#check R2093DLeanGeometricAbelKernelInfiniteNormalization.geometric_abel_kernel_hasSum_one
#check R2093DLeanGeometricAbelKernelInfiniteNormalization.geometric_abel_kernel_summable
#check R2093DLeanGeometricAbelKernelInfiniteNormalization.geometric_abel_kernel_tsum_eq_one
#check R2093DLeanGeometricAbelKernelInfiniteNormalization.GeometricAbelKernelInfiniteNormalizationWitness
#check R2093DLeanGeometricAbelKernelInfiniteNormalization.geometricAbelKernelInfiniteNormalizationWitness
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2092D/R2093D geometric Abel-kernel mass and infinite normalization patch."
