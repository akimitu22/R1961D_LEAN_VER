#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization.lean

sha256sum -c SHA256SUMS_R2085D_COMBINED_DEPENDENCY_CLOSURE_CLOSED_TARGET.txt

grep -q 'R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization' lakefile.lean
grep -q 'import R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization' Main.lean

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness where"
block = """

@[default_target]
lean_lib R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness where
  roots := #[`R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness]

@[default_target]
lean_lib R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction where
  roots := #[`R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness"
block = """

import R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness
import R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction
#check R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness.EndpointDependencyClosureWitness
#check R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness.EndpointDependencyClosureExists
#check R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness.endpoint_first_concrete_obligation_endpoint_dependency_closure_witness_to_finalization_evidence
#check R2084DLeanEndpointFirstConcreteObligationEndpointDependencyClosureWitness.endpoint_first_concrete_obligation_endpoint_dependency_closure_witness_preserves_certificate_statement
#check R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction.EndpointClosedTargetStatement
#check R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction.endpoint_first_concrete_obligation_endpoint_closed_target_from_witness
#check R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction.endpoint_first_concrete_obligation_endpoint_closed_target_extraction
#check R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction.endpoint_first_concrete_obligation_endpoint_closed_target_preserves_certificate_statement
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2084D/R2085D dependency closure witness and closed target extraction patch."
