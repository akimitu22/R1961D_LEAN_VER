#!/usr/bin/env bash
set -euo pipefail

# Files are already placed by unzip. This script only updates aggregate build files
# and records checksums for the newly added R2070D/R2071D layers.
# It is intentionally idempotent and does not self-copy directories.

python3 - <<'PYAPPLY'
from pathlib import Path
import re

R2069 = "R2069DLeanEndpointFirstConcreteObligationFinalTheoremHandoff"
R2070 = "R2070DLeanEndpointFirstConcreteObligationEndpointTheoremStatementAssembly"
R2071 = "R2071DLeanEndpointFirstConcreteObligationEndpointTheoremProofBoundary"
NEW = {R2070, R2071}

lake = Path("lakefile.lean")
text = lake.read_text()
text = re.sub(r"package «[^»]+» where", f"package «{R2071}» where", text, count=1)

lines = text.splitlines()
out = []
i = 0
while i < len(lines):
    line = lines[i]
    stripped = line.strip()
    if stripped == "@[default_target]":
        i += 1
        continue
    matched = None
    for m in NEW:
        if stripped == f"lean_lib {m}" or stripped == f"lean_lib {m} where":
            matched = m
            break
    if matched is not None:
        i += 1
        if i < len(lines) and "roots :=" in lines[i] and matched in lines[i]:
            i += 1
        continue
    out.append(line)
    i += 1
text = "\n".join(out).rstrip() + "\n"

if f"lean_lib {R2069} where" not in text:
    text += f"\nlean_lib {R2069} where\n  roots := #[`{R2069}]\n"

text += f"\nlean_lib {R2070} where\n  roots := #[`{R2070}]\n\n@[default_target]\nlean_lib {R2071} where\n  roots := #[`{R2071}]\n"
lake.write_text(text)

main = Path("Main.lean")
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2070 in line or R2071 in line:
        continue
    mlines.append(line)
mt = "\n".join(mlines).rstrip()
block = f"""
import {R2070}
import {R2071}
#check {R2070}.endpoint_first_concrete_obligation_endpoint_theorem_statement_assembly_to_actual_li_target
#check {R2070}.endpoint_first_concrete_obligation_endpoint_theorem_statement_assembly_statement
#check {R2070}.endpoint_first_concrete_obligation_endpoint_theorem_statement_assembly_prepares_proof_boundary
#check {R2070}.endpoint_first_concrete_obligation_endpoint_theorem_statement_assembly_keeps_endpoint_theorem_unclaimed
#check {R2071}.endpoint_first_concrete_obligation_endpoint_theorem_proof_boundary_to_actual_li_target
#check {R2071}.endpoint_first_concrete_obligation_endpoint_theorem_proof_boundary_statement
#check {R2071}.endpoint_first_concrete_obligation_endpoint_theorem_proof_boundary_required_proof_term_type
#check {R2071}.endpoint_first_concrete_obligation_endpoint_theorem_proof_boundary_keeps_endpoint_theorem_unclaimed
"""
main.write_text(mt + block)
PYAPPLY

sha256sum \
  R2070DLeanEndpointFirstConcreteObligationEndpointTheoremStatementAssembly.lean \
  R2070DLeanEndpointFirstConcreteObligationEndpointTheoremStatementAssembly/*.lean \
  R2071DLeanEndpointFirstConcreteObligationEndpointTheoremProofBoundary.lean \
  R2071DLeanEndpointFirstConcreteObligationEndpointTheoremProofBoundary/*.lean \
  R2070D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_STATEMENT_ASSEMBLY_LEDGER.md \
  R2071D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_PROOF_BOUNDARY_LEDGER.md \
  R2070D_ONE_HUNDRED_NINTH_BEST_STEP.md \
  R2071D_ONE_HUNDRED_TENTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2070D_R2071D.md \
  VERIFY_STATUS_R2070D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_STATEMENT_ASSEMBLY.md \
  VERIFY_STATUS_R2071D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_PROOF_BOUNDARY.md \
  > SHA256SUMS_R2071D_COMBINED_ENDPOINT_THEOREM_STATEMENT_ASSEMBLY_PROOF_BOUNDARY.txt

bash -n APPLY_R2071D_COMBINED_ENDPOINT_THEOREM_STATEMENT_ASSEMBLY_PROOF_BOUNDARY_PATCH.sh
