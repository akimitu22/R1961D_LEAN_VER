import R2047DLeanEndpointFirstConcreteObligationLemmaStatementBank.EndpointFirstConcreteObligationLemmaStatementBankDependencyAudit

namespace R2047DLeanEndpointFirstConcreteObligationLemmaStatementBank

open R2046DLeanEndpointFirstConcreteObligationDecompositionSlots
open R2045DLeanEndpointFirstConcreteProofObligationBoundary
open R2044DLeanEndpointProofObligationExecutionQueue
open R2043DLeanEndpointFinalVerificationBoundary
open R2042DLeanEndpointFinalSubmissionCertificateSlots
open R2041DLeanEndpointFinalSubmissionBoundary
open R2040DLeanEndpointFinalArchiveExportCertificateSlots
open R2039DLeanEndpointFinalArchiveExportBoundary
open R2038DLeanEndpointFinalPackageClosureCertificateSlots
open R2037DLeanEndpointFinalPackageClosureBoundary
open R2036DLeanEndpointFinalRHClaimCertificateSlots
open R2035DLeanEndpointFinalRHClaimBoundary
open R2034DLeanEndpointFinalTheoremHandoffCertificateSlots
open R2033DLeanEndpointFinalTheoremHandoffBoundary
open R2032DLeanEndpointFirstRHTargetIntegrationCertificateSlots
open R2031DLeanEndpointFirstRHTargetIntegrationBoundary
open R2030DLeanEndpointFirstExplicitFormulaHandoffCertificateSlots
open R2029DLeanEndpointFirstExplicitFormulaHandoffBoundary
open R2028DLeanEndpointFirstEstimateHandoffCertificateSlots
open R2027DLeanEndpointFirstEstimateHandoffBoundary
open R2026DLeanEndpointFirstConcreteLemmaDischargeCertificateSlots
open R2025DLeanEndpointFirstConcreteLemmaDischargeBoundary
open R2024DLeanEndpointFirstProofKernelExecutionCertificateSlots
open R2023DLeanEndpointFirstProofKernelExecutionBoundary
open R2022DLeanEndpointFirstProofKernelInvocationCertificateSlots
open R1962DLeanAnalyticRealization

/-- Bridge from R2047D lemma-statement bank to dependency audit. -/
def endpoint_first_concrete_obligation_lemma_statement_bank_to_dependency_audit

    {A : AnalyticRealizationObligations}
    {S : MainAnchoredEndpointFirstProofKernelInvocationCertificateSlots A}
    {B : MainAnchoredEndpointFirstProofKernelExecutionBoundary S}
    {C : MainAnchoredEndpointFirstProofKernelExecutionCertificateSlots B}
    {D : MainAnchoredEndpointFirstConcreteLemmaDischargeBoundary C}
    {E : MainAnchoredEndpointFirstConcreteLemmaDischargeCertificateSlots D}
    {F : MainAnchoredEndpointFirstEstimateHandoffBoundary E}
    {G : MainAnchoredEndpointFirstEstimateHandoffCertificateSlots F}
    {H : MainAnchoredEndpointFirstExplicitFormulaHandoffBoundary G}
    {I : MainAnchoredEndpointFirstExplicitFormulaHandoffCertificateSlots H}
    {J : MainAnchoredEndpointFirstRHTargetIntegrationBoundary I}
    {K : MainAnchoredEndpointFirstRHTargetIntegrationCertificateSlots J}
    {L : MainAnchoredEndpointFinalTheoremHandoffBoundary K}
    {M : MainAnchoredEndpointFinalTheoremHandoffCertificateSlots L}
    {N : MainAnchoredEndpointFinalRHClaimBoundary M}
    {O : MainAnchoredEndpointFinalRHClaimCertificateSlots N}
    {P : MainAnchoredEndpointFinalPackageClosureBoundary O}
    {Q : MainAnchoredEndpointFinalPackageClosureCertificateSlots P}
    {R : MainAnchoredEndpointFinalArchiveExportBoundary Q}
    {U : MainAnchoredEndpointFinalArchiveExportCertificateSlots R}
    {V : MainAnchoredEndpointFinalSubmissionBoundary U}
    {W : MainAnchoredEndpointFinalSubmissionCertificateSlots V}
    {X : MainAnchoredEndpointFinalVerificationBoundary W}
    {Y : MainAnchoredEndpointProofObligationExecutionQueue X}
    {Z : MainAnchoredEndpointFirstConcreteProofObligationBoundary Y)}
    {AA : MainAnchoredEndpointFirstConcreteObligationDecompositionSlots Z}
    (AB : MainAnchoredEndpointFirstConcreteObligationLemmaStatementBank AA) :
    EndpointFirstConcreteObligationLemmaStatementBankDependencyAudit AB :=
  { auditItemCount := AB.lemmaStatementBankStageCount
    attachedToDecompositionSlots := AB.allLemmaStatementsStillOpen
    recordsEndpointEstimateConcreteLemma := AB.recordsEndpointEstimateConcreteLemma
    recordsExplicitFormulaBridgeLemma := AB.recordsExplicitFormulaBridgeLemma
    recordsTransferAssemblyLemma := AB.recordsTransferAssemblyLemma
    recordsFiniteAbelReductionLemma := AB.recordsFiniteAbelReductionLemma
    recordsProofKernelConnectionLemma := AB.recordsProofKernelConnectionLemma
    recordsAllStatementsStillOpen := AB.allLemmaStatementsStillOpen
    actualLiTarget := AB.actualLiTarget }

/-- The R2047D bridge preserves the analytic target. -/
theorem endpoint_first_concrete_obligation_lemma_statement_bank_bridge_to_actual_li_target

    {A : AnalyticRealizationObligations}
    {S : MainAnchoredEndpointFirstProofKernelInvocationCertificateSlots A}
    {B : MainAnchoredEndpointFirstProofKernelExecutionBoundary S}
    {C : MainAnchoredEndpointFirstProofKernelExecutionCertificateSlots B}
    {D : MainAnchoredEndpointFirstConcreteLemmaDischargeBoundary C}
    {E : MainAnchoredEndpointFirstConcreteLemmaDischargeCertificateSlots D}
    {F : MainAnchoredEndpointFirstEstimateHandoffBoundary E}
    {G : MainAnchoredEndpointFirstEstimateHandoffCertificateSlots F}
    {H : MainAnchoredEndpointFirstExplicitFormulaHandoffBoundary G}
    {I : MainAnchoredEndpointFirstExplicitFormulaHandoffCertificateSlots H}
    {J : MainAnchoredEndpointFirstRHTargetIntegrationBoundary I}
    {K : MainAnchoredEndpointFirstRHTargetIntegrationCertificateSlots J}
    {L : MainAnchoredEndpointFinalTheoremHandoffBoundary K}
    {M : MainAnchoredEndpointFinalTheoremHandoffCertificateSlots L}
    {N : MainAnchoredEndpointFinalRHClaimBoundary M}
    {O : MainAnchoredEndpointFinalRHClaimCertificateSlots N}
    {P : MainAnchoredEndpointFinalPackageClosureBoundary O}
    {Q : MainAnchoredEndpointFinalPackageClosureCertificateSlots P}
    {R : MainAnchoredEndpointFinalArchiveExportBoundary Q}
    {U : MainAnchoredEndpointFinalArchiveExportCertificateSlots R}
    {V : MainAnchoredEndpointFinalSubmissionBoundary U}
    {W : MainAnchoredEndpointFinalSubmissionCertificateSlots V}
    {X : MainAnchoredEndpointFinalVerificationBoundary W}
    {Y : MainAnchoredEndpointProofObligationExecutionQueue X}
    {Z : MainAnchoredEndpointFirstConcreteProofObligationBoundary Y)}
    (AA : MainAnchoredEndpointFirstConcreteObligationDecompositionSlots Z)
    (AB : MainAnchoredEndpointFirstConcreteObligationLemmaStatementBank AA) : A.actualLiTarget :=
  (endpoint_first_concrete_obligation_lemma_statement_bank_to_dependency_audit AB).actualLiTarget

end R2047DLeanEndpointFirstConcreteObligationLemmaStatementBank
