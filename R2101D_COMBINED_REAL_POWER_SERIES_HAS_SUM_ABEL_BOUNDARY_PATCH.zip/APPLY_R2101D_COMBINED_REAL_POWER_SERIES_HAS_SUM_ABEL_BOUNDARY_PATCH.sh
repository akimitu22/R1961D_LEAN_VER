#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f lake-manifest.json
test -f R2099DLeanBoundFreeRealAbelLimit.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
grep -q 'require mathlib from git' lakefile.lean
grep -q 'R2099DLeanBoundFreeRealAbelLimit' lakefile.lean
grep -q 'import R2099DLeanBoundFreeRealAbelLimit' Main.lean

sha256sum -c SHA256SUMS_R2101D_COMBINED_REAL_POWER_SERIES_HAS_SUM_ABEL_BOUNDARY.txt

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2101DLeanHasSumAbelBoundary» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2100DLeanRealPowerSeriesAbelBoundary where"
block = """

@[default_target]
lean_lib R2100DLeanRealPowerSeriesAbelBoundary where
  roots := #[`R2100DLeanRealPowerSeriesAbelBoundary]

@[default_target]
lean_lib R2101DLeanHasSumAbelBoundary where
  roots := #[`R2101DLeanHasSumAbelBoundary]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2100DLeanRealPowerSeriesAbelBoundary"
block = """

import R2100DLeanRealPowerSeriesAbelBoundary
import R2101DLeanHasSumAbelBoundary
#check R2100DLeanRealPowerSeriesAbelBoundary.real_power_series_tendsto_of_partial_sums
#check R2100DLeanRealPowerSeriesAbelBoundary.RealPowerSeriesAbelBoundaryWitness
#check R2100DLeanRealPowerSeriesAbelBoundary.realPowerSeriesAbelBoundaryWitness
#check R2101DLeanHasSumAbelBoundary.weighted_power_series_hasSum_of_hasSum
#check R2101DLeanHasSumAbelBoundary.real_power_series_tendsto_of_hasSum
#check R2101DLeanHasSumAbelBoundary.real_power_series_tendsto_tsum_of_summable
#check R2101DLeanHasSumAbelBoundary.HasSumAbelBoundaryWitness
#check R2101DLeanHasSumAbelBoundary.hasSumAbelBoundaryWitness
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2100D/R2101D real power-series and HasSum Abel-boundary patch."
