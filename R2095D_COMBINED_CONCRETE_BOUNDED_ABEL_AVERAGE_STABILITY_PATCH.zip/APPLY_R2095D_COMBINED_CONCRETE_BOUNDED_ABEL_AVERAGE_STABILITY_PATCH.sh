#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f lake-manifest.json
test -f R2093DLeanGeometricAbelKernelInfiniteNormalization.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
grep -q 'require mathlib from git' lakefile.lean
grep -q 'R2093DLeanGeometricAbelKernelInfiniteNormalization' lakefile.lean
grep -q 'import R2093DLeanGeometricAbelKernelInfiniteNormalization' Main.lean

sha256sum -c SHA256SUMS_R2095D_COMBINED_CONCRETE_BOUNDED_ABEL_AVERAGE_STABILITY.txt

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2095DLeanConcreteAbelAverageStability» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2094DLeanConcreteBoundedAbelAverage where"
block = """

@[default_target]
lean_lib R2094DLeanConcreteBoundedAbelAverage where
  roots := #[`R2094DLeanConcreteBoundedAbelAverage]

@[default_target]
lean_lib R2095DLeanConcreteAbelAverageStability where
  roots := #[`R2095DLeanConcreteAbelAverageStability]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2094DLeanConcreteBoundedAbelAverage"
block = """

import R2094DLeanConcreteBoundedAbelAverage
import R2095DLeanConcreteAbelAverageStability
#check R2094DLeanConcreteBoundedAbelAverage.scaledAbelKernel
#check R2094DLeanConcreteBoundedAbelAverage.abelWeightedTerm
#check R2094DLeanConcreteBoundedAbelAverage.realAbelAverage
#check R2094DLeanConcreteBoundedAbelAverage.scaled_abel_kernel_hasSum
#check R2094DLeanConcreteBoundedAbelAverage.abel_weighted_terms_summable
#check R2094DLeanConcreteBoundedAbelAverage.norm_realAbelAverage_le
#check R2094DLeanConcreteBoundedAbelAverage.abs_realAbelAverage_le
#check R2094DLeanConcreteBoundedAbelAverage.ConcreteBoundedAbelAverageWitness
#check R2094DLeanConcreteBoundedAbelAverage.concreteBoundedAbelAverageWitness
#check R2095DLeanConcreteAbelAverageStability.realAbelAverageDifference
#check R2095DLeanConcreteAbelAverageStability.realAbelAverage_sub_of_summable
#check R2095DLeanConcreteAbelAverageStability.realAbelAverageDifference_eq_sub
#check R2095DLeanConcreteAbelAverageStability.norm_realAbelAverageDifference_le
#check R2095DLeanConcreteAbelAverageStability.norm_realAbelAverage_sub_le
#check R2095DLeanConcreteAbelAverageStability.abs_realAbelAverage_sub_le
#check R2095DLeanConcreteAbelAverageStability.ConcreteAbelAverageStabilityWitness
#check R2095DLeanConcreteAbelAverageStability.concreteAbelAverageStabilityWitness
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2094D/R2095D concrete bounded Abel-average and stability patch."
