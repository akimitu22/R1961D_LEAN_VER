#!/usr/bin/env bash
set -euo pipefail

# Files are already placed by unzip. This script only updates aggregate build files
# and records checksums for the newly added R2068D/R2069D layers.
# It is intentionally idempotent and does not self-copy directories.

python3 - <<'PYAPPLY'
from pathlib import Path
import re

R2067 = 'R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport'
R2068 = 'R2068DLeanEndpointFirstConcreteObligationEndpointBranchIntegration'
R2069 = 'R2069DLeanEndpointFirstConcreteObligationFinalTheoremHandoff'

lake = Path('lakefile.lean')
text = lake.read_text()
text = re.sub(r'package «[^»]+» where', f'package «{R2069}» where', text, count=1)

for m in (R2068, R2069):
    text = re.sub(rf'\n?@\[default_target\]\nlean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m}\n?', '\n', text)

lines = [line for line in text.splitlines() if line.strip() != '@[default_target]']
text = '\n'.join(lines).rstrip() + '\n'

if f'lean_lib {R2067} where' not in text:
    text += f"\nlean_lib {R2067} where\n  roots := #[`{R2067}]\n"

text += f"\nlean_lib {R2068} where\n  roots := #[`{R2068}]\n\n@[default_target]\nlean_lib {R2069} where\n  roots := #[`{R2069}]\n"
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2068 in line or R2069 in line:
        continue
    mlines.append(line)
mt = '\n'.join(mlines).rstrip()
block = f"""
import {R2068}
import {R2069}
#check {R2068}.endpoint_first_concrete_obligation_endpoint_branch_integration_to_actual_li_target
#check {R2068}.endpoint_first_concrete_obligation_endpoint_branch_integration_statement
#check {R2068}.endpoint_first_concrete_obligation_endpoint_branch_integration_ready_for_final_theorem_handoff
#check {R2069}.endpoint_first_concrete_obligation_final_theorem_handoff_to_actual_li_target
#check {R2069}.endpoint_first_concrete_obligation_final_theorem_handoff_statement
#check {R2069}.endpoint_first_concrete_obligation_final_theorem_handoff_keeps_endpoint_theorem_unclaimed
"""
main.write_text(mt + block)
PYAPPLY

sha256sum \
  R2068DLeanEndpointFirstConcreteObligationEndpointBranchIntegration.lean \
  R2068DLeanEndpointFirstConcreteObligationEndpointBranchIntegration/*.lean \
  R2069DLeanEndpointFirstConcreteObligationFinalTheoremHandoff.lean \
  R2069DLeanEndpointFirstConcreteObligationFinalTheoremHandoff/*.lean \
  R2068D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_BRANCH_INTEGRATION_LEDGER.md \
  R2069D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_FINAL_THEOREM_HANDOFF_LEDGER.md \
  R2068D_ONE_HUNDRED_SEVENTH_BEST_STEP.md \
  R2069D_ONE_HUNDRED_EIGHTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2068D_R2069D.md \
  VERIFY_STATUS_R2068D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_BRANCH_INTEGRATION.md \
  VERIFY_STATUS_R2069D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_FINAL_THEOREM_HANDOFF.md \
  > SHA256SUMS_R2069D_COMBINED_ENDPOINT_BRANCH_INTEGRATION_FINAL_THEOREM_HANDOFF.txt

bash -n APPLY_R2069D_COMBINED_ENDPOINT_BRANCH_INTEGRATION_FINAL_THEOREM_HANDOFF_PATCH.sh
