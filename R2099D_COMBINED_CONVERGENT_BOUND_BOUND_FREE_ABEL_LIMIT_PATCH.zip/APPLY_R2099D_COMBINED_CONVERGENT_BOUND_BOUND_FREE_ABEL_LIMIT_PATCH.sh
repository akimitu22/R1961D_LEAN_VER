#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f lake-manifest.json
test -f R2097DLeanConcreteRealAbelLimitTheorem.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
grep -q 'require mathlib from git' lakefile.lean
grep -q 'R2097DLeanConcreteRealAbelLimitTheorem' lakefile.lean
grep -q 'import R2097DLeanConcreteRealAbelLimitTheorem' Main.lean

sha256sum -c SHA256SUMS_R2099D_COMBINED_CONVERGENT_BOUND_BOUND_FREE_ABEL_LIMIT.txt

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2099DLeanBoundFreeRealAbelLimit» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2098DLeanConvergentPartialSumBound where"
block = """

@[default_target]
lean_lib R2098DLeanConvergentPartialSumBound where
  roots := #[`R2098DLeanConvergentPartialSumBound]

@[default_target]
lean_lib R2099DLeanBoundFreeRealAbelLimit where
  roots := #[`R2099DLeanBoundFreeRealAbelLimit]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2098DLeanConvergentPartialSumBound"
block = """

import R2098DLeanConvergentPartialSumBound
import R2099DLeanBoundFreeRealAbelLimit
#check R2098DLeanConvergentPartialSumBound.exists_abs_bound_of_tendsto_real
#check R2098DLeanConvergentPartialSumBound.exists_inclusive_partial_sum_abs_bound
#check R2098DLeanConvergentPartialSumBound.ConvergentPartialSumBoundWitness
#check R2098DLeanConvergentPartialSumBound.convergentPartialSumBoundWitness
#check R2099DLeanBoundFreeRealAbelLimit.infinite_abel_summation_identity_of_tendsto
#check R2099DLeanBoundFreeRealAbelLimit.real_abel_average_tendsto_of_partial_sums
#check R2099DLeanBoundFreeRealAbelLimit.BoundFreeRealAbelLimitWitness
#check R2099DLeanBoundFreeRealAbelLimit.boundFreeRealAbelLimitWitness
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2098D/R2099D convergent-bound and bound-free Abel-limit patch."
