#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f R2081DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationGate.lean

sha256sum -c SHA256SUMS_R2083D_COMBINED_FINALIZATION_EVIDENCE_CONDITIONAL_FINALIZATION.txt

grep -q 'R2081DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationGate' lakefile.lean
grep -q 'import R2081DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationGate' Main.lean

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

lake_marker = "lean_lib R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence where"
lake_block = """

@[default_target]
lean_lib R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence where
  roots := #[`R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence]

@[default_target]
lean_lib R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization where
  roots := #[`R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization]
"""
if lake_marker not in text:
    text = text.rstrip() + lake_block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
main_marker = "import R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence"
main_block = """

import R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence
import R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization
#check R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence.EndpointTheoremFinalizationEvidence
#check R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence.endpoint_first_concrete_obligation_endpoint_theorem_finalization_evidence
#check R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence.endpoint_first_concrete_obligation_endpoint_theorem_finalization_evidence_constructed
#check R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence.endpoint_first_concrete_obligation_endpoint_theorem_finalization_evidence_to_actual_li_target
#check R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence.endpoint_first_concrete_obligation_endpoint_theorem_finalization_evidence_to_certificate_statement
#check R2082DLeanEndpointFirstConcreteObligationEndpointTheoremFinalizationEvidence.endpoint_first_concrete_obligation_endpoint_theorem_finalization_evidence_to_export_proof
#check R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization.EndpointTheoremConditionalFinalizationStatement
#check R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization.endpoint_first_concrete_obligation_endpoint_theorem_conditional_finalization_statement_proved
#check R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization.endpoint_first_concrete_obligation_endpoint_theorem_conditional_finalization_from_exported_certificate
#check R2083DLeanEndpointFirstConcreteObligationEndpointTheoremConditionalFinalization.endpoint_first_concrete_obligation_endpoint_theorem_conditional_finalization_preserves_certificate_statement
"""
if main_marker not in text:
    text = text.rstrip() + main_block
main.write_text(text)
PY

echo "Applied R2082D/R2083D finalization evidence and conditional finalization patch."
