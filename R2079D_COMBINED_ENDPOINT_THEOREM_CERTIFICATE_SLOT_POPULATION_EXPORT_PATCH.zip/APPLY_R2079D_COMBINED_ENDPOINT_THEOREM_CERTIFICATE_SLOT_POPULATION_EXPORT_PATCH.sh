#!/usr/bin/env bash
set -euo pipefail

python3 - <<'PYAPPLY'
from pathlib import Path
import re
R2077 = 'R2077DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateBoundary'
R2078 = 'R2078DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateSlotPopulation'
R2079 = 'R2079DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateExport'

lake = Path('lakefile.lean')
text = lake.read_text()
text = re.sub(r'package «[^»]+» where', f'package «{R2079}» where', text, count=1)
for m in (R2078, R2079):
    text = re.sub(rf'\n?@\[default_target\]\nlean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
lines = [line for line in text.splitlines() if line.strip() != '@[default_target]']
text = '\n'.join(lines).rstrip() + '\n'
if f'lean_lib {R2077} where' not in text:
    text += f"\nlean_lib {R2077} where\n  roots := #[`{R2077}]\n"
text += f"\nlean_lib {R2078} where\n  roots := #[`{R2078}]\n\n@[default_target]\nlean_lib {R2079} where\n  roots := #[`{R2079}]\n"
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2078 in line or R2079 in line:
        continue
    mlines.append(line)
mt = '\n'.join(mlines).rstrip()
block_lines = [
    '',
    f'import {R2078}',
    f'import {R2079}',
    f'#check {R2078}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_slot_population_to_actual_li_target',
    f'#check {R2078}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_slot_population_statement',
    f'#check {R2078}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_slot_population_checked_candidate',
    f'#check {R2078}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_slot_population_closure_gate_result',
    f'#check {R2078}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_slot_population_slots_populated',
    f'#check {R2078}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_slot_population_keeps_certificate_incomplete',
    f'#check {R2079}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_export_to_actual_li_target',
    f'#check {R2079}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_export_statement',
    f'#check {R2079}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_export_checked_candidate',
    f'#check {R2079}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_export_closure_gate_result',
    f'#check {R2079}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_export_packet_exported',
    f'#check {R2079}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_export_keeps_certificate_incomplete',
    ''
]
main.write_text(mt + '\n'.join(block_lines))
PYAPPLY

sha256sum \
  R2078DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateSlotPopulation.lean \
  R2078DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateSlotPopulation/*.lean \
  R2079DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateExport.lean \
  R2079DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateExport/*.lean \
  R2078D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CERTIFICATE_SLOT_POPULATION_LEDGER.md \
  R2079D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CERTIFICATE_EXPORT_LEDGER.md \
  R2078D_ONE_HUNDRED_SEVENTEENTH_BEST_STEP.md \
  R2079D_ONE_HUNDRED_EIGHTEENTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2078D_R2079D.md \
  VERIFY_STATUS_R2078D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CERTIFICATE_SLOT_POPULATION.md \
  VERIFY_STATUS_R2079D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CERTIFICATE_EXPORT.md \
  > SHA256SUMS_R2079D_COMBINED_ENDPOINT_THEOREM_CERTIFICATE_SLOT_POPULATION_EXPORT.txt

bash -n APPLY_R2079D_COMBINED_ENDPOINT_THEOREM_CERTIFICATE_SLOT_POPULATION_EXPORT_PATCH.sh
