# R2005D fix: toy non-Prop theorem declarations

This patch fixes the R2004D/R2005D combined endpoint execution precheck layer after the Codespaces build stopped at:

```text
R2004DLeanEndpointFirstDischargeAttemptInputSlots/ToyEndpointFirstDischargeAttemptInputSlots.lean:71:0:
type of theorem ... is not a proposition
```

## Cause

Several toy "runs" declarations were introduced as `theorem` even though their return type is a data/object type rather than a `Prop`:

- `MainAnchoredEndpointFirstDischargeAttemptBoundary PD`
- `MainAnchoredEndpointFirstDischargeAttemptInputSlots AA`
- `EndpointFirstDischargeAttemptInputDependencyPlan IS`
- `MainAnchoredEndpointFirstDischargeExecutionPrecheck IP`

Lean requires `theorem` bodies to prove propositions. For executable/forgetful-map smoke tests returning data, `def` is the correct declaration form.

## Fix

The following declarations are changed from `theorem` to `def`:

- `toy_endpoint_first_discharge_attempt_input_slots_to_attempt_boundary_runs`
- `toy_endpoint_first_discharge_attempt_input_dependency_plan_to_slots_runs`
- `toy_endpoint_first_discharge_execution_precheck_to_input_dependency_plan_runs`
- `toy_endpoint_first_discharge_execution_precheck_dependency_audit_to_precheck_runs`

The target bridge checks returning `A.actualLiTarget` are left as `theorem` declarations.

## Non-claim boundary

This patch changes only toy declaration kinds. It does not add an endpoint proof-kernel execution, a concrete endpoint lemma discharge, an endpoint estimate proof, an explicit formula proof, or an RH proof.
