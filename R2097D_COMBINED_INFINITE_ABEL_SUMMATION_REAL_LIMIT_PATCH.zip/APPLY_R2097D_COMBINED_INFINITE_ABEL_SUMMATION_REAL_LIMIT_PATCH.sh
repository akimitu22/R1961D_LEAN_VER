#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f lake-manifest.json
test -f R2095DLeanConcreteAbelAverageStability.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
grep -q 'require mathlib from git' lakefile.lean
grep -q 'R2095DLeanConcreteAbelAverageStability' lakefile.lean
grep -q 'import R2095DLeanConcreteAbelAverageStability' Main.lean

sha256sum -c SHA256SUMS_R2097D_COMBINED_INFINITE_ABEL_SUMMATION_REAL_LIMIT.txt

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2097DLeanConcreteRealAbelLimitTheorem» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2096DLeanInfiniteAbelSummationIdentity where"
block = """

@[default_target]
lean_lib R2096DLeanInfiniteAbelSummationIdentity where
  roots := #[`R2096DLeanInfiniteAbelSummationIdentity]

@[default_target]
lean_lib R2097DLeanConcreteRealAbelLimitTheorem where
  roots := #[`R2097DLeanConcreteRealAbelLimitTheorem]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2096DLeanInfiniteAbelSummationIdentity"
block = """

import R2096DLeanInfiniteAbelSummationIdentity
import R2097DLeanConcreteRealAbelLimitTheorem
#check R2096DLeanInfiniteAbelSummationIdentity.realPowerSeriesValue
#check R2096DLeanInfiniteAbelSummationIdentity.inclusive_partial_sum_tendsto
#check R2096DLeanInfiniteAbelSummationIdentity.real_power_series_summable_inside_unit_interval
#check R2096DLeanInfiniteAbelSummationIdentity.partial_sum_boundary_term_tendsto_zero
#check R2096DLeanInfiniteAbelSummationIdentity.finite_abel_transform_tendsto_power_series
#check R2096DLeanInfiniteAbelSummationIdentity.finite_abel_transform_tendsto_abel_average
#check R2096DLeanInfiniteAbelSummationIdentity.infinite_abel_summation_identity
#check R2096DLeanInfiniteAbelSummationIdentity.InfiniteAbelSummationIdentityWitness
#check R2096DLeanInfiniteAbelSummationIdentity.infiniteAbelSummationIdentityWitness
#check R2097DLeanConcreteRealAbelLimitTheorem.real_abel_average_tendsto_of_partial_sums
#check R2097DLeanConcreteRealAbelLimitTheorem.ConcreteRealAbelLimitWitness
#check R2097DLeanConcreteRealAbelLimitTheorem.concreteRealAbelLimitWitness
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2096D/R2097D infinite Abel-summation and real-limit patch."
