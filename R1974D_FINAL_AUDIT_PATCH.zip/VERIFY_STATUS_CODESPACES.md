# VERIFY STATUS — Codespaces / Linux

## Current top target

```text
R1974DLeanFiniteAbelComponents
```

## Status summary

```text
R1970D: verified, 110 jobs
R1971D: verified, 114 jobs
R1972D: verified, 118 jobs
R1973D: verified, 122 jobs
R1974D: pending final local Codespaces rerun after applying this final-audit patch
```

## Required R1974D verification command

```bash
lake build 2>&1 | tee VERIFY_LOG_CODESPACES_R1974D_FINITE_ABEL_COMPONENTS.txt
```

Expected success line:

```text
Build completed successfully (126 jobs).
```

After the R1974D run succeeds, refresh this file to mark R1974D verified and then
regenerate `SHA256SUMS_R1974D_FINAL.txt`.
