#!/usr/bin/env bash
set -euo pipefail

cp -R R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure .
cp -R R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport .
cp R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure.lean .
cp R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.lean .
cp R2066D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_LEDGER.md .
cp R2067D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_DISCHARGE_CERTIFICATE_EXPORT_LEDGER.md .
cp R2066D_ONE_HUNDRED_FIFTH_BEST_STEP.md .
cp R2067D_ONE_HUNDRED_SIXTH_BEST_STEP.md .
cp MANUSCRIPT_REFERENCE_R2066D_R2067D.md .
cp VERIFY_STATUS_R2066D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE.md .
cp VERIFY_STATUS_R2067D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_DISCHARGE_CERTIFICATE_EXPORT.md .
cp R2067D_COMBINED_PATCH_MANIFEST.txt .

python3 - <<'PY'
from pathlib import Path

lake = Path('lakefile.lean')
text = lake.read_text()
text = text.replace('package «R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution» where',
                    'package «R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport» where')
old = """@[default_target]
lean_lib R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution where
  roots := #[`R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution]
"""
new = """lean_lib R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution where
  roots := #[`R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution]

lean_lib R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure where
  roots := #[`R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure]

@[default_target]
lean_lib R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport where
  roots := #[`R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport]
"""
if old in text:
    text = text.replace(old, new)
elif 'lean_lib R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport where' not in text:
    text = text.rstrip() + '\n\n' + new
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
block = """
import R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure
import R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport
#check R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure.endpoint_first_concrete_obligation_local_discharge_closure_to_actual_li_target
#check R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure.endpoint_first_concrete_obligation_local_discharge_closure_proves_kernel_conclusion
#check R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure.endpoint_first_concrete_obligation_local_discharge_closure_preserves_checker_execution
#check R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.endpoint_first_concrete_obligation_discharge_certificate_export_to_actual_li_target
#check R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.endpoint_first_concrete_obligation_discharge_certificate_exported_certificate
#check R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.endpoint_first_concrete_obligation_discharge_certificate_exported_certificate_satisfies_obligation
#check R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.endpoint_first_concrete_obligation_discharge_certificate_export_preserves_local_discharge_closure
"""
if 'import R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport' not in mt:
    mt = mt.rstrip() + block
main.write_text(mt)
PY

sha256sum \
  R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure.lean \
  R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure/*.lean \
  R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.lean \
  R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport/*.lean \
  R2066D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_LEDGER.md \
  R2067D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_DISCHARGE_CERTIFICATE_EXPORT_LEDGER.md \
  R2066D_ONE_HUNDRED_FIFTH_BEST_STEP.md \
  R2067D_ONE_HUNDRED_SIXTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2066D_R2067D.md \
  VERIFY_STATUS_R2066D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE.md \
  VERIFY_STATUS_R2067D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_DISCHARGE_CERTIFICATE_EXPORT.md \
  > SHA256SUMS_R2067D_COMBINED_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_CERTIFICATE_EXPORT.txt

bash -n APPLY_R2067D_COMBINED_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_CERTIFICATE_EXPORT_PATCH.sh
