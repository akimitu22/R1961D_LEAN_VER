#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f lake-manifest.json
test -f R2101DLeanHasSumAbelBoundary.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
grep -q 'require mathlib from git' lakefile.lean
grep -q 'R2101DLeanHasSumAbelBoundary' lakefile.lean
grep -q 'import R2101DLeanHasSumAbelBoundary' Main.lean

sha256sum -c SHA256SUMS_R2103D_COMBINED_ACTUAL_LI_KERNEL_PHASE_NORMAL_FORM.txt

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2103DLeanLiPhaseNormalForm» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2102DLeanActualLiKernel where"
block = """

@[default_target]
lean_lib R2102DLeanActualLiKernel where
  roots := #[`R2102DLeanActualLiKernel]

@[default_target]
lean_lib R2103DLeanLiPhaseNormalForm where
  roots := #[`R2103DLeanLiPhaseNormalForm]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2102DLeanActualLiKernel"
block = """

import R2102DLeanActualLiKernel
import R2103DLeanLiPhaseNormalForm
#check R2102DLeanActualLiKernel.actualLiPhase
#check R2102DLeanActualLiKernel.actualLiKernel
#check R2102DLeanActualLiKernel.actual_li_kernel_denominator_pos
#check R2102DLeanActualLiKernel.actual_li_phase_pos
#check R2102DLeanActualLiKernel.actual_li_phase_lt_nat_mul_pi
#check R2102DLeanActualLiKernel.abs_actual_li_kernel_le
#check R2102DLeanActualLiKernel.ActualLiKernelWitness
#check R2102DLeanActualLiKernel.actualLiKernelWitness
#check R2103DLeanLiPhaseNormalForm.liPhaseAmplitude
#check R2103DLeanLiPhaseNormalForm.liPhaseNormalForm
#check R2103DLeanLiPhaseNormalForm.li_phase_amplitude_nonneg
#check R2103DLeanLiPhaseNormalForm.abs_li_phase_normal_form_le_amplitude
#check R2103DLeanLiPhaseNormalForm.actual_li_rational_amplitude_eq_phase_amplitude
#check R2103DLeanLiPhaseNormalForm.actual_li_kernel_eq_phase_normal_form
#check R2103DLeanLiPhaseNormalForm.LiPhaseNormalFormWitness
#check R2103DLeanLiPhaseNormalForm.liPhaseNormalFormWitness
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2102D/R2103D actual Li-kernel and phase-normal-form patch."
