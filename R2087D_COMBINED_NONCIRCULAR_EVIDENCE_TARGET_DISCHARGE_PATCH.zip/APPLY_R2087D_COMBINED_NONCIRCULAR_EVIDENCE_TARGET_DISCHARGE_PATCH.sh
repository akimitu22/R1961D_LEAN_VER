#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction.lean

sha256sum -c SHA256SUMS_R2087D_COMBINED_NONCIRCULAR_EVIDENCE_TARGET_DISCHARGE.txt

grep -q 'R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction' lakefile.lean
grep -q 'import R2085DLeanEndpointFirstConcreteObligationEndpointClosedTargetExtraction' Main.lean

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence where"
block = """

@[default_target]
lean_lib R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence where
  roots := #[`R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence]

@[default_target]
lean_lib R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge where
  roots := #[`R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence"
block = """

import R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence
import R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge
#check R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence.NonCircularAnalyticEvidence
#check R2086DLeanEndpointFirstConcreteObligationNonCircularAnalyticEvidence.non_circular_analytic_evidence_has_no_target_assumption
#check R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge.ActualLiTargetDischargeStatement
#check R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge.actual_li_target_from_nine_analytic_components
#check R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge.endpoint_first_concrete_obligation_actual_li_target_discharge
#check R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge.endpoint_first_concrete_obligation_actual_li_target_without_dependency_closure
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2086D/R2087D non-circular analytic evidence and target discharge patch."
