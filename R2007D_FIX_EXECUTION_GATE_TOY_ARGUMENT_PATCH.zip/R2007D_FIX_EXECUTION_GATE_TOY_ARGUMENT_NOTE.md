# R2007D Fix: execution-gate toy argument

This patch fixes a toy-check argument mismatch in
`R2006DLeanEndpointFirstDischargeExecutionGate/ToyEndpointFirstDischargeExecutionGate.lean`.

## Problem

Two toy declarations passed the older statement-group variable `G` to R2006D execution-gate maps:

- `endpoint_first_discharge_execution_gate_to_precheck G`
- `endpoint_first_discharge_execution_gate_to_actual_li_target G`

Here `G` has type `MainAnchoredEndpointStatementGroup B`, while both maps expect
`MainAnchoredEndpointFirstDischargeExecutionGate PA`.

## Fix

Both calls now pass the local execution-gate argument `EG`:

- `endpoint_first_discharge_execution_gate_to_precheck EG`
- `endpoint_first_discharge_execution_gate_to_actual_li_target EG`

## Non-claim boundary

This fix is a toy-check plumbing correction only. It does not execute the endpoint proof kernel,
discharge a concrete endpoint lemma, prove the endpoint estimate, prove an explicit formula, or prove RH.
