#!/usr/bin/env bash
set -euo pipefail

# Files are already placed by unzip. This script only updates aggregate build files
# and records checksums for the newly added R2074D/R2075D layers.
# It is intentionally idempotent and does not self-copy directories.

python3 - <<'PYAPPLY'
from pathlib import Path
import re

R2073 = 'R2073DLeanEndpointFirstConcreteObligationEndpointProofTermCheckGate'
R2074 = 'R2074DLeanEndpointFirstConcreteObligationEndpointProofTermCheckCertificate'
R2075 = 'R2075DLeanEndpointFirstConcreteObligationEndpointTheoremClosureHandoff'

lake = Path('lakefile.lean')
text = lake.read_text()
text = re.sub(r'package «[^»]+» where', f'package «{R2075}» where', text, count=1)

for m in (R2074, R2075):
    text = re.sub(rf'\n?@\[default_target\]\nlean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m}\n?', '\n', text)

lines = [line for line in text.splitlines() if line.strip() != '@[default_target]']
text = '\n'.join(lines).rstrip() + '\n'

if f'lean_lib {R2073} where' not in text:
    text += f"\nlean_lib {R2073} where\n  roots := #[`{R2073}]\n"

text += f"\nlean_lib {R2074} where\n  roots := #[`{R2074}]\n\n@[default_target]\nlean_lib {R2075} where\n  roots := #[`{R2075}]\n"
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2074 in line or R2075 in line:
        continue
    mlines.append(line)
mt = '\n'.join(mlines).rstrip()
block = f"""
import {R2074}
import {R2075}
#check {R2074}.endpoint_first_concrete_obligation_endpoint_proof_term_check_certificate_to_actual_li_target
#check {R2074}.endpoint_first_concrete_obligation_endpoint_proof_term_check_certificate_statement
#check {R2074}.endpoint_first_concrete_obligation_endpoint_proof_term_check_certificate_checked_candidate
#check {R2074}.endpoint_first_concrete_obligation_endpoint_proof_term_check_certificate_result
#check {R2074}.endpoint_first_concrete_obligation_endpoint_proof_term_check_certificate_ready_for_closure_handoff
#check {R2074}.endpoint_first_concrete_obligation_endpoint_proof_term_check_certificate_keeps_endpoint_theorem_unclaimed
#check {R2075}.endpoint_first_concrete_obligation_endpoint_theorem_closure_handoff_to_actual_li_target
#check {R2075}.endpoint_first_concrete_obligation_endpoint_theorem_closure_handoff_statement
#check {R2075}.endpoint_first_concrete_obligation_endpoint_theorem_closure_handoff_checked_candidate
#check {R2075}.endpoint_first_concrete_obligation_endpoint_theorem_closure_handoff_completed
#check {R2075}.endpoint_first_concrete_obligation_endpoint_theorem_closure_handoff_keeps_endpoint_theorem_unclosed
"""
main.write_text(mt + block)
PYAPPLY

sha256sum \
  R2074DLeanEndpointFirstConcreteObligationEndpointProofTermCheckCertificate.lean \
  R2074DLeanEndpointFirstConcreteObligationEndpointProofTermCheckCertificate/*.lean \
  R2075DLeanEndpointFirstConcreteObligationEndpointTheoremClosureHandoff.lean \
  R2075DLeanEndpointFirstConcreteObligationEndpointTheoremClosureHandoff/*.lean \
  R2074D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_PROOF_TERM_CHECK_CERTIFICATE_LEDGER.md \
  R2075D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CLOSURE_HANDOFF_LEDGER.md \
  R2074D_ONE_HUNDRED_THIRTEENTH_BEST_STEP.md \
  R2075D_ONE_HUNDRED_FOURTEENTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2074D_R2075D.md \
  VERIFY_STATUS_R2074D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_PROOF_TERM_CHECK_CERTIFICATE.md \
  VERIFY_STATUS_R2075D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CLOSURE_HANDOFF.md \
  > SHA256SUMS_R2075D_COMBINED_ENDPOINT_PROOF_TERM_CHECK_CERTIFICATE_CLOSURE_HANDOFF.txt

bash -n APPLY_R2075D_COMBINED_ENDPOINT_PROOF_TERM_CHECK_CERTIFICATE_CLOSURE_HANDOFF_PATCH.sh
