#!/usr/bin/env bash
set -euo pipefail

# Files are already placed by unzip. This script only updates aggregate build files
# and records checksums for the newly added R2076D/R2077D layers.
# It is intentionally idempotent and does not self-copy directories.

python3 - <<'PYAPPLY'
from pathlib import Path
import re

R2075 = 'R2075DLeanEndpointFirstConcreteObligationEndpointTheoremClosureHandoff'
R2076 = 'R2076DLeanEndpointFirstConcreteObligationEndpointTheoremClosureGate'
R2077 = 'R2077DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateBoundary'

lake = Path('lakefile.lean')
text = lake.read_text()
text = re.sub(r'package «[^»]+» where', f'package «{R2077}» where', text, count=1)

for m in (R2076, R2077):
    text = re.sub(rf'\n?@\[default_target\]\nlean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m} where\n\s+roots := #\[`{m}\]\n?', '\n', text)
    text = re.sub(rf'\n?lean_lib {m}\n?', '\n', text)

lines = [line for line in text.splitlines() if line.strip() != '@[default_target]']
text = '\n'.join(lines).rstrip() + '\n'

if f'lean_lib {R2075} where' not in text:
    text += f"\nlean_lib {R2075} where\n  roots := #[`{R2075}]\n"

text += f"\nlean_lib {R2076} where\n  roots := #[`{R2076}]\n\n@[default_target]\nlean_lib {R2077} where\n  roots := #[`{R2077}]\n"
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2076 in line or R2077 in line:
        continue
    mlines.append(line)
mt = '\n'.join(mlines).rstrip()
block = f"""
import {R2076}
import {R2077}
#check {R2076}.endpoint_first_concrete_obligation_endpoint_theorem_closure_gate_to_actual_li_target
#check {R2076}.endpoint_first_concrete_obligation_endpoint_theorem_closure_gate_statement
#check {R2076}.endpoint_first_concrete_obligation_endpoint_theorem_closure_gate_checked_candidate
#check {R2076}.endpoint_first_concrete_obligation_endpoint_theorem_closure_gate_executed
#check {R2076}.endpoint_first_concrete_obligation_endpoint_theorem_closure_gate_result
#check {R2076}.endpoint_first_concrete_obligation_endpoint_theorem_closure_gate_keeps_endpoint_theorem_unclosed
#check {R2077}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_boundary_to_actual_li_target
#check {R2077}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_boundary_statement
#check {R2077}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_boundary_checked_candidate
#check {R2077}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_boundary_input_slots_exposed
#check {R2077}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_boundary_closure_gate_result
#check {R2077}.endpoint_first_concrete_obligation_endpoint_theorem_certificate_boundary_keeps_certificate_incomplete
"""
main.write_text(mt + block)
PYAPPLY

sha256sum \
  R2076DLeanEndpointFirstConcreteObligationEndpointTheoremClosureGate.lean \
  R2076DLeanEndpointFirstConcreteObligationEndpointTheoremClosureGate/*.lean \
  R2077DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateBoundary.lean \
  R2077DLeanEndpointFirstConcreteObligationEndpointTheoremCertificateBoundary/*.lean \
  R2076D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CLOSURE_GATE_LEDGER.md \
  R2077D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CERTIFICATE_BOUNDARY_LEDGER.md \
  R2076D_ONE_HUNDRED_FIFTEENTH_BEST_STEP.md \
  R2077D_ONE_HUNDRED_SIXTEENTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2076D_R2077D.md \
  VERIFY_STATUS_R2076D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CLOSURE_GATE.md \
  VERIFY_STATUS_R2077D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_ENDPOINT_THEOREM_CERTIFICATE_BOUNDARY.md \
  > SHA256SUMS_R2077D_COMBINED_ENDPOINT_THEOREM_CLOSURE_GATE_CERTIFICATE_BOUNDARY.txt

bash -n APPLY_R2077D_COMBINED_ENDPOINT_THEOREM_CLOSURE_GATE_CERTIFICATE_BOUNDARY_PATCH.sh
