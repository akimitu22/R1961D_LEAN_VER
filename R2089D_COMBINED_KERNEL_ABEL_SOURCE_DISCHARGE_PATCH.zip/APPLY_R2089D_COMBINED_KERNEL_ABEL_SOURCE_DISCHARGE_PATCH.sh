#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge.lean

sha256sum -c SHA256SUMS_R2089D_COMBINED_KERNEL_ABEL_SOURCE_DISCHARGE.txt

grep -q 'R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge' lakefile.lean
grep -q 'import R2087DLeanEndpointFirstConcreteObligationActualLiTargetDischarge' Main.lean

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

marker = "lean_lib R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge where"
block = """

@[default_target]
lean_lib R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge where
  roots := #[`R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge]

@[default_target]
lean_lib R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge where
  roots := #[`R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge]
"""
if marker not in text:
    text = text.rstrip() + block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
marker = "import R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge"
block = """

import R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge
import R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge
#check R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge.ActualLiKernelSourceEvidence
#check R2088DLeanEndpointFirstConcreteObligationActualLiKernelSourceDischarge.actual_li_kernel_registered_from_source_evidence
#check R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge.AbelBoundarySourceEvidence
#check R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge.abel_boundary_registered_from_source_evidence
#check R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge.actual_li_kernel_and_abel_boundary_registered_from_source_evidence
"""
if marker not in text:
    text = text.rstrip() + block
main.write_text(text)
PY

echo "Applied R2088D/R2089D kernel and Abel source discharge patch."
