import D190.RHFinitePositivePairingIdentification
import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace R2142DLeanFiniteConjugationOrbitPairing

open scoped BigOperators
open R2102DLeanActualLiKernel
open R2120DLeanAbelRegularizedHeightShell
open R2127DLeanCompatibleCriticalStripZeroCuts

noncomputable def liZeroTerm (n : Nat) (z : Complex) : Complex :=
  1 - (1 - 1 / z) ^ n

noncomputable def absoluteLiAbelWeight
    (n : Nat) (sigma : Real) (z : Complex) : Real :=
  Real.exp (-sigma * actualLiPhase n |z.im|)

theorem li_zero_term_conj (n : Nat) (z : Complex) :
    liZeroTerm n ((starRingEnd Complex) z) =
      (starRingEnd Complex) (liZeroTerm n z) := by
  simp [liZeroTerm]

theorem li_zero_term_add_conj_eq_two_re (n : Nat) (z : Complex) :
    liZeroTerm n z + liZeroTerm n ((starRingEnd Complex) z) =
      ((2 * (liZeroTerm n z).re : Real) : Complex) := by
  rw [li_zero_term_conj]
  exact Complex.add_conj (liZeroTerm n z)

noncomputable def conjugatePositiveCriticalStripZeroCut
    (height : Real) : Finset Complex :=
  (positiveCriticalStripZeroCut height).image (starRingEnd Complex)

/-- A concrete two-sided cut generated from the positive representatives.
It is not called an actual zeta-zero cut until zeta conjugation is proved. -/
noncomputable def pairedSymmetricNonrealCut
    (height : Real) : Finset Complex :=
  positiveCriticalStripZeroCut height ∪
    conjugatePositiveCriticalStripZeroCut height

theorem conjugation_injective :
    Function.Injective (starRingEnd Complex) := by
  intro z w h
  have h' := congrArg (starRingEnd Complex) h
  simpa using h'

theorem positive_cut_disjoint_conjugate_cut
    {height : Real} (hheight : 0 ≤ height) :
    Disjoint (positiveCriticalStripZeroCut height)
      (conjugatePositiveCriticalStripZeroCut height) := by
  classical
  refine Finset.disjoint_left.mpr ?_
  intro z hz hzc
  rcases Finset.mem_image.mp hzc with ⟨w, hw, rfl⟩
  have hwpos :=
    ((mem_positive_critical_strip_zero_cut_iff hheight).mp hw).2.2.2.1
  have hcpos :=
    ((mem_positive_critical_strip_zero_cut_iff hheight).mp hz).2.2.2.1
  simp only [Complex.conj_im] at hcpos
  linarith

theorem mem_paired_symmetric_nonreal_cut_iff
    {height : Real} {z : Complex} :
    z ∈ pairedSymmetricNonrealCut height ↔
      z ∈ positiveCriticalStripZeroCut height ∨
        (starRingEnd Complex) z ∈ positiveCriticalStripZeroCut height := by
  classical
  simp only [pairedSymmetricNonrealCut, Finset.mem_union,
    conjugatePositiveCriticalStripZeroCut, Finset.mem_image]
  constructor
  · intro h
    rcases h with h | ⟨w, hw, hwz⟩
    · exact Or.inl h
    · right
      subst z
      simpa using hw
  · intro h
    rcases h with h | h
    · exact Or.inl h
    · right
      exact ⟨(starRingEnd Complex) z, h, by simp⟩

noncomputable def pairedSymmetricLiCutSum
    (height : Real) (n : Nat) (sigma : Real) : Complex :=
  ∑ z in pairedSymmetricNonrealCut height,
    (analyticOrderNatAt riemannZeta z : Complex) *
      (absoluteLiAbelWeight n sigma z : Complex) * liZeroTerm n z

noncomputable def positiveOrbitExpandedLiCutSum
    (height : Real) (n : Nat) (sigma : Real) : Complex :=
  ∑ z in positiveCriticalStripZeroCut height,
    (analyticOrderNatAt riemannZeta z : Complex) *
      (absoluteLiAbelWeight n sigma z : Complex) *
        (liZeroTerm n z + liZeroTerm n ((starRingEnd Complex) z))

noncomputable def positiveCompressedLiCutSum
    (height : Real) (n : Nat) (sigma : Real) : Complex :=
  ∑ z in positiveCriticalStripZeroCut height,
    (((analyticOrderNatAt riemannZeta z : Real) *
      Real.exp (-sigma * actualLiPhase n z.im) *
        (2 * (1 - ((1 - 1 / z) ^ n).re)) : Real) : Complex)

noncomputable def positiveOrdinateComplexCutSum
    (height : Real) (n : Nat) (sigma : Real) : Complex :=
  ∑ z in positiveCriticalStripZeroCut height,
    (((analyticOrderNatAt riemannZeta z : Real) *
      actualAbelEntranceKernel n sigma z.im : Real) : Complex)

/-- Exact reindexing of the concrete disjoint union.  The only zeta-specific
input is preservation of analytic multiplicity under conjugation. -/
theorem paired_symmetric_sum_eq_positive_orbit_sum
    {height : Real} (hheight : 0 ≤ height) (n : Nat) (sigma : Real)
    (horder : ∀ z ∈ positiveCriticalStripZeroCut height,
      analyticOrderNatAt riemannZeta ((starRingEnd Complex) z) =
        analyticOrderNatAt riemannZeta z) :
    pairedSymmetricLiCutSum height n sigma =
      positiveOrbitExpandedLiCutSum height n sigma := by
  classical
  unfold pairedSymmetricLiCutSum positiveOrbitExpandedLiCutSum
  rw [pairedSymmetricNonrealCut,
    Finset.sum_union (positive_cut_disjoint_conjugate_cut hheight)]
  unfold conjugatePositiveCriticalStripZeroCut
  rw [Finset.sum_image conjugation_injective.injOn]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro z hz
  rw [horder z hz]
  simp only [Complex.conj_im, abs_neg]
  ring

theorem positive_orbit_sum_eq_compressed_sum
    {height : Real} (hheight : 0 ≤ height) (n : Nat) (sigma : Real) :
    positiveOrbitExpandedLiCutSum height n sigma =
      positiveCompressedLiCutSum height n sigma := by
  classical
  unfold positiveOrbitExpandedLiCutSum positiveCompressedLiCutSum
  apply Finset.sum_congr rfl
  intro z hz
  have hzim : 0 < z.im :=
    ((mem_positive_critical_strip_zero_cut_iff hheight).mp hz).2.2.2.1
  rw [li_zero_term_add_conj_eq_two_re]
  simp [liZeroTerm, abs_of_pos hzim]
  ring

/-- The exact finite symmetric-cut pairing identity requested by the audit.
The cut is the explicitly generated disjoint union, and no exhaustion claim
about the full zeta-zero multiset is hidden in the statement. -/
theorem paired_symmetric_sum_eq_positive_compressed_sum
    {height : Real} (hheight : 0 ≤ height) (n : Nat) (sigma : Real)
    (horder : ∀ z ∈ positiveCriticalStripZeroCut height,
      analyticOrderNatAt riemannZeta ((starRingEnd Complex) z) =
        analyticOrderNatAt riemannZeta z) :
    pairedSymmetricLiCutSum height n sigma =
      positiveCompressedLiCutSum height n sigma := by
  rw [paired_symmetric_sum_eq_positive_orbit_sum hheight n sigma horder,
    positive_orbit_sum_eq_compressed_sum hheight n sigma]

theorem rh_positive_compressed_sum_eq_ordinate_cut
    (hRH : RiemannHypothesis) {height : Real} (hheight : 0 ≤ height)
    (n : Nat) (sigma : Real) :
    positiveCompressedLiCutSum height n sigma =
      positiveOrdinateComplexCutSum height n sigma := by
  classical
  unfold positiveCompressedLiCutSum positiveOrdinateComplexCutSum
  apply Finset.sum_congr rfl
  intro z hz
  have hpair := R2136DLeanRHOrdinateShellBoundary.
    rh_ordinate_eq_complex_li_pair hRH
      (⟨z, hz⟩ : R2128DLeanActualOrdinateCutFamily.
        PositiveCriticalStripZeroIndex height) n
  unfold actualAbelEntranceKernel
  rw [hpair]
  ring

/-- RH identifies the exact paired finite cut with the ordinate model.  The
remaining issue is whether this constructed paired cut is the full actual
nonreal zeta-zero cut. -/
theorem rh_paired_symmetric_sum_eq_ordinate_cut
    (hRH : RiemannHypothesis) {height : Real} (hheight : 0 ≤ height)
    (n : Nat) (sigma : Real)
    (horder : ∀ z ∈ positiveCriticalStripZeroCut height,
      analyticOrderNatAt riemannZeta ((starRingEnd Complex) z) =
        analyticOrderNatAt riemannZeta z) :
    pairedSymmetricLiCutSum height n sigma =
      positiveOrdinateComplexCutSum height n sigma := by
  rw [paired_symmetric_sum_eq_positive_compressed_sum
      hheight n sigma horder,
    rh_positive_compressed_sum_eq_ordinate_cut hRH hheight n sigma]

end R2142DLeanFiniteConjugationOrbitPairing
