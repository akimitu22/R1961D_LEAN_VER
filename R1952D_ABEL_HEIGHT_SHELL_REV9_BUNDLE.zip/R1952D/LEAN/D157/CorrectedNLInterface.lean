import D156.SmoothZeroCountingDensity
import Mathlib.Tactic.Linarith

namespace R2108DLeanCorrectedNLInterface

/-- The six losses retained separately in the corrected L-branch ledger. -/
structure NLLossLedger where
  packet : Real
  residual : Real
  ancillary : Real
  link : Real
  bookkeeping : Real
  normalization : Real

def totalLoss (loss : NLLossLedger) : Real :=
  loss.packet + loss.residual + loss.ancillary + loss.link +
    loss.bookkeeping + loss.normalization

theorem total_loss_eq (loss : NLLossLedger) :
    totalLoss loss =
      loss.packet + loss.residual + loss.ancillary + loss.link +
        loss.bookkeeping + loss.normalization := rfl

/-- Exact beta-class information required by the N branch.  No inhabitant is
constructed here: each field is an obligation supplied by the analytic proof. -/
structure NBranchObligations where
  coefficientNullity : Prop
  exactClassCollection : Prop
  orbitChecks : Prop
  exceptionalNullity : Prop

/-- Quantitative data and independence obligation required by the L branch. -/
structure LBranchObligations where
  mainTerm : Real
  loss : NLLossLedger
  independentOfRH : Prop

/-- The corrected logical data shared by P1--P6.  N/L exhaustiveness is the
structural terminal-ledger decomposition, not a scalar dominance disjunction. -/
structure CorrectedInfiniteSideData where
  routeReturned : Prop
  endpointNecessary : Prop
  nlLedgerExhaustive : Prop
  correctedTransport : Prop
  RH : Prop
  closure : Prop
  terminalClassNonzero : Prop
  closureExcludesNonzero : closure -> terminalClassNonzero -> False

/-- Proof obligations P1--P6 for the corrected quotient proof.  P5 is RH
closure necessity; P6 is preservation of one nonzero terminal class. -/
structure P1P6Obligations
    (data : CorrectedInfiniteSideData) : Prop where
  p1RouteReturn : data.routeReturned
  p2EndpointNecessity : data.endpointNecessary
  p3NLExhaustiveness :
    data.routeReturned -> data.endpointNecessary -> data.nlLedgerExhaustive
  p4CorrectedTransport : data.correctedTransport
  p5RHClosureNecessity : data.RH -> data.closure
  p6TerminalNoAnnihilation :
    data.routeReturned ->
    data.endpointNecessary ->
    data.nlLedgerExhaustive ->
    data.correctedTransport ->
    data.terminalClassNonzero

/-- The final theorem uses every structural link P1--P6. -/
theorem conditional_infinite_side_contradiction
    {data : CorrectedInfiniteSideData}
    (obligation : P1P6Obligations data)
    (hRH : data.RH) : False := by
  have hRoute : data.routeReturned := obligation.p1RouteReturn
  have hEndpoint : data.endpointNecessary := obligation.p2EndpointNecessity
  have hNL : data.nlLedgerExhaustive :=
    obligation.p3NLExhaustiveness hRoute hEndpoint
  have hTransport : data.correctedTransport := obligation.p4CorrectedTransport
  have hClosure : data.closure := obligation.p5RHClosureNecessity hRH
  have hNonzero : data.terminalClassNonzero :=
    obligation.p6TerminalNoAnnihilation hRoute hEndpoint hNL hTransport
  exact data.closureExcludesNonzero hClosure hNonzero

/-- A machine-checkable form of the finite negative-witness inequality.  The
numerical bounds remain inputs and are not manufactured by this theorem. -/
theorem negative_witness_of_certified_upper_bounds
    {lambdaValue mainTerm edgeTerm upperMain upperEdge epsilon : Real}
    (hdecomp : lambdaValue = mainTerm + edgeTerm)
    (hmain : mainTerm ≤ upperMain)
    (hedge : edgeTerm ≤ upperEdge)
    (hepsilon : 0 ≤ epsilon)
    (hnegative : upperMain + upperEdge + epsilon < 0) :
    lambdaValue < 0 := by
  linarith

end R2108DLeanCorrectedNLInterface
