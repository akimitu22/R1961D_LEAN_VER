import D192.FiniteConjugationOrbitPairing
import D167.FiniteComplexZeroRectangle

namespace R2143DLeanActualSymmetricZeroCutBoundary

open scoped BigOperators
open Metric
open R2118DLeanFiniteComplexZeroRectangle
open R2142DLeanFiniteConjugationOrbitPairing

/-- The concrete full nonreal critical-strip cut formed directly from
Mathlib's actual zeta-zero set. -/
noncomputable def actualSymmetricNonrealZeroCut
    (height : Real) : Finset Complex :=
  (boundedZetaZeros (height + 1)).filter fun z =>
    0 ≤ z.re ∧ z.re ≤ 1 ∧ z.im ≠ 0 ∧ |z.im| ≤ height

/-- First analytic gate: zero membership is preserved by conjugation. -/
def ZetaZeroConjugationTarget : Prop :=
  ∀ z : Complex, z ∈ riemannZetaZeros →
    (starRingEnd Complex) z ∈ riemannZetaZeros

/-- Second analytic gate: local analytic order is preserved by conjugation. -/
def ZetaAnalyticOrderConjugationTarget : Prop :=
  ∀ z : Complex, z ∈ riemannZetaZeros →
    analyticOrderNatAt riemannZeta ((starRingEnd Complex) z) =
      analyticOrderNatAt riemannZeta z

/-- Third, logically separate analytic gate: every zeta zero has finite local
analytic order.  This is needed for positive multiplicity, not for cut
exhaustion. -/
def ZetaZeroOrderFiniteTarget : Prop :=
  ∀ z : Complex, z ∈ riemannZetaZeros →
    analyticOrderAt riemannZeta z ≠ ⊤

theorem symmetric_rectangle_mem_closedBall
    {height : Real} (hheight : 0 ≤ height) {z : Complex}
    (hreLower : 0 ≤ z.re) (hreUpper : z.re ≤ 1)
    (him : |z.im| ≤ height) :
    z ∈ closedBall (0 : Complex) (height + 1) := by
  have hnorm : ‖z‖ ≤ height + 1 := by
    calc
      ‖z‖ ≤ |z.re| + |z.im| := Complex.norm_le_abs_re_add_abs_im z
      _ = z.re + |z.im| := by rw [abs_of_nonneg hreLower]
      _ ≤ 1 + height := add_le_add hreUpper him
      _ = height + 1 := by ring
  simpa [Metric.mem_closedBall] using hnorm

theorem mem_actual_symmetric_nonreal_zero_cut_iff
    {height : Real} (hheight : 0 ≤ height) {z : Complex} :
    z ∈ actualSymmetricNonrealZeroCut height ↔
      z ∈ riemannZetaZeros ∧ 0 ≤ z.re ∧ z.re ≤ 1 ∧
        z.im ≠ 0 ∧ |z.im| ≤ height := by
  classical
  rw [actualSymmetricNonrealZeroCut, Finset.mem_filter,
    mem_bounded_zeta_zeros_iff]
  constructor
  · intro h
    exact ⟨h.1.2, h.2⟩
  · intro h
    exact ⟨⟨symmetric_rectangle_mem_closedBall hheight
      h.2.1 h.2.2.1 h.2.2.2.2, h.1⟩, h.2⟩

/-- Cut exhaustion is derived from zero conjugation; it is not an independent
bridge assumption. -/
theorem actual_symmetric_cut_eq_paired_cut
    (hconj : ZetaZeroConjugationTarget)
    {height : Real} (hheight : 0 ≤ height) :
    actualSymmetricNonrealZeroCut height =
      pairedSymmetricNonrealCut height := by
  classical
  ext z
  rw [mem_actual_symmetric_nonreal_zero_cut_iff hheight,
    mem_paired_symmetric_nonreal_cut_iff]
  constructor
  · intro h
    by_cases hpos : 0 < z.im
    · left
      apply (R2127DLeanCompatibleCriticalStripZeroCuts.
        mem_positive_critical_strip_zero_cut_iff hheight).2
      exact ⟨h.1, h.2.1, h.2.2.1, hpos,
        by simpa [abs_of_pos hpos] using h.2.2.2.2⟩
    · right
      have hneg : z.im < 0 := lt_of_le_of_ne (le_of_not_gt hpos) h.2.2.2.1
      apply (R2127DLeanCompatibleCriticalStripZeroCuts.
        mem_positive_critical_strip_zero_cut_iff hheight).2
      exact ⟨hconj z h.1, by simpa using h.2.1,
        by simpa using h.2.2.1, by simpa using (neg_pos.mpr hneg),
        by simpa [abs_of_neg hneg] using h.2.2.2.2⟩
  · intro h
    rcases h with hpos | hconjpos
    · have hp := (R2127DLeanCompatibleCriticalStripZeroCuts.
        mem_positive_critical_strip_zero_cut_iff hheight).mp hpos
      exact ⟨hp.1, hp.2.1, hp.2.2.1, ne_of_gt hp.2.2.2.1,
        by simpa [abs_of_pos hp.2.2.2.1] using hp.2.2.2.2⟩
    · have hp := (R2127DLeanCompatibleCriticalStripZeroCuts.
        mem_positive_critical_strip_zero_cut_iff hheight).mp hconjpos
      have hzeta : z ∈ riemannZetaZeros := by
        have hz := hconj ((starRingEnd Complex) z) hp.1
        simpa using hz
      have hneg : z.im < 0 := by
        have hcpos : 0 < -z.im := by simpa using hp.2.2.2.1
        linarith
      exact ⟨hzeta, by simpa using hp.2.1, by simpa using hp.2.2.1,
        ne_of_lt hneg, by simpa [abs_of_neg hneg] using hp.2.2.2.2⟩

/-- The precise zeta-specific gate between the proved finite orbit algebra and
the full actual Li cut. -/
def ActualFullLiCutPairingTarget : Prop :=
  ZetaZeroConjugationTarget ∧ ZetaAnalyticOrderConjugationTarget

noncomputable def actualSymmetricLiCutSum
    (height : Real) (n : Nat) (sigma : Real) : Complex :=
  ∑ z in actualSymmetricNonrealZeroCut height,
    (analyticOrderNatAt riemannZeta z : Complex) *
      (absoluteLiAbelWeight n sigma z : Complex) * liZeroTerm n z

/-- Once the two precisely isolated zeta-specific facts are supplied, the
proved finite-orbit identity becomes an equality for the concrete full cut. -/
theorem actual_symmetric_sum_eq_positive_compressed_of_target
    (hgate : ActualFullLiCutPairingTarget)
    {height : Real} (hheight : 0 ≤ height) (n : Nat) (sigma : Real) :
    actualSymmetricLiCutSum height n sigma =
      positiveCompressedLiCutSum height n sigma := by
  unfold actualSymmetricLiCutSum
  rw [actual_symmetric_cut_eq_paired_cut hgate.1 hheight]
  apply paired_symmetric_sum_eq_positive_compressed_sum hheight n sigma
  intro z hz
  have hzeta : z ∈ riemannZetaZeros :=
    ((R2127DLeanCompatibleCriticalStripZeroCuts.
      mem_positive_critical_strip_zero_cut_iff hheight).mp hz).1
  exact hgate.2 z hzeta

theorem rh_actual_symmetric_sum_eq_ordinate_of_target
    (hgate : ActualFullLiCutPairingTarget) (hRH : RiemannHypothesis)
    {height : Real} (hheight : 0 ≤ height) (n : Nat) (sigma : Real) :
    actualSymmetricLiCutSum height n sigma =
      positiveOrdinateComplexCutSum height n sigma := by
  rw [actual_symmetric_sum_eq_positive_compressed_of_target
      hgate hheight n sigma,
    rh_positive_compressed_sum_eq_ordinate_cut hRH hheight n sigma]

end R2143DLeanActualSymmetricZeroCutBoundary
