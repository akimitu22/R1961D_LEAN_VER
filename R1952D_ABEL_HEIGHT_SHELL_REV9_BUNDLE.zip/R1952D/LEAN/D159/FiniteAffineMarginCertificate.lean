import D158.SlidingCesaroDetector
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace R2110DLeanFiniteAffineMarginCertificate

/-- A proof-carrying closed complex disk for one concrete value. -/
structure ComplexDiskCertificate (value : Complex) : Prop where
  center : Complex
  radius : Real
  radiusNonnegative : 0 <= radius
  bound : ‖value - center‖ <= radius

/-- Exact affine consistency for carrier, packet, and aggregate remainder
disks.  No limit or compactness hypothesis is used. -/
theorem affine_consistency_bound
    {carrier packet remainder centerCarrier centerRemainder coefficient : Complex}
    {radiusCarrier radiusRemainder packetError : Real}
    (hbalance : carrier = packet + remainder)
    (hcarrier : ‖carrier - centerCarrier‖ <= radiusCarrier)
    (hpacket : ‖packet - coefficient‖ <= packetError)
    (hremainder : ‖remainder - centerRemainder‖ <= radiusRemainder) :
    ‖centerCarrier - (coefficient + centerRemainder)‖ <=
      radiusCarrier + packetError + radiusRemainder := by
  have hcarrier' : ‖centerCarrier - carrier‖ <= radiusCarrier := by
    calc
      ‖centerCarrier - carrier‖ = ‖-(carrier - centerCarrier)‖ := by
        congr 1
        ring
      _ = ‖carrier - centerCarrier‖ := norm_neg _
      _ <= radiusCarrier := hcarrier
  have hid :
      centerCarrier - (coefficient + centerRemainder) =
        (centerCarrier - carrier) + (packet - coefficient) +
          (remainder - centerRemainder) := by
    rw [hbalance]
    ring
  rw [hid]
  calc
    ‖(centerCarrier - carrier) + (packet - coefficient) +
        (remainder - centerRemainder)‖
        <= ‖(centerCarrier - carrier) + (packet - coefficient)‖ +
          ‖remainder - centerRemainder‖ := norm_add_le _ _
    _ <= (‖centerCarrier - carrier‖ + ‖packet - coefficient‖) +
          ‖remainder - centerRemainder‖ :=
      add_le_add_right (norm_add_le _ _) _
    _ <= (radiusCarrier + packetError) + radiusRemainder :=
      add_le_add (add_le_add hcarrier' hpacket) hremainder
    _ = radiusCarrier + packetError + radiusRemainder := rfl

/-- Three component disks assemble to the aggregate remainder disk. -/
theorem three_component_enclosure
    {aggregate first second third centerFirst centerSecond centerThird : Complex}
    {radiusFirst radiusSecond radiusThird : Real}
    (haggregate : aggregate = first + second + third)
    (hfirst : ‖first - centerFirst‖ <= radiusFirst)
    (hsecond : ‖second - centerSecond‖ <= radiusSecond)
    (hthird : ‖third - centerThird‖ <= radiusThird) :
    ‖aggregate - (centerFirst + centerSecond + centerThird)‖ <=
      radiusFirst + radiusSecond + radiusThird := by
  have hid :
      aggregate - (centerFirst + centerSecond + centerThird) =
        (first - centerFirst) + (second - centerSecond) +
          (third - centerThird) := by
    rw [haggregate]
    ring
  rw [hid]
  calc
    ‖(first - centerFirst) + (second - centerSecond) +
        (third - centerThird)‖
        <= ‖(first - centerFirst) + (second - centerSecond)‖ +
          ‖third - centerThird‖ := norm_add_le _ _
    _ <= (‖first - centerFirst‖ + ‖second - centerSecond‖) +
          ‖third - centerThird‖ :=
      add_le_add_right (norm_add_le _ _) _
    _ <= (radiusFirst + radiusSecond) + radiusThird :=
      add_le_add (add_le_add hfirst hsecond) hthird
    _ = radiusFirst + radiusSecond + radiusThird := rfl

/-- All data needed by one finite affine margin test.  The RH-dependent disk
bounds must be supplied by concrete Li analysis; they are not axioms here. -/
structure FiniteAffineMarginCertificate (RH : Prop) : Prop where
  carrier : Complex
  packet : Complex
  remainder : Complex
  coefficient : Complex
  centerCarrier : Complex
  centerRemainder : Complex
  radiusCarrier : Real
  radiusRemainder : Real
  packetError : Real
  radiusCarrierNonnegative : 0 <= radiusCarrier
  radiusRemainderNonnegative : 0 <= radiusRemainder
  packetErrorNonnegative : 0 <= packetError
  exactBalance : carrier = packet + remainder
  packetBound : ‖packet - coefficient‖ <= packetError
  carrierBound : RH -> ‖carrier - centerCarrier‖ <= radiusCarrier
  remainderBound : RH -> ‖remainder - centerRemainder‖ <= radiusRemainder
  positiveMargin :
    radiusCarrier + packetError + radiusRemainder <
      ‖centerCarrier - (coefficient + centerRemainder)‖

theorem finite_margin_impossible
    {RH : Prop} (certificate : FiniteAffineMarginCertificate RH)
    (hRH : RH) : False := by
  have hle := affine_consistency_bound
    certificate.exactBalance
    (certificate.carrierBound hRH)
    certificate.packetBound
    (certificate.remainderBound hRH)
  exact (not_lt_of_ge hle) certificate.positiveMargin

/-- A single finite witness is sufficient; no eventual or limit theorem is
required in the final inference. -/
theorem not_rh_of_finite_margin_certificate
    {RH : Prop} (certificate : FiniteAffineMarginCertificate RH) :
    ¬ RH := by
  intro hRH
  exact finite_margin_impossible certificate hRH

end R2110DLeanFiniteAffineMarginCertificate
