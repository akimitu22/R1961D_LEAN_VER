import Mathlib

namespace R2109DLeanSlidingCesaroDetector

open scoped BigOperators Topology
open Filter

/-- One exact exponential character, written with the coefficient on the
right so demodulation simplifies without reordering. -/
def pureMode (beta coefficient : Complex) (n : Nat) : Complex :=
  beta ^ n * coefficient

/-- The finite sliding Cesaro frequency detector from TRIAL15. -/
def slidingCesaroDetector
    (beta : Complex) (x : Nat -> Complex) (N L : Nat) : Complex :=
  (L : Complex)⁻¹ *
    ∑ r in Finset.range L, (beta ^ (N + r))⁻¹ * x (N + r)

theorem slidingCesaroDetector_add
    (beta : Complex) (x y : Nat -> Complex) (N L : Nat) :
    slidingCesaroDetector beta (fun n => x n + y n) N L =
      slidingCesaroDetector beta x N L +
        slidingCesaroDetector beta y N L := by
  simp [slidingCesaroDetector, mul_add, Finset.sum_add_distrib]

theorem slidingCesaroDetector_sub
    (beta : Complex) (x y : Nat -> Complex) (N L : Nat) :
    slidingCesaroDetector beta (fun n => x n - y n) N L =
      slidingCesaroDetector beta x N L -
        slidingCesaroDetector beta y N L := by
  simp [slidingCesaroDetector, mul_sub, Finset.sum_sub_distrib]

theorem slidingCesaroDetector_selected_mode
    {beta coefficient : Complex} (hbeta : beta ≠ 0)
    (N L : Nat) (hL : 0 < L) :
    slidingCesaroDetector beta (pureMode beta coefficient) N L =
      coefficient := by
  simp [slidingCesaroDetector, pureMode, hbeta, Nat.ne_of_gt hL]

/-- The same-object cut identity descends exactly through the finite detector. -/
theorem detector_exact_cut
    {beta : Complex} {X packet remainder : Nat -> Complex}
    (hcut : ∀ n, X n = packet n + remainder n) (N L : Nat) :
    slidingCesaroDetector beta X N L =
      slidingCesaroDetector beta packet N L +
        slidingCesaroDetector beta remainder N L := by
  have hfun : X = fun n => packet n + remainder n := funext hcut
  rw [hfun]
  exact slidingCesaroDetector_add beta packet remainder N L

/-- An explicit path for the start and length of the sliding detector. -/
structure CesaroPath where
  start : Nat -> Nat
  length : Nat -> Nat
  lengthPositive : ∀ k, 0 < length k
  startCofinal : Tendsto start atTop atTop
  lengthCofinal : Tendsto length atTop atTop

def detectorAlong
    (path : CesaroPath) (beta : Complex) (x : Nat -> Complex)
    (k : Nat) : Complex :=
  slidingCesaroDetector beta x (path.start k) (path.length k)

/-- The aggregate bridge is a definition, not an axiom.  An inhabitant must
be constructed from concrete Li estimates. -/
def AggregateCesaroBridge
    (RH : Prop) (path : CesaroPath) (beta : Complex)
    (X remainder : Nat -> Complex) : Prop :=
  RH ->
    Tendsto (detectorAlong path beta X) atTop (nhds 0) ∧
    Tendsto (detectorAlong path beta remainder) atTop (nhds 0)

/-- Abstract limit contradiction after the concrete finite detector algebra
and the exact scalar cut have been supplied. -/
theorem contradiction_of_cesaro_limits
    {path : CesaroPath} {beta coefficient : Complex}
    {X packet remainder : Nat -> Complex}
    (hcut : ∀ n, X n = packet n + remainder n)
    (hX : Tendsto (detectorAlong path beta X) atTop (nhds 0))
    (hremainder :
      Tendsto (detectorAlong path beta remainder) atTop (nhds 0))
    (hpacket :
      Tendsto (detectorAlong path beta packet) atTop (nhds coefficient))
    (hcoefficient : coefficient ≠ 0) : False := by
  have hsum : Tendsto
      (fun k => detectorAlong path beta packet k +
        detectorAlong path beta remainder k)
      atTop (nhds coefficient) := by
    simpa using hpacket.add hremainder
  have heq : detectorAlong path beta X =
      fun k => detectorAlong path beta packet k +
        detectorAlong path beta remainder k := by
    funext k
    exact detector_exact_cut hcut (path.start k) (path.length k)
  have hXcoefficient :
      Tendsto (detectorAlong path beta X) atTop (nhds coefficient) := by
    rw [heq]
    exact hsum
  have hzero : (0 : Complex) = coefficient :=
    tendsto_nhds_unique hX hXcoefficient
  exact hcoefficient hzero.symm

/-- The TRIAL15 conditional conclusion.  The bridge supplies only the two
Li-analytic mean limits; packet extraction and the cut identity remain
separate proved inputs. -/
theorem not_rh_of_aggregate_cesaro_bridge
    {RH : Prop} {path : CesaroPath} {beta coefficient : Complex}
    {X packet remainder : Nat -> Complex}
    (hcut : ∀ n, X n = packet n + remainder n)
    (hpacket :
      Tendsto (detectorAlong path beta packet) atTop (nhds coefficient))
    (hcoefficient : coefficient ≠ 0)
    (bridge : AggregateCesaroBridge RH path beta X remainder) :
    ¬ RH := by
  intro hRH
  rcases bridge hRH with ⟨hX, hremainder⟩
  exact contradiction_of_cesaro_limits hcut hX hremainder hpacket hcoefficient

end R2109DLeanSlidingCesaroDetector
