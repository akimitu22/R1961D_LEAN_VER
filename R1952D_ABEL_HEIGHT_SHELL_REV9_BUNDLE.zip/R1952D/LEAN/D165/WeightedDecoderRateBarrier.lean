import D164.PhaseAwareRobustMargin
import Mathlib.Tactic.Linarith

namespace R2116DLeanWeightedDecoderRateBarrier

open scoped BigOperators
open R2112DLeanFinitePacketCesaroBound
open R2113DLeanExactWeightedModeResponse
open R2114DLeanWeightedRawNormalizedIntertwining

/-- Weighted amplification of a positive comparison scale. -/
def weightedScaleMass
    {L : Nat} (weight : Fin L -> Complex) (scale : Fin L -> Real) : Real :=
  ∑ r, ‖weight r‖ * scale r

/-- A unit-modulus selected frequency and unit selected response force the
unweighted l1 mass of every decoder to be at least one. -/
theorem one_le_weight_mass_of_selected_normalized
    {L : Nat} (weight : Fin L -> Complex) (N : Nat) {beta : Complex}
    (hbeta : ‖beta‖ = 1)
    (hselected : weightedModeResponse weight N beta = 1) :
    1 <= ∑ r, ‖weight r‖ := by
  have htriangle :
      ‖weightedModeResponse weight N beta‖ <=
        ∑ r, ‖weight r * beta ^ (N + r.val)‖ :=
    by
      unfold weightedModeResponse
      exact norm_sum_le _ _
  have hmass :
      (∑ r, ‖weight r * beta ^ (N + r.val)‖) =
        ∑ r, ‖weight r‖ := by
    apply Finset.sum_congr rfl
    intro r hr
    simp [norm_mul, norm_pow, hbeta]
  rw [hselected, norm_one, hmass] at htriangle
  exact htriangle

/-- Rate barrier: selected-mode normalization prevents the scale-weighted
decoder mass from falling below the minimum scale on the window. -/
theorem minimum_scale_le_weighted_scale_mass
    {L : Nat} (weight : Fin L -> Complex) (scale : Fin L -> Real)
    (N : Nat) {beta : Complex}
    (hbeta : ‖beta‖ = 1)
    (hselected : weightedModeResponse weight N beta = 1)
    {minimumScale : Real} (hminimumNonnegative : 0 <= minimumScale)
    (hminimum : ∀ r, minimumScale <= scale r) :
    minimumScale <= weightedScaleMass weight scale := by
  have hmass := one_le_weight_mass_of_selected_normalized
    weight N hbeta hselected
  have hscaled :
      minimumScale * (∑ r, ‖weight r‖) <=
        weightedScaleMass weight scale := by
    rw [Finset.mul_sum]
    unfold weightedScaleMass
    apply Finset.sum_le_sum
    intro r hr
    exact mul_le_mul_of_nonneg_left (hminimum r) (norm_nonneg (weight r))
  have hminimumMass :
      minimumScale <= minimumScale * (∑ r, ‖weight r‖) := by
    nlinarith
  exact hminimumMass.trans hscaled

/-- The same barrier for the complete pointwise uncertainty cost.  This is
stronger than inspecting `B` alone and includes both the quantitative closure
rate and the transport radius. -/
theorem minimum_cost_le_weighted_uncertainty
    {L : Nat} (weight : Fin L -> Complex)
    (scale delta transportRadius : Fin L -> Real)
    (N : Nat) {beta : Complex}
    (hbeta : ‖beta‖ = 1)
    (hselected : weightedModeResponse weight N beta = 1)
    {minimumCost : Real} (hminimumCostNonnegative : 0 <= minimumCost)
    (hminimumCost :
      ∀ r, minimumCost <= scale r * delta r + transportRadius r) :
    minimumCost <=
      weightedUncertainty weight scale delta transportRadius := by
  have hmass := one_le_weight_mass_of_selected_normalized
    weight N hbeta hselected
  have hweighted :
      minimumCost * (∑ r, ‖weight r‖) <=
        weightedUncertainty weight scale delta transportRadius := by
    rw [Finset.mul_sum]
    unfold weightedUncertainty
    apply Finset.sum_le_sum
    intro r hr
    exact mul_le_mul_of_nonneg_left
      (hminimumCost r) (norm_nonneg (weight r))
  have hminimumMass :
      minimumCost <= minimumCost * (∑ r, ‖weight r‖) := by
    nlinarith
  exact hminimumMass.trans hweighted

end R2116DLeanWeightedDecoderRateBarrier
