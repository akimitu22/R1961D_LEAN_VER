import D151.ActualLiKernel
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Arctan
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace R2139DLeanCriticalLineComplexPowerIdentity

open R2102DLeanActualLiKernel

noncomputable def criticalLinePoint (T : Real) : Complex :=
  (1 / 2 : Real) + (T : Complex) * Complex.I

noncomputable def criticalLineRatio (T : Real) : Complex :=
  1 - 1 / criticalLinePoint T

noncomputable def criticalLineAngle (T : Real) : Real :=
  2 * Real.arctan (1 / (2 * T))

theorem cos_critical_line_angle
    {T : Real} (hT : 0 < T) :
    Real.cos (criticalLineAngle T) =
      (4 * T ^ 2 - 1) / (4 * T ^ 2 + 1) := by
  have hargden : 1 + (1 / (2 * T)) ^ 2 ≠ 0 := by positivity
  unfold criticalLineAngle
  rw [Real.cos_two_mul', Real.cos_sq_arctan, Real.sin_sq_arctan]
  field_simp [ne_of_gt hT, hargden]
  ring

theorem sin_critical_line_angle
    {T : Real} (hT : 0 < T) :
    Real.sin (criticalLineAngle T) =
      4 * T / (4 * T ^ 2 + 1) := by
  let x : Real := 1 / (2 * T)
  have hxden : 1 + x ^ 2 ≠ 0 := by positivity
  have hcos : Real.cos (Real.arctan x) ≠ 0 :=
    ne_of_gt (Real.cos_arctan_pos x)
  have hsin : Real.sin (Real.arctan x) =
      x * Real.cos (Real.arctan x) := by
    calc
      Real.sin (Real.arctan x) =
          Real.tan (Real.arctan x) * Real.cos (Real.arctan x) :=
        (Real.tan_mul_cos hcos).symm
      _ = x * Real.cos (Real.arctan x) := by rw [Real.tan_arctan]
  unfold criticalLineAngle
  change Real.sin (2 * Real.arctan x) = _
  rw [Real.sin_two_mul, hsin]
  have hcosSq := Real.cos_sq_arctan x
  rw [show 2 * (x * Real.cos (Real.arctan x)) *
      Real.cos (Real.arctan x) =
      2 * x * Real.cos (Real.arctan x) ^ 2 by ring, hcosSq]
  unfold x
  field_simp [ne_of_gt hT, hxden]
  ring

theorem critical_line_ratio_eq_cos_add_sin_mul_I
    {T : Real} (hT : 0 < T) :
    criticalLineRatio T =
      (Real.cos (criticalLineAngle T) : Complex) +
        (Real.sin (criticalLineAngle T) : Complex) * Complex.I := by
  have hnormSq : (1 / 2 : Real) ^ 2 + T ^ 2 ≠ 0 := by positivity
  have hden : 4 * T ^ 2 + 1 ≠ 0 := by positivity
  apply Complex.ext
  · rw [cos_critical_line_angle hT]
    simp [criticalLineRatio, criticalLinePoint, Complex.div_re,
      Complex.normSq_apply]
    field_simp [ne_of_gt hT, hnormSq, hden]
    ring
  · rw [sin_critical_line_angle hT]
    simp [criticalLineRatio, criticalLinePoint, Complex.div_im,
      Complex.normSq_apply]
    field_simp [ne_of_gt hT, hnormSq, hden]
    ring

theorem critical_line_ratio_pow_re
    {T : Real} (hT : 0 < T) (n : Nat) :
    ((criticalLineRatio T) ^ n).re =
      Real.cos ((n : Real) * criticalLineAngle T) := by
  rw [critical_line_ratio_eq_cos_add_sin_mul_I hT]
  have h := Complex.cos_add_sin_mul_I_pow n
    (criticalLineAngle T : Complex)
  have hre := congrArg Complex.re h
  simpa using hre

/-- Pure critical-line algebra.  No zeta-zero or RH hypothesis is used. -/
theorem critical_line_complex_power_identity
    {z : Complex} (hre : z.re = 1 / 2) (him : 0 < z.im)
    (n : Nat) :
    ((1 - 1 / z) ^ n).re =
      Real.cos (actualLiPhase n z.im) := by
  have hz : z = criticalLinePoint z.im := by
    apply Complex.ext
    · simpa [criticalLinePoint] using hre
    · simp [criticalLinePoint]
  rw [hz]
  change ((criticalLineRatio z.im) ^ n).re = _
  rw [critical_line_ratio_pow_re him]
  unfold actualLiPhase criticalLineAngle
  congr 1
  ring

theorem zero_pair_contribution_eq_complex_pair
    {z : Complex} (hre : z.re = 1 / 2) (him : 0 < z.im)
    (n : Nat) :
    zeroPairLiContribution n z.im =
      2 * (1 - ((1 - 1 / z) ^ n).re) := by
  unfold zeroPairLiContribution
  rw [critical_line_complex_power_identity hre him n]

end R2139DLeanCriticalLineComplexPowerIdentity
