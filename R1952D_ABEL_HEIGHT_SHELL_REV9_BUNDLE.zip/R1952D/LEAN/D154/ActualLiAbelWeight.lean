import D153.CanonicalLiPhaseInverse
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace R2105DLeanActualLiAbelWeight

open scoped Real
open R2102DLeanActualLiKernel
open R2103DLeanLiPhaseNormalForm
open R2104DLeanCanonicalLiPhaseInverse

/-- Derivative of the auxiliary transported density-kernel normal form.  This
is retained for compatibility and is not used as the corrected Abel primitive. -/
noncomputable def liPhaseNormalFormDeriv (n : Nat) (u : Real) : Real :=
  8 * Real.sin (u / (2 * (n : Real))) *
        Real.cos (u / (2 * (n : Real))) * Real.sin u +
    liPhaseAmplitude n u * Real.cos u

/-- The corrected zero-pair phase primitive `P_n(u) = 2(1-cos u)`. -/
noncomputable def liZeroPairPhasePrimitive (u : Real) : Real :=
  2 * (1 - Real.cos u)

/-- The derivative `P_n'(u) = 2 sin u`. -/
noncomputable def liZeroPairPhasePrimitiveDeriv (u : Real) : Real :=
  2 * Real.sin u

/-- The corrected Abel primitive `a_sigma(u) P_n(u)`.  The index is retained
in the API because the integration interval and inverse phase map depend on it. -/
noncomputable def liAbelPrimitive
    (_n : Nat) (cutoff : Real → Real) (u : Real) : Real :=
  cutoff u * liZeroPairPhasePrimitive u

/-- The corrected Abel weight `d/du {a_sigma(u) P_n(u)}`. -/
noncomputable def liAbelWeight
    (n : Nat) (cutoff : Real → Real) (u : Real) : Real :=
  deriv (fun v => liAbelPrimitive n cutoff v) u

/-- The corrected residual integrand in the phase coordinate. -/
noncomputable def liBoundaryResidualIntegrand
    (n : Nat) (cutoff residual : Real → Real) (u : Real) : Real :=
  residual (canonicalLiPhaseInverse n u) * liAbelWeight n cutoff u

theorem hasDerivAt_li_phase_normal_form
    {n : Nat} (hn : 0 < n) (u : Real) :
    HasDerivAt (liPhaseNormalForm n) (liPhaseNormalFormDeriv n u) u := by
  have hn0 : (n : Real) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt hn)
  have harg :
      HasDerivAt (fun v : Real => v / (2 * (n : Real)))
        (1 / (2 * (n : Real))) u := by
    simpa using (hasDerivAt_id u).div_const (2 * (n : Real))
  have hnormal :=
    (((harg.sin.pow 2).const_mul (8 * (n : Real))).mul
      (Real.hasDerivAt_sin u))
  unfold liPhaseNormalForm liPhaseNormalFormDeriv liPhaseAmplitude
  convert hnormal using 1 <;> try rfl
  simp only [Pi.pow_apply]
  field_simp [hn0]
  ring_nf

theorem hasDerivAt_li_zero_pair_phase_primitive (u : Real) :
    HasDerivAt liZeroPairPhasePrimitive
      (liZeroPairPhasePrimitiveDeriv u) u := by
  have h :=
    (hasDerivAt_const u (2 : Real)).sub
      ((Real.hasDerivAt_cos u).const_mul 2)
  unfold liZeroPairPhasePrimitive liZeroPairPhasePrimitiveDeriv
  convert h using 1 <;> ring

theorem zero_pair_contribution_at_phase_inverse
    {n : Nat} (hn : 0 < n) {u : Real}
    (hu0 : 0 < u) (hu1 : u < (n : Real) * Real.pi) :
    zeroPairLiContribution n (canonicalLiPhaseInverse n u) =
      liZeroPairPhasePrimitive u := by
  unfold zeroPairLiContribution liZeroPairPhasePrimitive
  rw [canonical_li_phase_inverse_right hn hu0 hu1]

theorem hasDerivAt_li_abel_primitive
    {n : Nat} (_hn : 0 < n)
    {cutoff cutoff' : Real → Real} {u : Real}
    (hcutoff : HasDerivAt cutoff (cutoff' u) u) :
    HasDerivAt (liAbelPrimitive n cutoff)
      (cutoff' u * liZeroPairPhasePrimitive u +
        cutoff u * liZeroPairPhasePrimitiveDeriv u) u := by
  change HasDerivAt (fun v => cutoff v * liZeroPairPhasePrimitive v)
    (cutoff' u * liZeroPairPhasePrimitive u +
      cutoff u * liZeroPairPhasePrimitiveDeriv u) u
  exact hcutoff.mul (hasDerivAt_li_zero_pair_phase_primitive u)

theorem li_abel_weight_eq
    {n : Nat} (hn : 0 < n)
    {cutoff cutoff' : Real → Real} {u : Real}
    (hcutoff : HasDerivAt cutoff (cutoff' u) u) :
    liAbelWeight n cutoff u =
      cutoff' u * liZeroPairPhasePrimitive u +
        cutoff u * liZeroPairPhasePrimitiveDeriv u := by
  exact (hasDerivAt_li_abel_primitive hn hcutoff).deriv

theorem li_zero_pair_phase_primitive_zero :
    liZeroPairPhasePrimitive 0 = 0 := by
  simp [liZeroPairPhasePrimitive]

/-- Historical auxiliary endpoint identities for the transported density
kernel.  They are not used to identify it with the corrected primitive. -/
theorem li_phase_normal_form_zero_left (n : Nat) :
    liPhaseNormalForm n 0 = 0 := by
  simp [liPhaseNormalForm]

theorem li_phase_normal_form_zero_right (n : Nat) :
    liPhaseNormalForm n ((n : Real) * Real.pi) = 0 := by
  simp [liPhaseNormalForm]

/-- Proof-carrying realization of the corrected zero-pair primitive and Abel
weight. -/
structure ActualLiAbelWeightWitness
    (n : Nat) (cutoff cutoff' : Real → Real) : Prop where
  indexPositive : 0 < n
  zeroPairPrimitiveDerivative : ∀ u : Real,
    HasDerivAt liZeroPairPhasePrimitive
      (liZeroPairPhasePrimitiveDeriv u) u
  primitiveDerivative : ∀ {u : Real}, HasDerivAt cutoff (cutoff' u) u →
    HasDerivAt (liAbelPrimitive n cutoff)
      (cutoff' u * liZeroPairPhasePrimitive u +
        cutoff u * liZeroPairPhasePrimitiveDeriv u) u
  weightFormula : ∀ {u : Real}, HasDerivAt cutoff (cutoff' u) u →
    liAbelWeight n cutoff u =
      cutoff' u * liZeroPairPhasePrimitive u +
        cutoff u * liZeroPairPhasePrimitiveDeriv u

def actualLiAbelWeightWitness
    {n : Nat} (hn : 0 < n) (cutoff cutoff' : Real → Real) :
    ActualLiAbelWeightWitness n cutoff cutoff' :=
  { indexPositive := hn
    zeroPairPrimitiveDerivative := hasDerivAt_li_zero_pair_phase_primitive
    primitiveDerivative := fun hcutoff =>
      hasDerivAt_li_abel_primitive hn hcutoff
    weightFormula := fun hcutoff => li_abel_weight_eq hn hcutoff }

end R2105DLeanActualLiAbelWeight
