import D185.LowerCutPlusTailInfiniteObject

namespace R2138DLeanDyadicBaseHeightIndependence

open scoped BigOperators
open R2124DLeanDyadicAbelTailBudget
open R2128DLeanActualOrdinateCutFamily
open R2129DLeanActualDyadicShellSequence
open R2130DLeanDyadicBudgetSummability
open R2131DLeanFixedParameterAbelTail
open R2134DLeanDyadicPartialSumSingleCut
open R2135DLeanLowerCutPlusTailInfiniteObject

theorem dyadic_height_rebase (height : Real) (m j : Nat) :
    dyadicHeight (dyadicHeight height m) j =
      dyadicHeight height (m + j) := by
  unfold dyadicHeight
  rw [pow_add]
  ring

theorem actual_dyadic_shell_rebase
    (height : Real) (n : Nat) (sigma : Real) (m j : Nat) :
    actualDyadicShell (dyadicHeight height m) n sigma j =
      actualDyadicShell height n sigma (m + j) := by
  simp [actualDyadicShell, dyadic_height_rebase, Nat.add_assoc]

theorem fixed_parameter_tail_rebase
    (height : Real) (n : Nat) (sigma : Real) (m : Nat) :
    fixedParameterInfiniteAbelTail (dyadicHeight height m) n sigma =
      ∑' j, (actualDyadicShell height n sigma (j + m) : Complex) := by
  unfold fixedParameterInfiniteAbelTail
  apply tsum_congr
  intro j
  rw [actual_dyadic_shell_rebase]
  rw [Nat.add_comm m j]

/-- Base-height independence along the dyadic refinement system.  The theorem
does not claim independence for arbitrary unrelated base heights. -/
theorem lower_cut_plus_tail_dyadic_base_independent
    {constant threshold height sigma : Real} {n : Nat}
    (hn : 0 < n) (hheight : 0 < height) (hsigma : 0 ≤ sigma)
    (hgrowth : R2123DLeanExplicitZeroCountingGrowth.HasExplicitZeroCountingGrowth
      actualPositiveZeroCount constant threshold)
    (hthreshold : ∀ j, threshold ≤ dyadicHeight height (j + 1))
    (m : Nat) :
    lowerCutPlusTailInfiniteObject height n sigma =
      lowerCutPlusTailInfiniteObject (dyadicHeight height m) n sigma := by
  let f : Nat → Complex := fun j =>
    (actualDyadicShell height n sigma j : Complex)
  have hsum : Summable f :=
    summable_actual_dyadic_shell hn hheight hsigma hgrowth hthreshold
  have hsplit := hsum.sum_add_tsum_nat_add m
  have hlower := lower_cut_add_partial_sum_eq_single_cut
    hheight n sigma m
  have hlowerComplex :
      (fixedParameterAbelLowerCut height n sigma : Complex) +
          ∑ j in Finset.range m, f j =
        (fixedParameterAbelLowerCut (dyadicHeight height m) n sigma : Complex) := by
    exact_mod_cast hlower
  have htail := fixed_parameter_tail_rebase height n sigma m
  unfold lowerCutPlusTailInfiniteObject
  rw [htail]
  unfold fixedParameterInfiniteAbelTail
  calc
    (fixedParameterAbelLowerCut height n sigma : Complex) + ∑' j, f j =
        (fixedParameterAbelLowerCut height n sigma : Complex) +
          (∑ j in Finset.range m, f j + ∑' j, f (j + m)) := by
            rw [hsplit]
    _ = ((fixedParameterAbelLowerCut height n sigma : Complex) +
          ∑ j in Finset.range m, f j) + ∑' j, f (j + m) := by
            ring
    _ = (fixedParameterAbelLowerCut (dyadicHeight height m) n sigma : Complex) +
          ∑' j, f (j + m) := by rw [hlowerComplex]

end R2138DLeanDyadicBaseHeightIndependence
