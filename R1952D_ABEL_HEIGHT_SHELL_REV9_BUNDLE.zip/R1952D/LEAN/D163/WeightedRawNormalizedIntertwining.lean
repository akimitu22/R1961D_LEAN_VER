import D162.ExactWeightedModeResponse

namespace R2114DLeanWeightedRawNormalizedIntertwining

open scoped BigOperators
open R2113DLeanExactWeightedModeResponse

/-- Pointwise uncertainty transported through a weighted decoder. -/
def weightedUncertainty
    {L : Nat} (weight : Fin L -> Complex)
    (scale delta transportRadius : Fin L -> Real) : Real :=
  ∑ r, ‖weight r‖ * (scale r * delta r + transportRadius r)

/-- Exact finite-window intertwining before any estimates are applied. -/
theorem weighted_decoder_intertwining
    {L : Nat} (weight : Fin L -> Complex)
    (raw normalized transport : Fin L -> Complex)
    (scale : Fin L -> Real)
    (hpoint : ∀ r, raw r = (scale r : Complex) * normalized r + transport r) :
    weightedWindowDecoder weight raw =
      weightedWindowDecoder weight
        (fun r => (scale r : Complex) * normalized r + transport r) := by
  unfold weightedWindowDecoder
  apply Finset.sum_congr rfl
  intro r hr
  rw [hpoint r]

/-- A pointwise normalized envelope and pointwise transport bounds imply the
sharp weighted l1 uncertainty budget. -/
theorem norm_weighted_decoder_le_uncertainty
    {L : Nat} (weight : Fin L -> Complex)
    (raw normalized transport : Fin L -> Complex)
    (scale delta transportRadius : Fin L -> Real)
    (hpoint : ∀ r, raw r = (scale r : Complex) * normalized r + transport r)
    (hscale : ∀ r, 0 <= scale r)
    (hdelta : ∀ r, 0 <= delta r)
    (htransportRadius : ∀ r, 0 <= transportRadius r)
    (hnormalized : ∀ r, ‖normalized r‖ <= delta r)
    (htransport : ∀ r, ‖transport r‖ <= transportRadius r) :
    ‖weightedWindowDecoder weight raw‖ <=
      weightedUncertainty weight scale delta transportRadius := by
  rw [weighted_decoder_intertwining weight raw normalized transport scale hpoint]
  calc
    ‖weightedWindowDecoder weight
        (fun r => (scale r : Complex) * normalized r + transport r)‖
        <= ∑ r, ‖weight r *
          ((scale r : Complex) * normalized r + transport r)‖ :=
      norm_sum_le _ _
    _ <= ∑ r, ‖weight r‖ *
        (scale r * delta r + transportRadius r) := by
      apply Finset.sum_le_sum
      intro r hr
      rw [norm_mul]
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg (weight r))
      calc
        ‖(scale r : Complex) * normalized r + transport r‖
            <= ‖(scale r : Complex) * normalized r‖ + ‖transport r‖ :=
          norm_add_le _ _
        _ = scale r * ‖normalized r‖ + ‖transport r‖ := by
          rw [norm_mul, Complex.norm_of_nonneg (hscale r)]
        _ <= scale r * delta r + transportRadius r := by
          exact add_le_add
            (mul_le_mul_of_nonneg_left (hnormalized r) (hscale r))
            (htransport r)
    _ = weightedUncertainty weight scale delta transportRadius := rfl

end R2114DLeanWeightedRawNormalizedIntertwining
