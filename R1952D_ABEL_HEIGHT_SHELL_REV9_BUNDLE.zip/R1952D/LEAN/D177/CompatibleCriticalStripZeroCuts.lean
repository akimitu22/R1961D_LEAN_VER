import D167.FiniteComplexZeroRectangle
import Mathlib.Analysis.Complex.Norm
import Mathlib.Tactic.Linarith

namespace R2127DLeanCompatibleCriticalStripZeroCuts

open Metric
open R2118DLeanFiniteComplexZeroRectangle

/-- Canonical positive-ordinate critical-strip cut.  The radius `height + 1`
covers the whole rectangle `0 <= re <= 1`, `0 < im <= height`; it is not a
free certificate parameter. -/
noncomputable def positiveCriticalStripZeroCut (height : Real) : Finset Complex :=
  finiteComplexZeroRectangle (height + 1) 0 1 height

theorem critical_strip_rectangle_mem_closedBall
    {height : Real} (hheight : 0 ≤ height) {z : Complex}
    (hreLower : 0 ≤ z.re) (hreUpper : z.re ≤ 1)
    (himLower : 0 < z.im) (himUpper : z.im ≤ height) :
    z ∈ closedBall (0 : Complex) (height + 1) := by
  have hnorm : ‖z‖ ≤ height + 1 := by
    calc
      ‖z‖ ≤ |z.re| + |z.im| := Complex.norm_le_abs_re_add_abs_im z
      _ = z.re + z.im := by
        rw [abs_of_nonneg hreLower, abs_of_pos himLower]
      _ ≤ height + 1 := by linarith
  simpa [Metric.mem_closedBall] using hnorm

theorem mem_positive_critical_strip_zero_cut_iff
    {height : Real} (hheight : 0 ≤ height) {z : Complex} :
    z ∈ positiveCriticalStripZeroCut height ↔
      z ∈ riemannZetaZeros ∧
      0 ≤ z.re ∧ z.re ≤ 1 ∧ 0 < z.im ∧ z.im ≤ height := by
  rw [positiveCriticalStripZeroCut,
    mem_finite_complex_zero_rectangle_iff]
  constructor
  · intro h
    exact ⟨h.1, h.2.2⟩
  · intro h
    exact ⟨h.1,
      critical_strip_rectangle_mem_closedBall hheight
        h.2.1 h.2.2.1 h.2.2.2.1 h.2.2.2.2,
      h.2⟩

theorem positive_critical_strip_zero_cut_mono
    {height₁ height₂ : Real} (hheight₁ : 0 ≤ height₁)
    (hheight₂ : 0 ≤ height₂) (hle : height₁ ≤ height₂) :
    positiveCriticalStripZeroCut height₁ ⊆
      positiveCriticalStripZeroCut height₂ := by
  intro z hz
  have h := (mem_positive_critical_strip_zero_cut_iff hheight₁).mp hz
  apply (mem_positive_critical_strip_zero_cut_iff hheight₂).2
  exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.1, h.2.2.2.2.trans hle⟩

/-- Restricting a higher canonical cut to ordinates at most `height₁`
recovers the lower cut exactly. -/
theorem positive_critical_strip_zero_cut_restriction
    {height₁ height₂ : Real} (hheight₁ : 0 ≤ height₁)
    (hheight₂ : 0 ≤ height₂) (hle : height₁ ≤ height₂) :
    (positiveCriticalStripZeroCut height₂).filter (fun z => z.im ≤ height₁) =
      positiveCriticalStripZeroCut height₁ := by
  classical
  ext z
  simp only [Finset.mem_filter]
  constructor
  · intro h
    have hz := (mem_positive_critical_strip_zero_cut_iff hheight₂).mp h.1
    apply (mem_positive_critical_strip_zero_cut_iff hheight₁).2
    exact ⟨hz.1, hz.2.1, hz.2.2.1, hz.2.2.2.1, h.2⟩
  · intro h
    exact ⟨positive_critical_strip_zero_cut_mono hheight₁ hheight₂ hle h,
      ((mem_positive_critical_strip_zero_cut_iff hheight₁).mp h).2.2.2.2⟩

end R2127DLeanCompatibleCriticalStripZeroCuts
