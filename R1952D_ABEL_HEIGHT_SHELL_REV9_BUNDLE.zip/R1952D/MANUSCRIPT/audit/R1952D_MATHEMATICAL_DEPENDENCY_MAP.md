# R1952D Mathematical Dependency Map

> **Historical pre-TRIAL12 map.** The P5/P6 entries below describe the
> superseded scalar architecture.  The current proof uses RH closure necessity
> in the quotient and preservation of one nonzero terminal class.  This file is
> retained for provenance only.

作成日: 2026-06-22  
目的: 数式訂正後も主論文の「共通壁→N/L分岐→無限境界→反証方向」を失わず、最終定理までの依存関係を再構成する。

## 1. 状態記号

| 記号 | 状態 |
|:---:|---|
| E | exact identityとして保持できる |
| S | 構造・依存関係として保持する |
| R | corrected objectで再計算・再証明する |
| B | theorem-linkまたはbridgeを補う |
| C | 条件付きinterfaceとしてのみ使用できる |

本マップは壁を削除しない。同時に、壁の構造記述だけでRH bridgeやtotal nonvanishingを代用しない。

## 2. 全体依存図

```mermaid
flowchart TD
    A["RH-side exact Li object"] --> B["Corrected Li / Abel transport"]
    B --> C["Joint infinite-side closure target"]
    C --> D["Common fixed-height obstruction wall"]
    D --> E["N/L exhaustive interface"]
    E --> F["N: exact-character packet"]
    E --> G["L: independent lower envelope"]
    F --> H["Total obstruction audit"]
    G --> H
    H --> I["Closure failure or valid discharge"]
    I --> J["Infinite-side theorem-link"]
    D --> K["Refutation-side witness lane"]
```

この図の `D` は研究史上の中心である。`B`, `C`, `E`, `H`, `J` は、局所核訂正後に同じ対象・同じ尺度で再接続しなければならない。

## 3. 最終結論までに区別する六命題

| ID | 命題 | 元稿・供給元 | 状態 | 必要作業 |
|---|---|---|:---:|---|
| P1 | Route-return: 対象routeが共通interfaceへ戻る | Secs. 13, 27--42; R1857D 797--943; 三図 | S/R | corrected carrierを保った各routeの再検証 |
| P2 | Endpoint necessity: fixed-height endpointが当該RH-side reassemblyに必要 | Secs. 5--8, 14, 44--51; R1857D 5515--5583 | S/B | corrected Abel objectからnecessityを再証明 |
| P3 | Route exhaustiveness: 対象endpoint routeをN/Lが尽くす | Secs. 9--12, 36--38, 46; R1857D 952--1029 | S/B | construction-relative範囲とglobal範囲を明記 |
| P4 | Corrected transport: 訂正後も同じendpoint objectへ運ばれる | corrected Sections 4--5 | R | weight、Jacobian、transition、scaleを全伝播 |
| P5 | RH bridge: RHならcorrected total obstructionがjoint regimeで消える | 旧Thm. 5.10; Thm. 2.1; Prop. 51.1 | B | fixed-`n`回復とは別の一様定理を構築 |
| P6 | Obstruction: 同じ総量・同じ尺度で非消滅する | Secs. 12, 15--18, 41, 45; N/L ledger | R/B | 個別classでなくorbit-completed totalを評価 |

最終的なRH反証定理には P1--P6 がすべて必要である。P1--P3は壁の構造として保持し、P4--P6を補強して接続する。

## 4. Exact Li / Abel chain

### 4.1 保持するexact identities [E]

RH下で $\rho=\tfrac12+iT$ とし、

\[
\theta_n(T)=2n\arctan\frac1{2T},\qquad
H_n(T)=2[1-\cos\theta_n(T)].
\]

\[
K_n^{\mathrm{Li}}(T)=\frac{8n}{4T^2+1}\sin\theta_n(T),
\qquad H_n'(T)=-K_n^{\mathrm{Li}}(T).
\]

\[
\lambda_n
=\int_0^\infty H_n(T)\,dN(T)
=\int_0^\infty K_n^{\mathrm{Li}}(T)N(T)\,dT.
\]

位相変数

\[
u=\theta_n(T),\qquad T_n(u)=\frac12\cot\frac{u}{2n}
\]

では

\[
P_n(u)=2(1-\cos u),\qquad
K_n^{\mathrm{Li}}(T_n(u))[-T_n'(u)]=2\sin u=P_n'(u),
\]

したがって

\[
\lambda_n=2\int_0^{n\pi}N(T_n(u))\sin u\,du.
\]

### 4.2 cutoff後のexact identity [E]

zero-measure levelでcutoffを入れる場合、

\[
W_{n,\sigma}^{\mathrm{corr}}(u)
=\frac{d}{du}\{a_\sigma(u)P_n(u)\}
=2a_\sigma(u)\sin u+2a_\sigma'(u)(1-\cos u).
\]

指数cutoff $a_\sigma=e^{-\sigma u}$ なら

\[
W_{n,\sigma}^{\mathrm{corr}}(u)
=4e^{-\sigma u}\sin\frac u2
\left(\cos\frac u2-\sigma\sin\frac u2\right).
\]

その零点は

\[
u=2\pi j,
\qquad
u=(2j+1)\pi-2\arctan\sigma.
\]

したがって次を分離する。

| 対象 | cell / sign band |
|---|---|
| primitive phase $P_n'(u)=2\sin u$ | $k\pi<u<(k+1)\pi$ |
| corrected cutoff weight $W_{n,\sigma}^{\mathrm{corr}}$ | 上記のshifted zerosで区切る |

### 4.3 joint-limit firewall [R/B]

\[
\|e^{-\sigma u}-1\|_{[0,n\pi],\infty}
=1-e^{-\pi n\sigma}.
\]

- 固定 $n$, $\sigma\to0$: 回復可能。
- $n\sigma\to\infty$: 上式は1へ行く。

ゆえに、旧Thm. 5.10に相当するRH bridgeは、fixed-index Abel recoveryからは得られない。joint regime専用の一様評価を独立に置く。

## 5. 共通壁へのroute-return

| Route | 壁へ戻る対象 | 元稿アンカー | 訂正後の監査 |
|---|---|---|---|
| fixed-height recombined margin | returned carrier shell / TP-C endpoint | R1857D fixed-height aggregation | corrected weightから同じcarrierが生成されること |
| phase oscillation / Stieltjes | boundary-transition functional | Secs. 29--31, 37.2, 37.5 | cutoff sign bandsとtransition termの再計算 |
| Li / Bombieri--Lagarias | identity-preservation burden | Secs. 5, 44, 51; R1857D E1 | $H_n\,dN$ と $K_nN\,dT$ のlevel discipline |
| off-line / negative witness | witness lane、または未供給証明route | R1857D 5584以降 | proof-direction N/Lとrefutation-directionを混同しない |
| DOR / A-part | finite-height input / linkage / anchor | R1857D fixed-height chain | anchor・linkage損失をledgerへ明示 |
| explicit formula / Selberg--Tsang | prime packetまたはzero packet | Secs. 32--35, 37.3--37.9, 42 | packet transferが消滅証明でないこと |

### 壁の厳密なclaim boundary

1. 各routeが、保存対象を変えずに共通interfaceへ戻ることを示す。
2. fixed-height TP-C endpointが、対象とするreassemblyで不可欠であることを示す。
3. N/Lが、そのendpointを閉じるrouteを尽くす範囲を明示する。
4. construction-relativeなreturn theoremを、無条件のglobal impossibilityと同一視しない。

ここでroute中の壁は複層であり、同一のfunctionalとは限らない。各層の
boundary、prime packet、zero packet、transition、edge、remainderを完全ledger
として保持し、層間decoderとdescendant detectorにより非消滅を伝播する。共通なのは
終端interfaceであって、中間壁そのものではない。

これは壁を弱めるための限定ではなく、壁を最終定理へ正確に接続するための定義域である。

## 6. N branch

### 6.1 exact-character packet [C/R]

\[
\mathcal P_N(n;H_0)
=\sum_{\chi\in\mathfrak X(H_0)}
A_\chi(n;H_0)\Phi_\chi(n;H_0).
\]

R1857Dはこのfinite-packet representationと係数nullity obligationを供給する。ただし、representationの一意性、$\mathfrak X(H_0)$ のcanonicity、$\Phi_\chi$ の独立性は自動ではない。

### 6.2 exact-beta class [R]

\[
\mathcal B(\beta_*)=\{d:\beta_d=\beta_*\},\qquad
A_{\mathcal B}=\sum_{d\in\mathcal B(\beta_*)}a_d,
\]

\[
C_{\mathcal B}=(\beta_*-1)^2A_{\mathcal B}.
\]

orbit completionは

\[
C_{\mathrm{orb}}(\rho)
=\sum_{q\in\mathcal Q(\rho)}C_{\mathcal B(q)}.
\]

検査順序は固定する。

1. concrete $\beta$-classを抽出する。
2. same-exact-$\beta$ の $a_d$ を合算し、duplicationを自動相殺とみなさない。
3. $A_{\mathcal B}$ と $C_{\mathcal B}$ を計算する。
4. conjugation/reflection等を含むorbit completionを行う。
5. $C_{\mathrm{orb}}$ の総寄与を評価する。
6. exceptional valid $A_d=0$ mechanismを個別に検査する。
7. 個別classの非零からtotal nonvanishingを推論しない。

### 6.3 N側の判定対象

canonical coreの蓄積が残る場合でも、結論は次の二つに分ける。

| 判定 | 必要証拠 |
|---|---|
| canonical N core blocked | same-exact-beta accumulationとorbit-completed totalの非消滅 |
| exceptional N mechanism valid | 具体的な $A_d=0$ mechanismと全linkageの証明 |

## 7. L branch

LはNの失敗から自動的に得られず、独立exact-carrier lower envelopeである。

\[
M_{\mathrm{LE}}(n;H_0)
\ge \operatorname{Err}_{\mathrm{NL}}^{\mathrm{tot}}(n;H_0).
\]

全損失は少なくとも

\[
\begin{aligned}
\operatorname{Err}_{\mathrm{NL}}^{\mathrm{tot}}
={}&\operatorname{Err}_{\mathrm{pkt}}^{-}
+\operatorname{Err}_{\mathrm{res}}
+\operatorname{Err}_{\mathrm{anc}}\\
&+\operatorname{Err}_{\mathrm{link}}
+\operatorname{Err}_{\mathrm{book}}
+\operatorname{Err}_{\mathrm{norm}}.
\end{aligned}
\]

| 条件 | 理由 |
|---|---|
| comparison scaleを事前固定 | post hocな尺度選択を防ぐ |
| 全損失を一度だけ計上 | omissionとdouble countingを防ぐ |
| residual-only boundをfull Lとしない | anchor/linkage/packet/normalizationが残るため |
| RHを仮定しない | RH結論への循環を防ぐ |
| Li positivityを仮定しない | criterion-side結論への循環を防ぐ |
| equivalent positivityを仮定しない | 名前を変えた循環を防ぐ |

R1857DはL branchのinterfaceとledgerを供給するが、lower-envelope estimateそのものは供給していない。

## 8. 元稿定理階層の再接続

| 元稿の層 | 元稿アンカー | 訂正後に前置する依存 |
|---|---|---|
| Main A: closure necessity | Thm. 2.1; Thm. 5.10 | corrected Li/Abel identity + joint-limit bridge |
| Main B: coherent normal form | Thm. 2.2; Thm. 9.10; Thm. 11.1 | corrected structural support + route domain |
| Main C: terminal rigidity | Thm. 2.3; Thm. 12.7; Thm. 17.6 | N/L total ledger + total, not componentwise, obstruction |
| Main D: contradiction | Thm. 2.4; Cor. 2.15; Thm. 3.1 | P1--P6すべて |
| operational recurrence | Thms. 13.2, 36.4, 37.6, 38.1 | corrected carrier-preserving branch transport |
| quantified closure | Lemma 45.2; Cor. 41.1 | corrected boundary scaleとactual sign bands |

### 新しい証明順序

```mermaid
flowchart TD
    A["Exact zero-pair identity"] --> B["Corrected Abel identity"]
    B --> C["Uniform joint-limit theorem"]
    C --> D["Corrected closure necessity"]
    D --> E["Route-return theorem"]
    E --> F["Endpoint necessity"]
    F --> G["N/L exhaustiveness"]
    G --> H["N-or-L audit"]
    H --> I["Total obstruction theorem"]
    I --> J["Infinite-side conclusion"]
```

## 9. Total obstruction

最終的に評価すべき対象は、個別terminalではなく同一joint regime・同一scaleでの総量である。記号は完全LaTeX化時に統一するが、必要な形は

\[
\mathcal O_{n,\sigma}^{\mathrm{tot}}
=\mathcal B_{n,\sigma}^{\mathrm{corr}}
+\mathcal E_{\mathrm{trans}}
+\mathcal E_{\mathrm{pkt}}
+\mathcal E_{\mathrm{edge}}
+\mathcal R_{\mathrm{low}}.
\]

必要な定理は、単なる

\[
[P]\ne0,\quad [Z]\ne0,\quad [E^\partial]\ne0
\]

ではなく、許される相互相殺、same-beta accumulation、orbit completion、全損失を含めた後の

\[
\limsup_{(n,\sigma)\to\mathcal J}
\frac{|\mathcal O_{n,\sigma}^{\mathrm{tot}}|}
{B_{n,\sigma}^{\mathrm{corr}}}>0
\]

またはそれと同値な非消滅命題である。ここで $\mathcal J$ は明示されたjoint regimeでなければならない。

## 10. Refutation lane

refutation-directionはN/L proof-directionを置換しない。壁が無限境界と結び付いた後の独立laneとして置く。

固定高で、外向き丸め上界が

\[
M_n(H_0)\le\overline M_n(H_0),\qquad
E_n(H_0)\le\overline E_n(H_0)
\]

を満たし、

\[
\overline M_n(H_0)+\overline E_n(H_0)
+\varepsilon_{\mathrm{cert}}(n,H_0)<0
\]

なら $\lambda_n<0$ である。packet版では

\[
P_{\mathcal P}(H_0)
=\sum_j\omega_j
\left(\overline M_{n_j}+\overline E_{n_j}
+\varepsilon_{\mathrm{cert},j}\right)<0,
\qquad \omega_j\ge0,
\]

からpacket内の少なくとも一つの負Li係数が従う。named witnessには別のsingle-index localization certificateが必要である。

現資料にはcertified negative witnessは存在しないため、このlaneはinterfaceとして回収する。

## 11. 優先証明課題

| 優先 | 課題 | 完了条件 |
|---:|---|---|
| 1 | corrected downstream search | 旧kernel、旧weight、旧scale、旧cell使用箇所を全件分類 |
| 2 | corrected carrier transport | 各branchが同一endpoint objectへ到達する式を確定 |
| 3 | joint-limit theorem | fixed-`n`回復に依存しない一様評価を証明 |
| 4 | endpoint necessity | RH-side closure targetからfixed-height endpointへのbridgeを確定 |
| 5 | N/L exhaustiveness | 対象route universeと除外条件を明示して証明 |
| 6 | N beta/orbit audit | exact-beta class、$A_{\mathcal B}$、$C_{\mathrm{orb}}$、exceptional $A_d=0$ を評価 |
| 7 | L lower envelope | RH/Li positivity非依存で全損失を支配 |
| 8 | total nonvanishing | component cancellationを含む総量下界を証明 |
| 9 | final theorem relink | Thms. 2.1--3.1と後続参照を新しいlabel/refで接続 |

## 12. 現時点の判定

- 壁、route-return、N/L分岐、fixed-height endpoint、refutation laneは主論文の中心構造として回収対象に確定した。
- corrected Li/Abel identitiesは回収できる。
- 100頁元稿の定理階層も回収できる。
- 完成したRH反証を再主張するには、corrected transport、joint-limit RH bridge、N/L exhaustiveness、total obstruction theoremを同一対象上で接続する必要がある。
- corridor、Gram、凸分離等は補助検査に留め、中心構造を置換しない。
