# R1952D Source Recovery Map

> **Historical source-recovery document.** Completion estimates and gap
> statements below record the state before the TRIAL12/TRIAL13 proof-
> architecture restoration.  They do not define the current claim status.

作成日: 2026-06-22  
対象: `R1952D` 主論文の完全LaTeX再構築前監査  
状態: 回収設計完了。完全LaTeX本文はまだ作成していない。

## 1. 結論

- 元100頁PDFの全100頁からレイアウト保持テキストを抽出できた。
- 目次上の Sections 1--63、参考文献、146個の番号付き命題類、195個の一意な番号付き表示式ラベルを検出した。
- Sections 4--5には意味的LaTeXが存在するが、その内部にも一般cutoffの符号帯とjoint limitに関する再修正箇所がある。
- R1857Dは100頁本文の代替ソースではない。N/L壁、全損失ledger、fixed-height endpoint、refutation laneの供給源として限定使用する。
- 100頁本文の意味的回収見通しは93--96%である。これは完成率ではなく、既存PDF・部分LaTeX・R1857Dから第一稿を再構築できる見込みである。数式の4--7%は原PDF画像との手動照合が必要である。

## 2. 権威ファイル

| 優先 | 資料 | 検査結果 | 使用範囲 |
|---:|---|---|---|
| 1 | `original/R1952D_MAIN_ORIGINAL.pdf` | 100頁、SHA-256 `923798705...1495`、33,008語抽出 | 原題、研究史、Sections 1--63、全体の意味的基準 |
| 2 | `baseline/R1952D/MANUSCRIPT/pdf/R1952D_MAIN.pdf` | 100頁、SHA-256 `b4b175f0...48fb` | 訂正後の外形基準。ただし19--100頁は旧PDF埋込み |
| 3 | `baseline/R1952D/MANUSCRIPT/source/R1952D_Sections_4_5.tex` | 573行、1,992語 | Li零点対、Stieltjes、Jacobian、corrected Abel weightの直接LaTeX供給元 |
| 4 | `corrected62/MANUSCRIPT/reference/R1857D_main_manuscript_current.tex` | 7,144行、48,786語、SHA-256 `323129fd...c33f` | N/L壁とfixed-height/refutation部分のみ回収 |
| 5 | `corrected62/MANUSCRIPT/source/*.tex` | corridor中心の62頁版 | 監査メモと失敗条件の参照のみ。投稿本文の基準にしない |

元PDFと `R1952D_MAIN_Previous.pdf` は抽出テキストが同一である。復旧100頁版は、実質的に前付けとSections 4--5のみを差し替えた版である。

## 3. 回収区分

| 区分 | 意味 | 対象 |
|---|---|---|
| A | 直接LaTeXを回収し、局所訂正後に使用 | Sections 4--5の訂正核 |
| B | 原PDFから意味と構造を忠実に再構築 | Sections 1--3, 6--63 |
| C | R1857Dから限定移植し、R1952Dへ統合 | N/L interface、ledger、endpoint、refutation lane |
| D | 構造のみ保持し、定量部を再証明 | boundary scale、sign band、packet、terminal obstruction、joint limit |
| X | 投稿本文には再利用しない | 62頁corridor再分類、PDF貼合せ版、却下済み生成物 |

## 4. Sections 1--63 回収表

| Sec. | 原題（要約せず原目次準拠） | 原頁 | 回収 | 主要アンカー／処置 |
|---:|---|---:|:---:|---|
| 1 | Scope: infinite-side contradiction, not a finite Li route | 8 | B | (1.1)--(1.2)。研究方針転換を追記するが、finite-Li中心へ変更しない |
| 2 | Hierarchy of the main results | 8 | B+C | Thms. 2.1--2.4、Props. 2.5--2.14、Cor. 2.15。N/L壁を階層へ追加 |
| 3 | Main Infinite-Side Contradiction | 11 | B+D | Thm. 3.1、Cor. 3.2。corrected transport/RH bridge/total nonvanishingへ再接続 |
| 4 | The actual Li kernel and phase coordinate | 12 | A | 旧(4.1)--(4.6)を廃止し、`H_n`, `K_n^{Li}`, Jacobian付きphase identityへ置換 |
| 5 | Exact Li-boundary identity and closure necessity | 13 | A+D | 旧Lemmas 5.1--5.7, Thm. 5.10の役割を訂正核から再構成。後続の `Theorem 5.10` 参照を復活 |
| 6 | Asymptotic regime and closure topology | 18 | B+D | (6.1)--(6.7)。旧boundary scaleをcorrected weightから再推定 |
| 7 | RH-internal admissible class | 20 | B+D | Def. 7.1、Prop. 7.2。RH bridgeの循環性監査 |
| 8 | Detailed RH-internal admissibility | 21 | B+D | Lemma 8.1、Prop. 8.2、Lemma 8.3。actual sign bandsとの整合を修正 |
| 9 | Coherent actual Li-boundary closure without terminal axiom | 24 | B+D | Def. 9.1、Prop. 9.2、Lemmas 9.5--9.8、Thms. 9.7--9.12 |
| 10 | Formal RH-internal generator algebra | 30 | B+D | Defs. 10.1--10.4、Lemmas 10.5--10.6、Prop. 10.7 |
| 11 | Completeness of the RH-internal Li-boundary mechanism | 33 | B+D | Thm. 11.1。global exhaustivenessとconstruction-relative wallを区別 |
| 12 | Obstruction quotient and admissible closure | 34 | B+D | (12.1)--(12.3)、Lemma 12.5、Thm. 12.7。componentwiseからtotalへの飛躍を禁止 |
| 13 | Boundary recurrence theorem | 36 | B+D | Def. 13.1、Thm. 13.2。corrected carrierで再証明 |
| 14 | Infinite-side closure criterion | 37 | B+D | Defs. 14.1--14.2、Lemma 14.3、Prop. 14.5。旧scaleを再計算 |
| 15 | Terminal obstruction non-production and non-absorption | 39 | B+D | Thms. 15.2--15.6、Cor. 15.7。総量・同一尺度の評価を追加 |
| 16 | Terminal theorem normal forms and terminal ideal rigidity | 42 | B+D | Defs. 16.1, 16.3、Lemmas 16.2, 16.4、Thms. 16.5--16.7 |
| 17 | Terminal class non-vanishing in the actual obstruction quotient | 44 | B+D | Lemmas 17.1--17.5、Thms. 17.6--17.7。個別非零だけでは不足 |
| 18 | Prime-zero branch rigidity of terminal quotients | 47 | B+C+D | Lemmas 18.2--18.4、Thm. 18.5、Props. 18.6, 18.8。N/L interfaceへ接続 |
| 19 | Artificial escape classes | 51 | B | Def. 19.1、Prop. 19.2。補助分類として保持 |
| 20 | Exclusion I: interior-stationary escape | 52 | B+D | Thm. 20.1。corrected phaseで再点検 |
| 21 | Exclusion II: endpoint compensation | 53 | B+D | Prop. 21.1。endpoint scaleを再推定 |
| 22 | Exclusion III: short-prime-packet escape | 54 | B+D | Thm. 22.1。独立算術入力の境界を保持 |
| 23 | Exclusion IV: zero-phase escape | 54 | B+D | Thm. 23.1。密度と位相相殺を区別 |
| 24 | Exclusion V: Li-cell deformation | 54 | B+D | Thm. 24.1。primitive cellsとcutoff sign bandsを区別 |
| 25 | Expanded exclusion of artificial escapes | 55 | B+D | Props. 25.1, 25.3, 25.5、Lemmas 25.2, 25.4 |
| 26 | Proof of the main theorem | 58 | B+D | 新しいtheorem-link完成後にのみ再組立 |
| 27 | Condensed technical chain | 58 | B | 八branchへの導入 |
| 28 | Branch 1: Continuous prime-phase integral | 58 | B+D | (28.1)、carrier-preserving transport再確認 |
| 29 | Branch 2: Boundary-transition kernel | 59 | B+D | (29.1)、corrected transition termを使用 |
| 30 | Branch 3: Stieltjes smoothing window collapse | 59 | B+D | (30.1)、joint limit一様性を再証明 |
| 31 | Branch 4: Bandlimited endpoint substitute | 59 | B+D | (31.1)、leakage scale再推定 |
| 32 | Branch 5: Zero-side resonance packet | 60 | B+D | (32.1)、packet scale再推定 |
| 33 | Branch 6: Riemann--von Mangoldt density branch | 60 | B+D | (33.1)、density/fluctuation分離 |
| 34 | Branch 7: Selberg--Tsang return | 61 | B+D | (34.1)、prime returnをwallへ接続 |
| 35 | Branch 8: Resonant prime packet | 61 | B+D | (35.1)、exact-carrier ledgerへ接続 |
| 36 | Generated-chain recurrence theorem | 61 | B+D | Defs. 36.1--36.3、Thm. 36.4、Cor. 36.5。route-return証明の中心 |
| 37 | Generator-by-generator proof details | 65 | B+D | Lemmas/Props. 37.1--37.5、Thm. 37.6。旧amplitude依存を全検索 |
| 38 | Expanded proof of the generated no-escape theorem | 69 | B+D | Thm. 38.1。generator exhaustivenessの範囲を明記 |
| 39 | Submission-level branch normal forms | 71 | B+D | (39.1)--(39.11)。全branchのcorrected normal form |
| 40 | Condensed branch table | 73 | B | 表を単一LaTeXで再作成 |
| 41 | Effect on the infinite-side closure condition | 74 | B+D | Cor. 41.1、(41.1)。corrected totalへ置換 |
| 42 | Single-pass technical proof library | 75 | B+D | Lemmas/Props. 42.1--42.7、(42.1)--(42.18)。最重要再計算域 |
| 43 | Why the clean version is shorter | 79 | B | 研究史として保持。削除理由の過大主張を避ける |
| 44 | Expanded core proof of RH-internal admissibility | 79 | B+D | Prop. 44.1、(44.1)--(44.2)。RH bridge監査 |
| 45 | Expanded closure criterion | 81 | B+D | Def. 45.1、Lemma 45.2、(45.1)--(45.5)。総obstruction化 |
| 46 | Exhaustiveness of the five artificial escapes | 82 | B+D | Thm. 46.1。global exhaustivenessとは区別 |
| 47 | Submission-oriented logical map | 84 | B+C | N/L壁とrefutation laneを含む図へ更新 |
| 48 | Detailed branch derivations without repeated passes | 84 | B+D | Prop. 48.1、(48.1)--(48.16)。定量再推定域 |
| 49 | Scale ledger and non-internal alternatives | 87 | B+D | 全損失ledgerと対応させる |
| 50 | Scale ledger for the submitted proof | 88 | B+D | (50.1)--(50.5)。旧boundary/transition/packet/endpoint scaleを更新 |
| 51 | Expanded derivation of RH-internal closure necessity | 89 | B+D | Prop. 51.1。fixed-`n`からjoint limitへの飛躍を禁止 |
| 52 | Detailed generated-chain verification table | 90 | B+D | generatorごとのcorrected carrierと損失を表形式で再生成 |
| 53 | Expanded finite versus infinite distinction | 91 | B | (53.1)。finite negativityを主論証にしない |
| 54 | Review checklist for the main theorem | 92 | B+C | six-link auditを追加 |
| 55 | Technical estimates supporting the generated proof | 92 | B+D | Lemma 55.1、(55.1)--(55.11)。定量再証明域 |
| 56 | Reader-oriented proof skeleton | 95 | B+C | wall/N/L/無限境界の読者向け依存順序へ更新 |
| 57 | Appendix A: exact kernel identities retained in the structural version | 95 | B+D | (57.1)--(57.2)をcorrected identitiesへ差替え |
| 58 | Appendix B: monotone phase estimates | 96 | B+D | (58.1)--(58.2)、carrier再確認 |
| 59 | Appendix C: Stieltjes and bandlimited window failures | 96 | B+D | (59.1)--(59.2)、joint limit条件を追加 |
| 60 | Appendix D: zero and prime packet duality | 97 | B+D | (60.1)--(60.2)、N/L packetとの関係を明記 |
| 61 | Appendix E: exact reading of the conclusion | 97 | B+C | 壁の構造命題とRH反証命題を分離 |
| 62 | Non-circularity and review-sensitive points | 97 | B+C+D | Props. 62.1--62.4。L-route非循環性とRH bridgeを追加 |
| 63 | Final summary | 99 | B+C | proof-direction wallからrefutation-directionへの転換を明示 |

## 5. 定理在庫

元100頁PDFから一意に検出した番号付き命題類は146個である。

| 種類 | 数 |
|---|---:|
| Theorem | 30 |
| Proposition | 42 |
| Lemma | 36 |
| Definition | 25 |
| Corollary | 5 |
| Remark | 8 |

最上位の回収アンカーは次である。

| 役割 | 元稿アンカー | 回収後の扱い |
|---|---|---|
| closure necessity | Thm. 2.1; Thm. 5.10; Prop. 51.1 | corrected finite-to-Abel transportとjoint-limit bridgeから再証明 |
| coherent normal form | Thm. 2.2; Thms. 9.7, 9.9, 9.10; Thm. 11.1 | construction-relativeとglobal exhaustivenessを分離 |
| obstruction/terminal rigidity | Thm. 2.3; Thm. 12.7; Thms. 15.2--18.5 | total obstructionの同一尺度非消滅を補う |
| contradiction | Thm. 2.4; Cor. 2.15; Thm. 3.1 | six-link dependencyが揃うまで最終結論を確定しない |
| route return | Thm. 13.2; Thm. 36.4; Thm. 37.6; Thm. 38.1 | corrected carrier-preserving transportで再検証 |
| escape classification | Prop. 19.2; Thms. 20.1--24.1; Thm. 46.1 | 補助監査。N/L壁の代替にしない |

## 6. 表示式在庫

PDF抽出では200件の番号らしい出現を検出し、本文中の重複参照を除くと195個の一意なラベルを確認した。主要範囲は次のとおりである。

| 範囲 | 個数 | 状態 |
|---|---:|---|
| (1.1)--(2.1) | 3 | 構造保持 |
| 旧(4.1)--(5.9) | 14 | 入口式として廃止し、訂正核へ置換 |
| (6.1)--(18.7) | 52 | corrected scale/quotientへ再接続 |
| (19.1)--(25.6) | 14 | phase・packet・endpointを再推定 |
| (28.1)--(42.18) | 62 | branch transportの主要再計算域 |
| (44.1)--(60.2) | 50 | closure、ledger、appendix整合を再検証 |

### 訂正核として採用する式

\[
H_n(T)=2[1-\cos\theta_n(T)],\qquad
K_n^{\mathrm{Li}}(T)=\frac{8n}{4T^2+1}\sin\theta_n(T),\qquad
H_n'(T)=-K_n^{\mathrm{Li}}(T).
\]

\[
\lambda_n=\int_0^\infty H_n(T)\,dN(T)
=\int_0^\infty K_n^{\mathrm{Li}}(T)N(T)\,dT.
\]

\[
K_n^{\mathrm{Li}}(T_n(u))[-T_n'(u)]=2\sin u,
\qquad
\lambda_n=2\int_0^{n\pi}N(T_n(u))\sin u\,du.
\]

\[
W_{n,\sigma}^{\mathrm{corr}}(u)
=\frac{d}{du}\{a_\sigma(u)P_n(u)\}
=2a_\sigma(u)\sin u+2a_\sigma'(u)(1-\cos u).
\]

指数cutoffでは、actual sign-bandの零点は $u=k\pi$ だけではない。固定 $n$ のAbel回復も、$n\sigma\to\infty$ のjoint limitへ一様には移せない。

## 7. R1857D限定回収表

| 行 | 内容 | R1952Dでの役割 |
|---:|---|---|
| 797--943 | C-NLS cutoff transferとconstruction-relative wall return | 各routeから壁へのreturn分類 |
| 952--1029 | N/L boundary normal form、N packet、独立L、非循環性 | 壁の中核 |
| 1032--1149 | returned-shell packet、exact-character packet、total majorant | N/L interfaceの具体化 |
| 1154--1439 | packet negative pressure、全損失ledger、lower-envelope dominance | L branchの損失帳簿 |
| 5515--5583 | fixed-height current endpoint、N/L局在化 | endpoint theoremとclaim boundary |
| 5584以降 | PALWおよびLi-negative witness lane | refutation-directionの独立節 |

R1857Dの題名、claim-neutral結論、別研究史は移植しない。N/Lも現状のままではclosure theoremではないため、R1952DのRH bridgeを代用しない。

## 8. 回収率と次工程判定

| 指標 | 結果 |
|---|---:|
| PDF頁の抽出可能性 | 100/100頁 |
| Section見出し | 63/63 |
| 番号付き命題類 | 146件検出 |
| 一意な番号付き式 | 195ラベル検出 |
| 直接使用可能な訂正LaTeX | Sections 4--5中心、約1,992語 |
| N/L供給LaTeX | 必要ブロック実在、ただし限定移植 |
| 第一稿の意味的回収見通し | 93--96% |

したがって、大規模な単一ソース化へ進むための「90%以上の意味的回収見通し」は満たす。ただし、これは数学的正当性93--96%を意味しない。数学的には、corrected transport、joint limit、N/L exhaustiveness、RH bridge、total obstruction nonvanishingが未検証である。

## 9. 完全LaTeX作成時の禁止事項

1. 本文PDFを `\includepdf` で埋め込まない。
2. 62頁corridor版を主本文へ移植しない。
3. Sections 4--5の訂正LaTeXを無批判に採用しない。
4. `Theorem 5.10` を欠番のまま後続節へ残さない。
5. primitive phase cellとcorrected cutoff weightのsign bandを同一視しない。
6. fixed-`n` dominated convergenceをjoint infinite limitへ流用しない。
7. 個別terminal classの非零からtotal obstructionの非零を結論しない。
