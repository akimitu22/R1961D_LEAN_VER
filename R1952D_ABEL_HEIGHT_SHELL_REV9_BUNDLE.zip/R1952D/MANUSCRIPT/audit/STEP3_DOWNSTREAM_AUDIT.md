# R1952D step 3 downstream audit

> **Historical document.** This audit predates the TRIAL12/TRIAL13
> proof-architecture restoration.  Its scalar uniform-bridge and total-
> obstruction requirements are not gates in the current complete-ledger
> terminal-class proof.  See
> `AUDIT/HISTORICAL/TRIAL13_CORRECTNESS_REPAIR.md` for the
> current claim boundary.

## Scope

This audit covers propagation of the corrected Sections 4--5 objects through
the 63-section LaTeX manuscript and integration of the common wall, N/L
interface, and refutation-side witness lane.

## Search results and disposition

| Search target | Result after edits | Disposition |
|---|---:|---|
| `K_n^{Li}` used directly against `dN` as a Li coefficient | 0 operative uses | The two remaining occurrences in Sections 4--5 explicitly identify the operation as a different functional. |
| Legacy `B^partial`, bold `B_partial`, or uncorrected `B_{n,sigma}` glyphs | 0 | Replaced by `B_{n,sigma}^{corr}` or a native corrected total expression. |
| Jacobian-free use of `D_n` as the phase density | 0 operative uses | `D_n` remains only as the auxiliary transported density-kernel value in Sections 4--5. |
| Canonical cells asserted to be the full cutoff sign bands | 0 | Primitive cells and cutoff sign bands are separated in Sections 4--5 and the downstream conventions. |
| Fixed-index dominated convergence used as a joint-limit theorem | 0 | The firewall is stated in Section 5 and repeated in Sections 2, 12, 44, 51, and 53. |
| Individual terminal nonvanishing used as total nonvanishing | 0 in the revised theorem spine | Sections 12, 14, 17, 18, 41, and 45 require a total same-regime estimate. |
| Missing `Theorem 5.10` | 0 | The conditional corrected closure interface is present and cross-referenced. |

## Integrated wall and N/L material

Section 12 now contains:

- corrected obstruction quotient and comparison topology;
- construction-relative corrected route universe;
- fixed-height route-return normal form;
- endpoint-necessity obligation;
- exact-character packet and Hypothesis N;
- exact-beta class accumulation and orbit completion;
- exceptional zero-coefficient guard;
- Hypothesis L as an independent exact-carrier lower envelope;
- packet, residual, anchor, linkage, bookkeeping, and normalization losses;
- normalized sufficient L-side comparison template;
- construction-relative N/L exhaustiveness theorem;
- corrected total obstruction and same-regime limsup target.

Section 18 separately restores the fixed-height and packet-amplified certified
negative-witness interfaces. No witness instance is asserted.

## Main theorem relinking

The main hierarchy now distinguishes six links:

1. corrected route-return;
2. fixed-height endpoint necessity;
3. construction-relative N/L exhaustiveness;
4. corrected carrier transport;
5. uniform RH-to-closure bridge;
6. total corrected obstruction in the same regime.

Sections 2--3 state the final contradiction only conditionally on all six
links. Sections 7, 9, 15--18, 26, 41, 44--45, 47, 51, 53--54, 56, and 61--63
were synchronized with that dependency boundary.

## Analytic obligations not evaluated in step 3

- A uniform joint-limit RH bridge independent of fixed-index Abel recovery.
- Branch-by-branch quantitative reconstruction from the corrected weight.
- Proof that the selected fixed-height endpoint is necessary for the full
  corrected reassembly.
- Concrete evaluation of `A_chi`, exact-beta classes, orbit totals, and every
  exceptional zero-coefficient mechanism.
- An RH- and Li-positivity-independent L-side lower envelope.
- A complete numerical or analytic evaluation of every ledger component.
- A same-regime lower bound for the total corrected obstruction.
- A certified finite negative Li witness.

These are retained as explicit theorem obligations rather than reported as
completed results.
