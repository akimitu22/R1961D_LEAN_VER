# Current manuscript status

TRIAL18 adds the full finite-packet Ces\`aro estimate to the typed finite Li
witness framework.

Proved in the manuscript and Lean interface:

- one typed record fixes every finite scale parameter;
- exact cut and three-component remainder decomposition use the same record;
- component disks assemble to the aggregate remainder disk;
- the same-witness data compile to the D159 finite margin certificate;
- D161 proves the selected-mode identity and the full nonselected-mode
  `K/L` estimate uniformly in the starting index;
- a positive compiled certificate conditionally implies `not RH`.

Not proved: construction of the record from an admissible asymptotic scale law,
concrete actual-Li component bounds, or a positive margin. No unconditional RH
conclusion is claimed.
