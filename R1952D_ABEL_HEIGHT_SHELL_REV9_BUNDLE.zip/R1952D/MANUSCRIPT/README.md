# R1952D complete LaTeX source recovery

The root source is `source/R1952D_MAIN.tex`. Sections 1--63 are stored as
individual files in `source/sections`. The title, abstract, table of contents,
body, theorem structures, equation numbering, cross-references, and bibliography
are generated from one LaTeX root. No manuscript page uses `\includepdf`.

Build with:

```sh
cd source
latexmk -xelatex -interaction=nonstopmode -halt-on-error R1952D_MAIN.tex
```

The verified PDF is `output/pdf/R1952D_MAIN.pdf`. See `RECOVERY_STATUS.md` for
the source-recovery boundary, `STEP3_STATUS.md` for the corrected downstream
integration status, and `audit/STEP3_DOWNSTREAM_AUDIT.md` for the detailed
search and claim audit.
