# TRIAL15 sliding Cesaro detector audit

Date: 2026-06-23

## Main change

The original fixed-height scalar carrier is written exactly as
`X = P + E_cut`. The main detector is

```text
A_(N,L)(x) = (1/L) sum_(r<L) beta_*^(-(N+r)) x_(N+r).
```

For the finite raw packet, the selected mode contributes exactly `C_*` and
the remaining modes contribute `O(1/L)`, uniformly in the starting index.

## Removed proof gates

- pointwise smallness of every remainder component;
- coordinatewise direct-sum faithfulness;
- global phase rotation and sector decomposition;
- six separate absolute loss estimates.

## Remaining analytic bridge

On one explicit cofinal path, RH must imply both the detector mean of `X` and
the detector mean of `E_cut` tend to zero. The detector algebra and the
conditional contradiction are proved; these two concrete Li-analytic limits
are not proved.

## Lean scope

The new D158 module formalizes the finite detector algebra and conditional
limit contradiction without adding `axiom`, `sorry`, or `admit`. The actual Li
integral estimates remain outside the formalized theorem set.
