# TRIAL6 multilayer no-annihilation audit

## Correction of the wall model

The walls encountered along a route are layered.  A boundary wall may become
a prime packet, zero packet, transition wall, edge term, or retained remainder.
TRIAL6 therefore removes the requirement that every intermediate wall be
identified with one raw fixed-height packet.

## Multilayer ledger

Section 36 introduces the layer state

\[
\mathscr W_j^{\rm led}
=\mathscr B_j\oplus\mathscr P_j^{\rm p}
\oplus\mathscr P_j^{\rm z}\oplus\mathscr T_j
\oplus\mathscr E_j\oplus\mathscr R_j
\]

and its corrected-scale quotient

\[
\overline{\mathscr W}_j
=\mathscr W_j^{\rm led}/\mathscr N_j.
\]

The direct-sum coordinates are not identified between layers.  Every generated
term must be entered exactly once in its actual layer.

## Layerwise certificate

Definition 36.6 requires, for every generator step:

1. an exact complete-ledger lift, including all complementary and error terms;
2. stability of negligible classes under the layer map;
3. a decoder that reassembles the preceding layer;
4. boundedness of that decoder at the corrected layer scales;
5. for N propagation, a positive descendant-detector bound.

The decoder is a left inverse between different ledger spaces.  It is not an
assertion that the two walls are the same.

## Proved composition theorem

If the first three fields hold at every step, Theorem 36.7 proves that the
composite layer map is injective on the declared obstruction subspace.  With
decoder bounds,

\[
\|\overline G_{m-1}\cdots\overline G_0v\|_m
\ge\left(\prod_{j=0}^{m-1}K_j^{-1}\right)\|v\|_0.
\]

With descendant bounds,

\[
\|\ell_m(\overline G_{m-1}\cdots\overline G_0v)\|
\ge\left(\prod_{j=0}^{m-1}a_j\right)\|\ell_0(v)\|.
\]

Thus a certified route cannot silently annihilate a detected wall obstruction;
the obstruction must remain in some descendant ledger coordinate.

## Generator decoder audit

Lemma 36.8 supplies natural representative-level decoders:

- inverse phase substitution;
- recombination of the integration-by-parts boundary and remainder;
- recombination of all explicit-formula outputs;
- recombination of density, fluctuation, and error measures;
- restoration of cutoff complements, transitions, and leakage;
- leading packet plus exact stationary-phase remainder;
- Dirichlet polynomial plus exact Selberg--Tsang remainder;
- quotient identity for proved lower-order removal.

These prove the formal complete-ledger reassembly.  They do not manufacture
the corrected-scale quotient bounds.

Proposition 36.9 reduces quotient descent to explicit estimates: equivalence
of consecutive corrected scales, a forward operator bound, and a decoder
operator bound.  This identifies the precise quantitative content that must be
verified route by route instead of treating type recurrence as sufficient.

## N-side consequence

The raw N detector from TRIAL5 is nonzero.  Corollary 36.10 now gives the
correct propagation rule:

- if its final descendant is the returned N coefficient detector, returned
  Hypothesis N fails;
- if its type changes, the obstruction survives in the actual boundary,
  prime-packet, transition, edge, or remainder coordinate.

The second case must not be renamed as returned N.  It remains part of the
complete L/total-obstruction ledger.

## Remaining analytic obligations

TRIAL6 proves the composition theorem and identifies the exact decoder
candidates.  It does not yet prove, for every concrete route step:

1. quotient stability in the declared joint regime;
2. a finite corrected-scale decoder constant `K_j`;
3. a positive descendant constant `a_j`;
4. control of all type-changing anchor, linkage, and carrier allowances;
5. the final scalar total-obstruction lower bound.

Consequently, multilayer recurrence is now represented correctly and its
no-annihilation theorem is proved conditionally on explicit layer
certificates.  The unconditional routewise instantiation and P3/P6 discharge
remain open.

## Verification

- XeLaTeX clean build: success, 85 pages;
- undefined references: 0;
- multiply defined labels: 0;
- overfull boxes: 0;
- missing glyphs: 0;
- LaTeX and hyperref warnings: 0;
- all 85 rendered pages inspected; no clipping, overlap, or blank pages.
