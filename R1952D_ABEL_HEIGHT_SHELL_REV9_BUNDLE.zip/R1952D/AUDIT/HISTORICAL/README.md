# Historical audits

These files document earlier TRIAL stages. They are retained for provenance
only and do not determine the mathematical claim status of TRIAL17.

Current review should begin with:

1. `../TRIAL17_CONCRETE_FINITE_LI_WITNESS_AUDIT.md`;
2. `../FINAL_INTEGRATION_AUDIT.md`;
3. `../STEP4_CLAIM_BOUNDARY.md`.
