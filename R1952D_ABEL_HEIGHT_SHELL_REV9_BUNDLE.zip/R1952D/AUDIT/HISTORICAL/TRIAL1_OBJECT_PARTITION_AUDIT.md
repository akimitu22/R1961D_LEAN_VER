# R1952D TRIAL1 object-level and partition audit

Audit date: 2026-06-22

## Scope

This trial implements the level-typed object stack and the two-partition
discipline. It does not discharge P1--P6 or change the conditional status of
the main theorem-link.

## Implemented hierarchy

| Level | Preserved object |
|---|---|
| Zero measure | H_n(T) dN(T) |
| Post-Stieltjes density | K_n^{Li}(T) N(T) dT |
| Phase primitive | P_n = H_n o T_n |
| Auxiliary transported density | D_n = K_n^{Li} o T_n |
| Jacobian-corrected density | G_n = D_n(-T_n') = P_n' |
| Cutoff-weighted phase | W_corr = (a_sigma P_n)' |

The primitive cells C_{k,n} and cutoff sign bands S_{j,n,sigma} are now
separate defined objects. Sign-sensitive endpoint claims must use the latter;
phase-coordinate bookkeeping uses the former.

## Files synchronized

Twenty section files were changed: Sections 3--4, 6--11, 19, 21, 24--25,
36--37, 42, 46, 49, 55--57.

Principal changes:

- Section 4 defines the six analytic levels and two partitions.
- Sections 6 and 42 distinguish ledger preservation from the still-unproved
  numerical scale comparison.
- Sections 8--11 replace single-kernel preservation by preservation of the
  complete object stack and both partitions.
- Sections 19, 21, 24--25, 36--37, and 46 replace Li-cell deformation by a
  two-partition deformation test.
- Section 57 restricts its asymptotic kernel formula to the post-Stieltjes
  level.
- The missing backslash in the normalized total obstruction in Section 3 was
  corrected.

## Semantic search audit

| Search | Result |
|---|---:|
| Ambiguous actual Li kernel / actual kernel | 0 |
| K_n^{Li} sign bands used as cutoff sign bands | 0 |
| Primitive cells asserted to be general cutoff sign bands | 0 |
| Old Section 24 references 4.2 and 4.4 for phase cells | 0 |
| K_n^{Li} dN occurrences | 2, both explicit non-example warnings |
| includepdf in manuscript source | 0 |

## Build and visual verification

The complete source was rebuilt through XeLaTeX with latexmk.

| Check | Result |
|---|---:|
| Pages | 73 |
| Undefined references | 0 |
| Multiply defined labels | 0 |
| Overfull boxes | 0 |
| Missing glyphs | 0 |

All 73 pages were rendered to PNG and reviewed as a contact sheet. The new
typed definition, partition definition, coherence tuple, downstream escape
sections, and scale-alternative table were inspected at full-page resolution.
No blank, clipped, overlapping, or corrupted page was observed.

## Remaining proof boundary

This trial removes semantic ambiguity but does not prove corrected transport,
endpoint necessity, substantive N/L exhaustiveness, either N/L discharge, the
uniform RH bridge, or total corrected nonvanishing. In particular, statements
that previously asserted automatic scale preservation now retain the ledger
and explicitly mark the branchwise comparison factor as a P4 obligation.
