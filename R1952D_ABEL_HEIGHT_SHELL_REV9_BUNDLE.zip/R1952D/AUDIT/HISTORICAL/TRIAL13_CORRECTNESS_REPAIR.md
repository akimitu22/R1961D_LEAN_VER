# TRIAL13 correctness repair

Date: 2026-06-23

## Decisive correction

TRIAL12 treated two unproved implications as completed theorems.

### G1. Joint-limit RH bridge

The manuscript proves fixed-index Abel recovery, but also correctly observes

```text
||exp(-sigma u)-1||_[0,n pi] = 1-exp(-pi n sigma).
```

This does not tend to zero in the declared regime `n sigma -> infinity`.
The former Theorem 5.10 then asserted, without a new estimate, that RH makes
the corrected residual class negligible. TRIAL13 replaces it by an explicit
conditional interface.

### G2. Ledger faithfulness

The original Li-boundary identity is scalar. Splitting its terms into a formal
direct sum prevents cancellation between coordinates by definition. A nonzero
formal coordinate therefore detects the original scalar quotient only after a
well-defined faithful ledger lift has been proved. TRIAL12 did not prove this.
TRIAL13 states the missing bridge explicitly in Definition 12.15a.

## Results retained

- corrected zero-pair and Abel-boundary identities;
- exact fixed-height character calculation under RH;
- nonzero exact-mode coefficients;
- Vandermonde finite-block separation;
- formal route and complete-ledger obstruction results;
- the conditional modus-tollens theorem if G1 and G2 are supplied.

## Claim boundary

The bundle does not claim a proof or disproof of RH. A negative finite Li
coefficient is not inserted as an artificial requirement; the actual missing
steps are G1 and G2 above.
