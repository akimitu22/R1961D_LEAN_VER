# TRIAL12 proof-architecture repair

Date: 2026-06-23

## Scope

TRIAL12 is rebuilt from the pre-TRIAL7 manuscript line. It removes the
TRIAL8--TRIAL10 scalar P5/P6 route from the main proof and restores the
infinite-side quotient argument:

1. RH requires coherent closure of the corrected infinite-side Li-boundary
   object.
2. Structural-support exhaustion returns every object-preserving route to the
   necessary fixed-height multilayer wall.
3. The N/L interface exhausts the terminal ledger coordinates.
4. The raw exact-character calculation supplies one nonzero terminal class.
5. Exact complete-ledger lifts and decoders preserve a nonzero descendant.
6. The same quotient class therefore cannot be both zero and nonzero.

No negative finite Li coefficient is used.

## Conservative conditions removed from the main theorem

The following are not proof gates in TRIAL12:

- a uniform scalar P5 bridge;
- moving core-tail or diagonal certificates;
- a scalar total-obstruction lower bound;
- global rotation or sector decomposition;
- six separately evaluated loss constants;
- a strict scalar margin or positive liminf;
- quantitative decoder norms or descendant-detector constants.

The six-loss L-side comparison remains only as an explicitly optional
quantitative strengthening. P3 is the structural N/L complete-ledger
exhaustiveness theorem and does not assume L-side dominance.

## Required statements retained

The revision does not demote:

- corrected same-object transport;
- coherent support and generated-route exhaustion;
- route return to the common fixed-height interface;
- endpoint necessity;
- N/L terminal-coordinate exhaustiveness;
- exact-character nonvanishing;
- complete-ledger no-annihilation;
- RH closure necessity in the same quotient.

## Lean synchronization

D157/CorrectedNLInterface.lean now represents P3 by
nlLedgerExhaustive, not by the old proposition
hypothesisN or hypothesisL. P6 consumes route return, endpoint necessity,
N/L ledger exhaustiveness, and corrected transport.

Static inspection:

- Lean files: 749
- import declarations: 1762
- sorry: 0
- admit: 0
- explicit global axiom: 0

The current execution environment does not contain lean, lake, or the
declared Lean 4.31.0/mathlib toolchain. Therefore no Lean compilation claim
is made for TRIAL12; the result above is a static source inspection only.

## PDF verification

- pages: 81
- XeLaTeX build: passed
- undefined references: 0
- duplicate labels: 0
- overfull boxes: 0
- missing glyphs: 0
- hyperref warnings: 0
- rendered pages inspected: 81
- blank, clipped, or overlapping pages: 0

