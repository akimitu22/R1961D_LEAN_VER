# TRIAL4 exact-character gap audit

## Scope

TRIAL4 reconstructs the exact characters behind the abstract N-side packet.
It corrects an ambiguity in the recovered notation: the exact parameter
`beta` in

\[
C_{\mathcal B}=(\beta_*-1)^2A_{\mathcal B}
\]

is an exponential mode in the index `n`, not the real part of a zero.

## Exact reconstruction

Under RH and at fixed height `H_0`, define

\[
\beta_\gamma=1-\frac1{1/2+i\gamma}.
\]

The finite-height Li contribution is

\[
\lambda_n^{\le H_0}
=\sum_{0<\gamma\le H_0}m_\gamma
 (2-\beta_\gamma^n-\beta_\gamma^{-n}).
\]

Appendix D proves the exact post-difference packet

\[
\Delta^2\lambda_n^{\le H_0}
=-\sum_\gamma m_\gamma
\{(\beta_\gamma-1)^2\beta_\gamma^n
+(\beta_\gamma^{-1}-1)^2\beta_\gamma^{-n}\}.
\]

## Proved gaps

### Coefficient gap

For every ordinate `gamma<=H_0`,

\[
|\beta_\gamma-1|^2
=|\beta_\gamma^{-1}-1|^2
=\frac1{\gamma^2+1/4}
\ge\frac1{H_0^2+1/4}.
\]

Multiplicity is a positive integer, so every raw mode coefficient is nonzero.

### Vandermonde block gap

For the distinct fixed-height modes `beta_1,...,beta_q`, the `q` consecutive
packet values form a Vandermonde system.  If

\[
d(H_0)=\min_{j\ne k}|\beta_j-\beta_k|,
\qquad
s(H_0)=d(H_0)^{q(q-1)/2}/q^{q-1},
\]

then, uniformly in the starting index `N`,

\[
\sum_{r=0}^{q-1}|P_{N+r}(H_0)|^2
\ge s(H_0)^2\sum_j|C_j|^2
\ge\frac{s(H_0)^2}{(H_0^2+1/4)^2}.
\]

Thus the raw post-difference packet cannot vanish on `q` consecutive indices.

### Moving-window gap

Let `M_0(H_0)` be the number of positive zeros up to `H_0`, counted with
multiplicity, and set `R_0=sqrt(H_0^2+1/4)`.  Appendix D proves

\[
\sum_{r=0}^{\ell-1}\lambda_{N+r}^{\le H_0}
\ge2M_0(H_0)(\ell-2R_0).
\]

This is strictly positive for every integer `ell>2R_0` when the packet is
nonempty.

## Conditional ledger bridge

If a same-object identity

\[
M_{\mathrm{eff}}=\lambda^{\le H_0}+R_{\mathrm{car}}
\]

and a window lower bound for `R_car` are supplied, the moving-window gap gives
a concrete sufficient inequality under which at least one index in every
window satisfies the L-type comparison.  This implication is Proposition
60.5.

## Remaining P3 obligations

P3 is not discharged.  The remaining work is:

1. prove an injective same-object map from the raw modes to the transformed
   returned packet `A_chi,Phi_chi`;
2. retain every anchor, linkage, packet, and residual term under that map;
3. bound the returned carrier allowance on the same moving window;
4. obtain an RH-independent lower envelope if the result is to qualify as
   Hypothesis L;
5. upgrade the one-index-per-window conclusion to the pointwise
   `R_sgn(H_0)` statement, or redefine and justify the selected range.

The moving-window bound uses the RH unit-circle identity and therefore cannot
itself serve as the RH-independent L discharge.

## Verification

- XeLaTeX build: success, 80 pages;
- undefined references: 0;
- multiply defined labels: 0;
- overfull boxes: 0;
- missing glyphs: 0;
- hyperref warnings: 0;
- full-page rendering and package verification are recorded at final export.

All preceding trial bundles remain unchanged.
