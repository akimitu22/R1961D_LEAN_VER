# TRIAL2 route-family audit

## Scope

TRIAL2 preserves the corrected object hierarchy and primitive/cutoff partition of
TRIAL1.  It implements plan C for P4+P1 by organizing the eight route sections into
five transport families:

| Family | Operations | Sections |
|---|---|---|
| F1 | phase substitution and ordinary integration by parts | 28 |
| F2 | cutoff insertion and transition differentiation | 29 |
| F3 | Stieltjes smoothing and bandlimited replacement | 30--31 |
| F4 | standard prime-zero explicit formula | 32 |
| F5 | Riemann-von Mangoldt, Selberg-Tsang, and packet return | 33--35 |

## Certificate

Section 27 now defines one corrected route transport certificate with six fields:

- T1: same-object identity;
- T2: corrected-amplitude provenance;
- T3: complete ledger identity;
- T4: partition provenance;
- T5: quantitative comparison on the declared corrected scale;
- T6: fixed-height wall factorization through the common carrier.

T1--T4 form an algebraic certificate.  T1--T5 form a quantitative certificate.
Only T1--T6 form a wall-returned certificate.  These status names prevent an exact
identity or a bookkeeping decomposition from being reported as P4 or P1.

## Implemented identities

- F1 records the corrected amplitude after phase substitution and the exact
  integration-by-parts boundary/remainder identity.
- F2 records the product rule for the cutoff, including the transition term and
  its endpoint ledger.
- F3 records the exact smoothing-commutator split, the unsmoothing remainder, and
  the bandlimited/leakage split.
- F4 records the standard explicit-formula decomposition with prime, zero,
  gamma/pole, and edge terms retained.
- F5 records the Riemann-von Mangoldt split, the Selberg-Tsang approximation, the
  prime density/error split, and the conditional fixed-height ledger form.

Theorems 27.5 and 27.6 are assembly theorems: routewise T1--T5 imply P4 in one
declared regime, while T6 plus a common carrier gives the P4-to-P1 return.  They do
not manufacture any missing certificate field.

## Open proof obligations

P4 and P1 are not discharged in TRIAL2.  The remaining work is:

1. instantiate the corrected amplitude and ledger for every individual route;
2. prove T5 on one compatible scale for every route, including endpoints,
   transition terms, leakage, remainders, and packet errors;
3. prove T6 at fixed height with the same carrier, anchor, and linkage convention;
4. verify that all five families operate in the same declared regime before using
   the family assembly theorem.

## Verification

- XeLaTeX build: success, 76 pages;
- undefined references: 0;
- multiply defined labels: 0;
- overfull boxes: 0;
- missing glyphs: 0;
- hyperref warnings: 0;
- visual inspection: all 76 rendered pages checked in four contact sheets; no
  clipping, overlap, or blank-page defect observed.

The original Stage 5 bundle and TRIAL1 were not modified.
