# TRIAL14 scalar dual-detector repair

Date: 2026-06-23

## Main change

TRIAL14 moves the final test from the formal direct-sum ledger to the original
fixed-height scalar returned carrier. For the finite exact-character packet

```text
P_n(H0) = sum_j C_j beta_j^n,
```

the inverse Vandermonde row defines a block functional `Lambda_(H0,j*)`.

## Proved algebra

1. exact coefficient extraction:
   `Lambda(P_N,...,P_(N+q-1)) = C_(j*) beta_(j*)^N`;
2. explicit nonzero bound: `|C_(j*)| >= R0^(-2)`;
3. descent through negligible scalar blocks;
4. the conditional contradiction obtained by combining these results with
   the aggregate detector bridge.

## Remaining analytic bridge

`D_(H0,j*)` consists of two aggregate estimates on the same cofinal path:

```text
RH => Lambda(X block) = o(1)
Lambda(X block - raw packet block) = o(1).
```

This is one scalar detector bridge. It permits all cancellation already present
in the original scalar object and does not require coordinatewise ledger
faithfulness, global rotation, sector decomposition, or six separate loss
estimates.

## Claim boundary

The detector algebra is proved. The analytic bridge `D_(H0,j*)` is not proved
in TRIAL14. Consequently the manuscript does not claim a proof or disproof of
RH.
