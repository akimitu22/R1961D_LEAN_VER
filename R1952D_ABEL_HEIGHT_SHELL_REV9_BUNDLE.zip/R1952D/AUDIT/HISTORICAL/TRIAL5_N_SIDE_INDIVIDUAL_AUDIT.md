# TRIAL5 N-side individual audit

## Scope

TRIAL5 evaluates the four requested N-side components for the canonical raw
fixed-height packet: the raw coefficients `A_chi`, exact-beta classes, orbit
completion, and exceptional zero-coefficient mechanisms.  It does not identify
the raw packet with the transformed returned packet merely from shared notation.

## Raw coefficients

Under RH, for a distinct positive ordinate `gamma<=H_0`, set

\[
\rho_\gamma=\frac12+i\gamma,
\qquad
\beta_\gamma=1-\frac1{\rho_\gamma}.
\]

After applying the forward second difference, the two exact modes have

\[
A^{\rm raw}_{\beta_\gamma}
=-m_\gamma(\beta_\gamma-1)^2,
\qquad
A^{\rm raw}_{\beta_\gamma^{-1}}
=-m_\gamma(\beta_\gamma^{-1}-1)^2.
\]

Both are nonzero because `m_gamma>0`, `rho_gamma` is finite, and neither mode
equals one.

## Exact-beta classes

Repeated zeros at the same ordinate are first merged into their positive
multiplicity.  Injectivity of `gamma -> beta_gamma` on positive ordinates and
the upper/lower half-circle separation show that each exact-mode class is a
singleton after this merge.  Its pre-difference accumulation and
post-difference coefficient are

\[
A_{\mathcal B(\beta_\gamma)}=-m_\gamma,
\qquad
C_{\mathcal B(\beta_\gamma)}=-\frac{m_\gamma}{\rho_\gamma^2},
\]

\[
A_{\mathcal B(\beta_\gamma^{-1})}=-m_\gamma,
\qquad
C_{\mathcal B(\beta_\gamma^{-1})}
=-\frac{m_\gamma}{(\rho_\gamma-1)^2}.
\]

Thus neither class accumulation nor either individual post-difference
coefficient can vanish.

## Orbit completion

The nonduplicated mode orbit is

\[
\mathcal Q_{\rm mode}(\gamma)
=\{\beta_\gamma,\beta_\gamma^{-1}\}.
\]

Its completed raw coefficient is

\[
C^{\rm raw}_{\rm orb}(\gamma)
=\frac{2m_\gamma(\gamma^2-1/4)}{(\gamma^2+1/4)^2}.
\]

It is negative for `0<gamma<1/2`, zero for `gamma=1/2`, and positive for
`gamma>1/2`.

## Exceptional mechanisms

The exhaustive raw verdict is:

1. same-mode accumulation cannot vanish, since it equals `-m_gamma`;
2. an individual post-difference coefficient cannot vanish;
3. conjugation/reflection orbit completion can vanish only at `gamma=1/2`;
4. if every ordinate in the fixed-height set exceeds `1/2`, every orbit
   coefficient and their total sum are strictly positive.

Consequently, the coefficient-nullity form of Hypothesis N fails for the
canonical raw packet.  The exceptional orbit cancellation at `gamma=1/2`
does not restore Hypothesis N, because the two individual mode coefficients
remain nonzero.

## Returned packet and P3 boundary

The raw verdict transfers to the returned packet only through an injective
same-object map preserving every exact mode, multiplicity, class, orbit,
anchor, carrier term, and ledger linkage.  Once that map is proved, the
returned N side fails and any P3 discharge for this packet must use the L side.

That identification is not proved here.  A carrier allowance, an
RH-independent L lower estimate, and the pointwise sign-range upgrade are also
still open.  Therefore TRIAL5 does not discharge P3.

## Verification

- XeLaTeX clean build: success, 82 pages;
- undefined references: 0;
- multiply defined labels: 0;
- overfull boxes: 0;
- missing glyphs: 0;
- LaTeX and hyperref warnings: 0;
- all 82 rendered pages inspected; no clipping, overlap, or blank pages.

All preceding trial bundles remain unchanged.
