# TRIAL3 endpoint-necessity audit

## Scope

TRIAL3 preserves the corrected object hierarchy, partition distinction, and
five-family transport system of TRIAL2.  It implements the proposed hybrid
strategy for P2:

1. an exact fixed-height Stieltjes cut and anchor ledger;
2. a trace/retraction on the corrected reassembly quotient;
3. dual functionals separating the wall coordinate from the trace kernel.

## Exact result

For

\[
F_{n,\sigma}(T)=a_\sigma(\theta_n(T))H_n(T),\qquad
u_{0,n}=\theta_n(H_0),
\]

the corrected Abel object is split using the half-open partition
`[0,H_0]` and `(H_0,infinity)`.  Lemma 51.1 proves

\[
\lambda_{n,\sigma}^{(H)}
=\lambda_{n,\sigma}^{\le H_0}
 +\lambda_{n,\sigma}^{>H_0}.
\]

After Stieltjes integration by parts, the anchor

\[
A_{n,\sigma}(H_0)=F_{n,\sigma}(H_0)N(H_0)
\]

appears with opposite signs in the two cut ledgers.  It cancels only after the
two pieces are recombined.  This establishes certificate item E1 for the actual
corrected zero-measure object.

## Assembly system

Definition 51.4 divides endpoint necessity into five certificate fields:

- E1: exact fixed-height cut;
- E2: compatibility of the cut trace with every allowed generator relation;
- E3: uniform continuity of the trace on the corrected quotient and joint
  regime;
- E4: same-object identification of the trace with the fixed-height wall,
  retaining anchor and linkage errors;
- E5: trace/retraction identity and continuous coordinate separation.

Lemma 51.5 proves that E2--E3 make the provisional trace descend to the
reassembly quotient.  Proposition 51.6 constructs the dual separator from a
wall-coordinate functional.  Theorem 51.7 proves that E1--E5 imply P2 for the
selected construction.

## Remaining obligations

P2 is not discharged in TRIAL3.  The exact cut E1 is proved, but the following
items remain:

1. check E2 for every route operation, including a localization crossing
   `H_0` and its complete transition/leakage ledger;
2. prove the uniform scale estimate E3 in the same joint regime used by the
   closure target;
3. instantiate the same-object wall factorization, anchor, and linkage in E4;
4. prove the continuity and separation requirements in E5 for the completed
   wall topology.

In particular, one chosen cutoff derivation does not prove endpoint necessity.
The trace must be independent of the representative and continuous after the
joint-limit quotient is taken.

## Verification

- XeLaTeX build: success, 79 pages;
- undefined references: 0;
- multiply defined labels: 0;
- overfull boxes: 0;
- missing glyphs: 0;
- hyperref warnings: 0;
- visual inspection: all 79 rendered pages checked in four contact sheets;
  pages 70--71 were also inspected at full resolution;
- Lean static verification: unchanged from TRIAL2 and rerun during packaging.

The original Stage 5 bundle and all preceding trial bundles were not modified.
