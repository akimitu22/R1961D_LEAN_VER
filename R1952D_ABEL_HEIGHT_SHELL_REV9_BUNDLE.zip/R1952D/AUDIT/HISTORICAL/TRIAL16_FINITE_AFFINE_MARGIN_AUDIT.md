# TRIAL16 finite affine margin audit

Date: 2026-06-23

## Main change

The final proof gate is now one finite certificate. For actual detector values
`AX`, `AP`, and `AE`, exact cut gives `AX = AP + AE`. Certified disks and the
packet bound imply

```text
norm (x - (C + e)) <= rX + rE + epsilonPacket.
```

A strict reverse inequality is impossible under RH.

## Component resolution

The aggregate remainder disk is assembled from the smooth term, returned
packet mismatch, and residual term. Their centers and radii remain separate,
so a compensating selected frequency cannot be hidden inside an aggregate
zero-limit assertion.

## Claim boundary

The finite certificate algebra is proved. Concrete Li centers, radii,
admissible witness data, and a positive margin are not proved. Consequently no
proof or disproof of RH is claimed.

## Lean scope

D159 formalizes the finite affine inequality and conditional contradiction.
The concrete Li enclosure estimates are not represented as axioms.
