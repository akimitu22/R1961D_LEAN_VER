# TRIAL17 concrete finite Li witness audit

Date: 2026-06-23

## Main change

TRIAL17 prevents cross-regime certificate assembly. Every detector value and
disk estimate is indexed by the same record containing the finite Li scale
parameters.

## Lean implementation

D160 provides:

1. `FiniteLiWitness` with local consistency fields;
2. `detectorAt` using the witness index and window;
3. exact cut transport at that witness;
4. three-component remainder transport;
5. component-disk aggregation;
6. compilation to D159 and the conditional `not RH` theorem.

## Claim boundary

The interface and compilation theorem are proved. Global admissible-path
membership, actual-Li sequence definitions, concrete disk estimates, full
finite packet extraction in Lean, and a positive margin remain unproved.
