# P3 gap-connection analysis

## TRIAL6 multilayer correction

The direct injective raw-to-returned packet map proposed below is sufficient
but unnecessarily identifies a multilayer route with a single packet
transport.  TRIAL6 replaces it by layerwise complete-ledger maps.  Each layer
may change the obstruction type, provided it has a quotient-stable decoder and
a positive descendant-detector bound.  Theorem 36.7 composes these
certificates; Corollary 36.10 specializes them to the raw N detector.  The
older direct-map wording in this audit should be read as the one-layer special
case of that framework.

## Question

Can the exact-beta factor, the finite-route phase margin, and the normalized
L-side dominance gap be connected to prove the analytic alternative

\[
\text{Hypothesis N}\quad\lor\quad\text{Hypothesis L}?
\]

The required non-definitional form is

\[
\mathbf A_{H_0}(n)=0
\quad\lor\quad
M_{\mathrm{LE}}(n;H_0)
\ge \operatorname{Err}_{\mathrm{NL}}^{\mathrm{tot}}(n;H_0)
\]

for every object and index in one declared fixed-height regime.

## Sources inspected

- the TRIAL3 manuscript, especially Sections 12, 18, 36, 46, and 51;
- `R1857D_main_manuscript_current.tex`, especially the R1660C--R1696C N/L
  chain, the r61 exact block appendix, the D2b phase-margin chain, and the D0R
  recombined-margin chain;
- pre-R1640C and related source snapshots containing the original Hypotheses N
  and L;
- the Step 3 mathematical dependency and source-recovery maps;
- `LEAN/D157/CorrectedNLInterface.lean`.

## Three different gaps

### 1. Exact-beta multiplier

The recovered N-side record contains

\[
C_{\mathcal B}=(\beta_*-1)^2 A_{\mathcal B}.
\]

Further reconstruction shows that `beta_*` is naturally an exponential mode
in `n`, not the real part of a zero.  For

\[
\beta_\gamma=1-\frac1{1/2+i\gamma}
\]

one has the exact post-difference identity

\[
\Delta^2(\beta_\gamma^n)
=(\beta_\gamma-1)^2\beta_\gamma^n
\]

and, under RH,

\[
|\beta_\gamma-1|^2
=\frac1{\gamma^2+1/4}
\ge\frac1{H_0^2+1/4}.
\]

Appendix D of TRIAL4 proves this raw fixed-height coefficient gap and a
Vandermonde block gap.  What remains missing is a certified descendant chain
through the distinct intervening walls.  Cancellation inside a transformed
class, after orbit completion, or during a type change cannot be excluded until
every step has a quotient-stable complete-ledger decoder and a positive
descendant-detector bound.

### 2. Phase margin

The D2b chain introduces a bucketwise constant `delta_*` through

\[
1+\cos(n\theta)\ge\delta_*>0.
\]

The argument takes the minimum of positive local margins on a finite
certificate bucket.  It does not supply a formula or independent proof that
each local margin is positive.  The same source says that the remaining burden
is the analytic validity of those margins.

There is also a direct obstruction to using this as a global all-index gap.
For fixed real `theta`,

\[
\inf_{n\ge1}(1+\cos(n\theta))>0
\]

holds only in the special periodic case in which `theta/(2*pi)` is rational
with odd reduced denominator.  If the denominator is even, some `n` gives
`cos(n*theta)=-1`; if the ratio is irrational, density modulo `2*pi` gives
infimum zero.  The manuscript does not prove the special odd-denominator
condition for its zeta phases.  Therefore the finite-bucket `delta_*` cannot be
promoted to the required infinite-index uniform margin without an additional
phase-arithmetic theorem or an explicitly finite index range.

### 3. Normalized L-side dominance gap

The long source defines

\[
\Delta_{\mathrm{LE}}(H_0)
=\lambda_{\mathrm{LE}}(H_0)-\sum_j\kappa_j(H_0),
\]

where

\[
\lambda_{\mathrm{LE}}
=\inf_n\frac{M_{\mathrm{LE}}(n;H_0)}{\Omega(n;H_0)},
\qquad
\kappa_j
=\sup_n\frac{\operatorname{Err}_j(n;H_0)}{\Omega(n;H_0)}.
\]

This is exactly the normalized sufficient criterion for L.  The current
manuscript retains the same quantity implicitly as
`C_LE(H_0)-sum_j c_j(H_0)` in (12.12)--(12.13).

The source repeatedly states that neither `lambda_LE`, the `kappa_j`, nor
`Delta_LE` is evaluated.  More decisively, the R1690C--R1695C recovery audit
does not find a source-backed tuple for

\[
\mathcal M_{\mathrm{core}},\quad
\mathcal M_{\mathrm{rem}},\quad
B_{\mathrm{rem}},\quad
B_{\mathrm{main}}^{\mathrm{cand}}.
\]

It classifies the main-candidate route as inactive and blocks the proposed
inequality skeleton.  Thus the long source itself confirms that the missing
step is not merely omitted exposition.

## Missing packet data

The exact-character packet is written as

\[
\mathcal P_N(n;H_0)
=\sum_{\chi\in\mathfrak X(H_0)}
A_\chi(n;H_0)\Phi_\chi(n;H_0).
\]

Across the pre-TRIAL4 sources, this is only an interface representation.  The
raw zero-pair packet now has explicit modes and coefficients in Appendix D,
but no explicit formula identifies those data with the returned
`A_chi,Phi_chi`.  The source expressly
does not claim:

- canonicity of `X(H_0)`;
- uniqueness of the packet/residual split;
- coefficient independence of the `Phi_chi`;
- a finite or explicitly completed sign-relevant range.

Consequently no Gram matrix can presently be formed, and no positive smallest
singular value can be proved.  A nonzero displayed coefficient vector may even
represent the zero packet if the synthesis functions are dependent.

## Recombined-margin chain

The most concrete lower-envelope object in the long source is

\[
M_n^{\mathrm{eff}}(H_0)
=\lambda_n^{\le H_0}+R_n^{\mathrm{car}}(H_0),
\qquad
\mathfrak m(n;H_0)
=M_n^{\mathrm{eff}}(H_0)-B_{\mathrm{cancel}}(n,H_0;U).
\]

The identity

\[
\lambda_n=M_n^{\mathrm{eff}}(H_0)+R_n^{\mathrm{obs}}(H_0)
\]

and the conditional estimate

\[
|R_n^{\mathrm{obs}}(H_0)|
\le B_{\mathrm{cancel}}(n,H_0;U)
\]

show that a positive recombined margin would imply `lambda_n>=0`.

However, the D0R witness package assumes a certified lower envelope
`L_eff<=M_eff` as its first input and says that this input is available only
after the lower-envelope obligation has been discharged.  The subsequent
finite-difference lemmas propagate that assumed lower envelope; they do not
derive it from the exact-beta or phase gaps.  Using the D0R conclusion to prove
L would therefore be circular.

There is also a notation-role conflict in the long source: the N/L interface
first identifies `m(n;H_0):=M_LE(n;H_0)` as a main component, while the final
aggregation writes `m(n;H_0)=M_eff(n;H_0)-B_cancel(n,H_0;U)` as an already
subtracted margin.  A connection theorem must choose one typed meaning before
any ledger comparison is valid.

## Lean status

`CorrectedNLInterface.lean` stores P3 as the field

```lean
data.routeReturned -> data.hypothesisN ∨ data.hypothesisL
```

and stores coefficient nullity, orbit checks, and L-side dominance as
obligations.  It constructs no analytic inhabitant and proves no gap estimate.

## Exact theorem that would be sufficient

The existing notation can support a non-circular P3 theorem only after the
following objects are supplied.

1. A sequence of complete-ledger layer maps from the canonical raw synthesis
   space through every boundary, prime, zero, transition, edge, and remainder
   wall encountered by the route.
2. A quotient-stable bounded decoder and positive descendant-detector bound at
   every step, preserving the raw coefficient and Vandermonde
   bounds

   \[
   \|S_{H_0}(n)A\|\ge s_*(H_0)\|A\|,
   \qquad s_*(H_0)>0.
   \]

3. A source-backed definition of `M_LE`, `Omega`, and every error component on
   the same index range.
4. The branch-conditioned dominance estimate

   \[
   \Delta_{L\mid\neg N}(H_0)
   :=
   \inf_{\substack{n\in\mathcal R_{\mathrm{sgn}}(H_0)\\
                   \mathbf A_{H_0}(n)\ne0}}
   \frac{M_{\mathrm{LE}}(n;H_0)
   -\operatorname{Err}_{\mathrm{NL}}^{\mathrm{tot}}(n;H_0)}
        {\Omega(n;H_0)}
   \ge0.
   \]

Then coefficient nullity gives N, while its failure invokes the displayed
estimate and gives L.  This is the needed analytic disjunction.

## Verdict

The raw exact-beta factor is now reconstructed as an explicit coefficient gap,
and the raw packet has a uniform finite-block Vandermonde gap.  These results
do not yet propagate through every later wall layer.  The pointwise phase margin remains
conditional and generally cannot be uniform on an unrestricted infinite index
set; the L-side dominance gap is the right target but is unevaluated and lacks
a source-instantiated main term.  Therefore P3 still cannot be proved from the
available manuscript and Lean data.

This verdict means that the connection is currently unproved, not that no
future external estimate can establish it.  Such an estimate would be a new
analytic input rather than a recovery of an existing hidden proof.
