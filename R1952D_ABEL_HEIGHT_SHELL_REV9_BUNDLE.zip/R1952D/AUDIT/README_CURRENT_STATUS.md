# Audit status index

The current authority for TRIAL18 is:

1. `TRIAL18_FINITE_PACKET_CESARO_BOUND_AUDIT.md`;
2. `FINAL_INTEGRATION_AUDIT.md`;
3. the rebuilt manuscript and current `STEP4_CLAIM_BOUNDARY.md`.

`TRIAL1_*` through `TRIAL17_*` and the old Step 3 documents are historical
development records. They do not determine the current claim status.
