# TRIAL18 finite packet Cesaro bound audit

Date: 2026-06-23

## Main change

TRIAL18 discharges the finite-packet `K/L` field that remained abstract in
D160. D161 constructs the packet from finitely many distinct unit frequencies
and proves a detector estimate uniform in the starting index.

## Lean implementation

D161 provides:

1. `FinitePacketData` and the selected finite packet;
2. detector commutation with finite sums;
3. the exact finite geometric-sum identity;
4. a length-independent norm bound for every nonselected mode;
5. `finite_packet_detector_bound` with explicit `packetErrorConstant / L`;
6. `finite_packet_bound_at_witness`, matching the D160 field at one witness.

## Claim boundary

The finite algebra and packet estimate are represented by explicit theorem
proofs, with no `axiom`, `sorry`, or `admit`. The current environment lacks a
Lean 4.31.0 executable, so elaboration remains to be checked externally.
Actual-Li carrier and remainder definitions, admissible-path realization,
component disk enclosures, and a strict positive margin remain unproved.
