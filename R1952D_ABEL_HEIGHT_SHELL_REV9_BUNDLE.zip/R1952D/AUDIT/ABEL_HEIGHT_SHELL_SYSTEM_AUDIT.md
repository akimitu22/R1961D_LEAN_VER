# Abel-regularized height-shell implementation audit

Date: 2026-06-24

## Scope

This implementation adds D167--D199.  It formalizes the compatible finite-cut
family, its conditional fixed-parameter Abel tail, and the lower-cut plus tail
limit that must
precede any claimed RH closure theorem.  It does not claim a proof of RH or
of `not RH`.

## Implemented chain

- `D167/FiniteComplexZeroRectangle.lean`
  - starts from Mathlib's actual `riemannZetaZeros`;
  - intersects it with a compact closed ball and obtains a finite set from
    `IsCompact.inter_riemannZetaZeros_finite`;
  - applies the positive-ordinate rectangle conditions only after finiteness
    has been certified.
- `D168/FiniteAtomicZeroPairing.lean`
  - uses membership in the actual D167 zero cut as its finite index type;
  - defines multiplicity by `analyticOrderNatAt riemannZeta`;
  - proves the RH critical-line view for the same positive-ordinate indices;
  - defines exact finite atomic pairing as a finite sum.
- `D169/AbelRegularizedHeightShell.lean`
  - fixes the shell convention to `(a,b]`;
  - defines the actual Abel-regularized zero-pair entrance kernel;
  - proves `0 <= exp (-sigma * phase) <= 1` under the stated signs;
  - proves `|F_{n,sigma}(T)| <= n^2/T^2` for `n > 0`, `sigma >= 0`,
    and `T > 0`;
  - makes no positivity claim for later signed ledgers.
- `D170/HalfOpenAtomicCounting.lean`
  - defines the right-continuous atomic count, real shell pairing, and
    interior interval integral;
  - proves the expanded half-open atomic Stieltjes identity using FTC;
  - does not mix transition or edge terms into the basic shell definition.
- `D171/ShellCocycleAnchorTelescoping.lean`
  - proves exact shell additivity under refinement;
  - proves exact adjacent-anchor cancellation.
- `D172/ExplicitZeroCountingGrowth.lean`
  - states the explicit zero-counting growth and quadratic-kernel bounds as
    named theorem boundaries, not record fields.
- `D173/DyadicAbelTailBudget.lean`
  - defines the corrected factor-two dyadic shell budget;
  - derives a shell bound from the actual kernel theorem, explicit counting
    growth, and domination by the global count;
  - proves summability of the linear-logarithmic dyadic majorant;
  - proves the finite triangle-inequality accumulation theorem;
  - leaves the infinite Cauchy passage separate.
- `D174/ComparisonScaleNondegeneracy.lean`
  - makes positivity of a comparison-scale lower envelope explicit;
  - proves the normalized tail bound `|tail|/B <= majorant/b`.
- `D175/UniformNormalizedTailDiagonal.lean`
  - names the old fixed-epsilon predicate as pointwise;
  - defines the genuine uniform epsilon--N limit over an admissible scale type;
  - transfers a uniform master-ratio limit to the normalized tail limit.
- `D176/AbelHeightShellDependencyAudit.lean`
  - checks the declarations and prints axiom dependencies of the proved chain.
- `D177/CompatibleCriticalStripZeroCuts.lean`
  - fixes the canonical critical-strip cut radius to `H + 1`;
  - proves rectangle coverage, monotonicity, and exact restriction compatibility.
- `D178/ActualOrdinateCutFamily.lean`
  - turns the canonical cut into an actual ordinate family and actual finite count;
  - proves reduction of multiplicity positivity to finite
    analytic order, without assuming that finiteness as a record field.
- `D179/ActualDyadicShellSequence.lean`
  - defines every shell from the canonical cut at its upper endpoint;
  - proves shell nonnegativity and the corrected budget bound for every index.
- `D180/DyadicBudgetSummability.lean`
  - identifies the exact budget with a constant multiple of the summable
    linear-logarithmic majorant;
  - derives summability of the actual complex shell series from its norm bound.
- `D181/FixedParameterInfiniteAbelObject.lean`
  - correctly names the `tsum` as the tail above the base height;
  - records that `tsum` is total and justified by the conditional `HasSum` theorem;
  - exports convergence and the Cauchy property of finite dyadic partial sums.
- `D182/CompatibleInfiniteAbelDependencyAudit.lean`
  - checks the extended declarations and their axiom dependencies.
- `D183/CanonicalCutShellPairing.lean`
  - writes shell pairings directly on canonical finite cuts;
  - proves the refinement cocycle across different height cuts.
- `D184/DyadicPartialSumSingleCut.lean`
  - proves that the first `m` dyadic shells equal `(H, 2^m H]` on one cut.
- `D185/LowerCutPlusTailInfiniteObject.lean`
  - adds `(0,H]` and proves convergence of single-height cuts to lower plus tail.
- `D186/RHOrdinateShellBoundary.lean`
  - proves the RH critical-line view for the canonical cut;
  - applies the separately proved pure complex-power identity pointwise.
- `D188/DyadicBaseHeightIndependence.lean`
  - proves base-height independence along `H -> 2^m H` only.
- `D189/CriticalLineComplexPowerIdentity.lean`
  - proves the critical-line complex-power/cosine identity without RH or zeta;
  - identifies the ordinate primitive with one complex conjugate-pair expression.
- `D190/RHFinitePositivePairingIdentification.lean`
  - proves equality of the RH positive-representative finite Abel shell and
    the ordinate shell;
  - does not claim exhaustion of the full zeta zero multiset.
- `D191/ActualLiIdentificationDependencyAudit.lean`
  - checks the proved positive-representative identification chain.
- `D192/FiniteConjugationOrbitPairing.lean`
  - constructs the positive cut and its conjugate image as a disjoint union;
  - proves injective image reindexing and exact pair compression;
  - proves the finite symmetric-cut sum identity conditional only on
    conjugation invariance of analytic multiplicity;
  - under RH, identifies the constructed paired sum with the ordinate cut.
- `D193/ActualSymmetricZeroCutBoundary.lean`
  - defines the full symmetric nonreal cut directly from actual zeta zeros;
  - separates zero conjugation, order conjugation, and order finiteness;
  - derives exact Finset equality between the actual and paired cuts from
    zero conjugation instead of accepting that equality as a bridge input.
- `D194/SymmetricLiCutDependencyAudit.lean`
  - checks the exact finite orbit theorems and their dependency boundary.
- `D195/ActualSymmetricCutInfiniteLimit.lean`
  - identifies the positive ordinate sum with D185's canonical lower cut;
  - transfers D185 convergence to the actual symmetric Li cut sequence under
    RH, zero conjugation, order conjugation, and explicit zero-count growth.
- `D196/ActualSymmetricLimitDependencyAudit.lean`
  - checks the cut-equality and conditional infinite-limit dependency chain.
- `D197/ExplicitPositiveTerminalTail.lean`
  - sums the exact dyadic budget in closed form for terminal height `T >= 1`;
  - proves the first-shell threshold condition propagates to every dyadic shell;
  - proves the conditional actual-cut error bound
    `4 C n^2 / T * (1 + log T + 2 log 2)`;
  - uses D188 to compare dyadic terminal cuts `T = 2^m H0` with one fixed-base
    infinite object instead of silently treating the height-indexed objects as equal;
  - exposes the same shell tail as a nonnegative real `tsum`;
  - proves that real `tsum` casts to the existing complex tail under the
    summability hypotheses;
  - proves the hybrid pointwise kernel bound
    `F <= min 4 (n^2 / t^2)`.
- `D198/EndpointScaleConditioning.lean`
  - separates the complex endpoint coordinate, its norm scale, and the
    uncancelled endpoint size;
  - defines the endpoint cancellation ratio with an explicit zero-size case;
  - proves the zero-size/exact-cancellation/near-cancellation/nondegenerate
    four-way split;
  - proves the exact factorization `tail/B = (tail/S)/chi`;
  - states the quantitative matched-cancellation obligation for the near branch.
- `D199/PositiveTailScaleDependencyAudit.lean`
  - checks the positive-tail and endpoint-conditioning dependency boundary.

## Deliberately unresolved analytic gates

The following are not certificate fields and are not claimed as proved:

1. finiteness of the analytic order of zeta at each zero, needed to upgrade
   the proved conditional positivity lemma to an unconditional multiplicity theorem;
2. conjugate-zero existence and analytic multiplicity preservation; the cut
   equality is now derived from the former and is no longer an input;
3. the actual Riemann--von Mangoldt bound needed to discharge the explicit
   growth argument of the now-proved conditional tail remainder;
4. a canonical corrected-endpoint adapter, arbitrary-base independence, and a
   uniform normalized global scale law;
5. a positive lower envelope, wall-route trace, quotient descent, and RH
   closure necessity.

In particular, an absolute tail estimate cannot by itself imply normalized
closure.  The ratio against the lower envelope must be shown to tend to zero.

## Verification

`LEAN/STEP4_VERIFY_STATIC.sh` reports 806 Lean files, 1895 import
declarations, no missing local imports, and no
`sorry`, `admit`, or explicit `axiom` declarations.  The project now includes
`R2149DLeanPositiveTailScaleSystem` as a default Lake target.  Lean/Lake are not
installed in this environment; an attempted Elan bootstrap was rejected by
the network endpoint with HTTP 403, so elaborating compilation remains an
open verification step.  The root package name in `lake-manifest.json` has
been synchronized with `lakefile.lean`; regeneration by `lake update` remains
part of the first elaborating build.
