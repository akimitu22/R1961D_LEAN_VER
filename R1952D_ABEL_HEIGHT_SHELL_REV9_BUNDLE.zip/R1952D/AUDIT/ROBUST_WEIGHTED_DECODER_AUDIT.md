# Robust weighted decoder implementation audit

Date: 2026-06-23

## Implemented modules

- `D162/ExactWeightedModeResponse.lean`
  - finite weighted window decoder;
  - exact response of every packet mode;
  - selected-mode normalization without an absolute leakage majorant.
- `D163/WeightedRawNormalizedIntertwining.lean`
  - exact pointwise raw/normalized transport identity;
  - pointwise uncertainty budget
    `sum |a_r| * (B_r * delta_r + tau_r)`.
- `D164/PhaseAwareRobustMargin.lean`
  - real projection in an arbitrary certified phase;
  - contradiction from a positive robust phase margin;
  - RH-conditional theorem with the RH envelope supplied as a theorem
    argument rather than stored as a certificate field.
- `D165/WeightedDecoderRateBarrier.lean`
  - l1 mass lower bound under selected-mode normalization;
  - scale-weighted rate barrier `minimumScale <= weightedScaleMass`.
- `D166/RobustDecoderDependencyAudit.lean`
  - declaration and axiom audits for the new chain.

## Deliberately not claimed

The modules do not construct actual Riemann-zeta zeros, identify the raw
window with the actual fixed-height Li packet, prove joint Abel--Stieltjes
intertwining, or derive a quantitative normalized window envelope from RH.
Those are the remaining analytic gates.  In particular, the final conditional
theorem cannot be instantiated merely by filling an abstract `positiveMargin`
field.

## Verification boundary

The repository static verifier reports no missing local imports and no
`sorry`, `admit`, or explicit `axiom` declarations.  Lean 4.31.0 and Lake are
not installed in the present environment, so elaborating compilation remains
unverified.
