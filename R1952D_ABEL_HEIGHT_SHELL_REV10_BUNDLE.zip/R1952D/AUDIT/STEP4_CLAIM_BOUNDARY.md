# Current manuscript-to-Lean claim boundary

Updated for the Abel height-shell revision: 2026-06-24

## Manuscript change

All carrier, packet, remainder, and component estimates are tied to one finite
witness record. D161 now derives the full finite-packet detector estimate from
distinct unit frequencies at that same witness.

## Lean boundary

D160 defines `FiniteLiWitness`, same-witness detector evaluation, exact-cut
transport, three-component remainder transport, and compilation into the D159
finite affine margin certificate. D161 proves the selected-mode extraction and
uniform finite-packet `K/L` bound.

The record fields provide finite consistency checks only. The current tree
does not prove that a witness arises from a global admissible scale law, does
not produce a positive margin. These items are not axioms.

## D167--D199 boundary

D167 constructs a finite cut from Mathlib's actual `riemannZetaZeros` by first
intersecting with a compact ball. D168 maps the resulting membership subtype
to ordinate data whose multiplicity is `analyticOrderNatAt riemannZeta`, and
proves the RH critical-line statement for the same positive-ordinate index.

D170 proves an expanded finite-atomic half-open Stieltjes identity using only
derivative and continuity hypotheses on the integration interval. Its
interior term is a finite sum of genuine interval integrals and each term is
evaluated from an independent FTC hypothesis. D169 proves the actual
Abel-entrance bound `|F n sigma T| <= n^2 / T^2` under `n > 0`, `sigma >= 0`,
and `T > 0`. D173 derives the corrected factor-two dyadic shell bound from
that theorem, explicit zero-count growth, and domination by the global count.
D177 fixes a canonical radius covering the critical-strip rectangle and proves
exact restriction compatibility between height cuts. D179 applies the D173
bound to every actual dyadic shell. D180 proves that the exact budget is a
constant multiple of the summable linear-log majorant and obtains summability
of the complex shell sequence. D181 defines the fixed-parameter Abel tail and
proves `HasSum` and Cauchy partial sums, conditional on the explicit zero-count
growth input. D183--D185 prove cross-cut refinement, identify dyadic partial
sums with single finite cuts, and construct the lower-cut plus tail limit.
D188 proves base-height independence along dyadic refinements only. D175 now
defines the genuine uniform epsilon--N
statement over an admissible scale index type and includes scale positivity;
the old fixed-epsilon predicate is named pointwise.

D189 proves the complex-power/cosine identity from the critical-line geometry
alone. D190 lifts that identity to equality of finite positive-representative
Abel shell sums under RH. It does not prove that these representatives exhaust
the full zeta zero multiset.

D192 constructs a two-sided cut as the disjoint union of the positive cut and
its conjugate image. It proves the image reindexing and exact finite pair-sum
compression, assuming only equality of analytic multiplicities on conjugate
pairs, and under RH identifies this constructed paired sum with the ordinate
cut. D193 separately defines the actual symmetric nonreal cut from
`riemannZetaZeros`. The remaining exhaustion statement is now the exact
Finset equality between these two concrete cuts, not a sign disjunction.

The D193 revision no longer accepts that Finset equality as an input: it
derives it from zero-membership conjugation, compact-ball coverage, and the
sign split of the nonzero ordinate. Zero conjugation, order conjugation, and
order finiteness are separate theorem boundaries. D195 proves that the
positive ordinate sum is the complex lift of D185's canonical lower cut and
transfers D185's convergence to the actual symmetric cut sequence,
conditionally on RH, the two conjugation theorems, and explicit zero-count
growth.

D197 sums the dyadic budget exactly at terminal height and proves the
conditional actual-cut error bound
`4 C n^2 / T * (1 + log T + 2 log 2)`. It also proves the pointwise hybrid
kernel bound.  Its fixed-base theorem keeps `T = 2^m H0` explicit and invokes
D188; its positive real `tsum` is identified with the complex tail under the
summability hypotheses. D198 retains the complex endpoint coordinate before taking its
norm, separates endpoint size from cancellation ratio, proves the four-way
conditioning split for a positive threshold including exact cancellation and
strict scale positivity in both remaining branches, and records the matched-cancellation inequality
needed in the near branch. These results do not supply the actual zero-count
constant or discharge near-cancellation.

Still open are finiteness of the local analytic orders needed for unconditional
positive multiplicities, conjugate-zero and multiplicity preservation,
the explicit global zero-counting theorem needed by the conditional rate,
the canonical corrected-endpoint adapter, arbitrary-base independence, a uniform admissible scale
law, a positive comparison-scale lower envelope, wall-route trace descent, and
RH closure necessity.
