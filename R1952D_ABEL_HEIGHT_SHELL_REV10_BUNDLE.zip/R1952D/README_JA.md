# R1952D TRIAL18 finite packet Cesaro bound修正版

## 修正内容

TRIAL18は、TRIAL17のsingle-witness構造を保ち、有限packet全体の
sliding Cesaro `K/L` 評価をD161で形式化した。

```text
(N, L, sigma, Y, wY, Delta, Xband, Llocal, H0)
```

carrier、raw packet、aggregate remainder、smooth term、returned-packet
mismatch、residualはすべて同じrecordで評価される。異なるregime、fixed
height、window、normalizationから得た評価は型上合成できない。

D160は三成分diskをaggregate remainder diskへ合成し、D159のfinite affine
margin certificateを生成する。正のmarginが供給された場合だけ条件付き
`not RH`へ進む。

D161は有限unit-frequency packetを具体的に定義し、有限幾何和恒等式、
非選択modeの評価、有限和のtriangle inequalityから、starting indexに一様な
full packet boundを証明する。最終定理はD160の`packetBound` fieldと同じ型を
持つ。

## 残る解析入力

- finite witnessが実際のadmissible scale lawから得られること
- actual Li carrierと各remainder成分の具体的定義
- 同じwitnessにおけるcenter/radius評価
- strict positive margin

これらは公理化されておらず、RHの否定も証明済みとは主張しない。

## weighted robust decoder追加

D162--D166は、fixed Cesaro detectorを一般の有限weighted decoderへ
拡張する。選択modeを1へ正規化したときも、非選択modeを
絶対値和に置き換えず、exact complex packet responseとして保持する。

RH側の入力は各window点の具体的な不等式

```text
raw_r = B_r * normalized_r + transport_r
|normalized_r| <= delta_r
|transport_r| <= tau_r
```

の形でのみ受け取る。最終的な許容誤差は

```text
sum_r |a_r| * (B_r * delta_r + tau_r)
```

である。D165はselected responseの正規化から
`weightedScaleMass >= minimumScale`を証明し、qualitative closureだけでは
不足する場合のrate barrierを明示する。

追加部分は有限代数とノルム不等式の形式化であり、actual
zero set、joint Abel--Stieltjes intertwining、RH quantitative envelopeは証明しない。

## Abel height-shell system追加

D167--D176は、無限側closureへ進む前段を有限height shellから組み直す。
Mathlibのactual `riemannZetaZeros`をcompact closed ballで切って有限性を証明し、
その後にpositive-ordinate rectangleをfilterする。shell規約は一貫して
`(a,b]`とし、multiplicity付きatomic pairing、shell cocycle、anchor
telescopingを有限和としてexactに証明する。

tail側は無限和を仮定せず、zero-counting constant、kernel order、heightを
露出したdyadic shell budgetを定義し、有限partial tailのノルム評価までを
証明する。さらにcomparison scaleの正のlower envelope `b`から

```text
|tail| / B <= majorant / b
```

を導く。したがって必要なrateは絶対tail消滅ではなく、normalized master
ratioの消滅である。

修正版では、D167のactual zero cutからD168のordinate dataへのadapterを
追加し、multiplicityを`analyticOrderNatAt riemannZeta`で定義した。D170は
有限原子countに対するhalf-open Stieltjes identityをFTCから証明する。
D169は`n>0`, `sigma>=0`, `T>0`の下でactual Abel entrance kernelの
`|F| <= n^2/T^2`を証明し、D173はzero-count growthとglobal count domination
から係数2を含むdyadic shell boundを導出する。D175の固定epsilon命題は
pointwiseへ改名し、admissible scale型全体に一様なepsilon--N limitを追加した。

D177--D182ではcanonical radius `H+1` がcritical-strip rectangleを覆うこと、
異なるheight cutのrestriction compatibility、区間内だけの微分仮定による
atomic Stieltjes IBPを追加した。各dyadic shellを上端のcanonical cutから定義し、
kernelの非負性からreal absolute valueとcomplex normの評価へ接続した。
またexact dyadic budgetをsummable linear-log majorantの定数倍と同定し、
明示的zero-count growthを引数としてactual shell列の`Summable`、`HasSum`、
fixed-parameter Abel tailを構成した。uniform tail limitの定義には
scale positivityを内蔵した。

D183--D188では、異なるcanonical cut上のshell pairingを直接比較し、
dyadic partial sumが単一cut `(H, 2^m H]` とexactに一致することを証明した。
lower cut `(0,H]` を加えたsingle-cut列は`lower + tail`へ収束する。
さらにbase heightを`2^m H`へ変更した場合の同一性を、shell index shiftと
summable seriesの分割から証明した。これは任意の非dyadic base height間の
独立性を主張しない。

D189--D191では、`Re z = 1/2`、`Im z > 0`だけから
`Re (1 - 1/z)^n = cos(actualLiPhase n (Im z))`を導く純代数定理を追加した。
zeta零点性はこの定理の仮定ではない。RH下ではpositive-ordinate代表ごとの
complex Li conjugate-pair expressionとordinate Abel shellの有限和が一致する。

D192--D194では、positive cutとその共役像をdisjoint unionとして構成し、
共役写像の単射性、両側cutのmembership、有限和のimage再添字付け、
`u + conj u = 2 Re u`によるpositive-representative和へのexact圧縮を証明した。
さらにRH下ではconstructed paired cutの和をordinate cutへ同一化した。
この定理が必要とするzeta固有入力は共役によるanalytic multiplicity保存である。
別にMathlibのactual zero setからfull symmetric nonreal cutを具体定義し、
そのcutと構成したpaired cutとのFinset等号を正確な未証明gateとして隔離した。
旧D190の単なる虚部符号二分法をexhaustion targetと呼ぶ定義は削除した。

D193をさらに修正し、zeta zeroの共役保存、analytic orderの共役保存、
local order有限性を三つの独立gateへ分離した。actual symmetric cutとpaired cutの
Finset等号は、zero共役保存からcompact-ball被覆、虚部符号、`Finset.ext`を用いて
定理として導出し、独立仮定から除外した。D195--D196ではpositive ordinate sumが
D185のcanonical lower cutと一致することを証明し、RH・zero共役・order共役・
既存のzero-count growthの下でactual symmetric Li cut列が
`lowerCutPlusTailInfiniteObject`へ収束する定理を追加した。

D197--D199では、固定base `H0`とdyadic terminal `T=2^m H0`, `T>=1`に対し、
exact dyadic budgetを幾何級数として総和し、D188で同一のfixed-base infinite
objectへ戻したうえで、
既存のzero-count growthを明示的な引数に残したまま

```text
|infinite object(H0) - actual cut(T)|
  <= 4 C n^2 / T * (1 + log T + 2 log 2)
```

を証明した。最初のshellで`threshold <= 2*T`なら全dyadic shellでgrowth
thresholdを満たすことも証明した。real positive `tsum`がsummability下で
既存complex tailと一致することも追加した。さらにentrance kernelについて
`F <= min 4 (n^2/t^2)`を追加した。endpoint側はcomplex coordinate、norm
scale、uncancelled size、cancellation ratioを分離し、正のconditioning
thresholdに対するzero-size、exact cancellation、near cancellation、
nondegenerateの四分岐と
`tail/B = (tail/S)/chi`のexact factorizationを定理化した。

analytic multiplicityの正値性は、local analytic orderが有限なら従う形まで
証明した。zetaについてその有限性を閉じる解析補題、共役零点の存在と
analytic multiplicity一致、positive cutが全Li共役対を重複なく数える定理、
明示的Riemann--von Mangoldt定数、一般base-height independence、
comparison-scale lower bound、wall-route trace、quotient descent、RH closure
necessityは未証明である。これらをledger fieldとして仮定してはいない。

## 主要ファイル

- `MAIN.pdf`: 修正版PDF
- `LEAN/D160/ConcreteFiniteLiWitness.lean`: same-witness形式化
- `LEAN/D161/FinitePacketCesaroBound.lean`: full finite-packet評価
- `AUDIT/TRIAL18_FINITE_PACKET_CESARO_BOUND_AUDIT.md`: 修正監査
- `LEAN/D197/ExplicitPositiveTerminalTail.lean`: 条件付き明示tail rate
- `LEAN/D198/EndpointScaleConditioning.lean`: endpoint conditioning分解
- `AUDIT/ABEL_HEIGHT_SHELL_SYSTEM_AUDIT.md`: D167--D199の境界監査
- `AUDIT/FINAL_INTEGRATION_AUDIT.md`: ビルド・表示・静的検査
