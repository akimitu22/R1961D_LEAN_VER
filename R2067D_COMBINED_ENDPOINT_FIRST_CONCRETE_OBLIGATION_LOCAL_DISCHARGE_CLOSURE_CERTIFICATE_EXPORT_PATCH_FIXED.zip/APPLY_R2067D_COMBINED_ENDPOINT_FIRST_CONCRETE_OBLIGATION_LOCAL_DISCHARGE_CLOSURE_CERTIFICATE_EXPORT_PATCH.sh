#!/usr/bin/env bash
set -euo pipefail

# Files are already placed by unzip. This script only updates aggregate build files
# and records checksums for the newly added R2066D/R2067D layers.
# It is intentionally idempotent and safe to rerun after a failed earlier apply.

python3 - <<'PY'
from pathlib import Path

R2065 = 'R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution'
R2066 = 'R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure'
R2067 = 'R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport'

lake = Path('lakefile.lean')
text = lake.read_text()
text = text.replace('package «R2065DLeanEndpointFirstConcreteObligationWitnessCheckerExecution» where',
                    'package «R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport» where')
text = text.replace('package «R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure» where',
                    'package «R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport» where')

# Remove prior/default-target annotations globally; the patch then writes one clean default target.
lines = []
for line in text.splitlines():
    if line.strip() == '@[default_target]':
        continue
    if R2066 in line or R2067 in line:
        continue
    lines.append(line)
text = '\n'.join(lines).rstrip() + '\n'

# Ensure R2065 remains as a non-default library. If it somehow disappeared, add it.
if f'lean_lib {R2065} where' not in text:
    text += f"\nlean_lib {R2065} where\n  roots := #[`{R2065}]\n"

# Append the new two-layer target block exactly once, with R2067 as default target.
text += f"\nlean_lib {R2066} where\n  roots := #[`{R2066}]\n\n@[default_target]\nlean_lib {R2067} where\n  roots := #[`{R2067}]\n"
lake.write_text(text)

main = Path('Main.lean')
mt = main.read_text()
mlines = []
for line in mt.splitlines():
    if R2066 in line or R2067 in line:
        continue
    mlines.append(line)
mt = '\n'.join(mlines).rstrip()
block = f"""
import {R2066}
import {R2067}
#check {R2066}.endpoint_first_concrete_obligation_local_discharge_closure_to_actual_li_target
#check {R2066}.endpoint_first_concrete_obligation_local_discharge_closure_proves_kernel_conclusion
#check {R2066}.endpoint_first_concrete_obligation_local_discharge_closure_preserves_checker_execution
#check {R2067}.endpoint_first_concrete_obligation_discharge_certificate_export_to_actual_li_target
#check {R2067}.endpoint_first_concrete_obligation_discharge_certificate_exported_certificate
#check {R2067}.endpoint_first_concrete_obligation_discharge_certificate_exported_certificate_satisfies_obligation
#check {R2067}.endpoint_first_concrete_obligation_discharge_certificate_export_preserves_local_discharge_closure
"""
main.write_text(mt + block)
PY

sha256sum \
  R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure.lean \
  R2066DLeanEndpointFirstConcreteObligationLocalDischargeClosure/*.lean \
  R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport.lean \
  R2067DLeanEndpointFirstConcreteObligationDischargeCertificateExport/*.lean \
  R2066D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_LEDGER.md \
  R2067D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_DISCHARGE_CERTIFICATE_EXPORT_LEDGER.md \
  R2066D_ONE_HUNDRED_FIFTH_BEST_STEP.md \
  R2067D_ONE_HUNDRED_SIXTH_BEST_STEP.md \
  MANUSCRIPT_REFERENCE_R2066D_R2067D.md \
  VERIFY_STATUS_R2066D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE.md \
  VERIFY_STATUS_R2067D_ENDPOINT_FIRST_CONCRETE_OBLIGATION_DISCHARGE_CERTIFICATE_EXPORT.md \
  > SHA256SUMS_R2067D_COMBINED_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_CERTIFICATE_EXPORT.txt

bash -n APPLY_R2067D_COMBINED_ENDPOINT_FIRST_CONCRETE_OBLIGATION_LOCAL_DISCHARGE_CLOSURE_CERTIFICATE_EXPORT_PATCH.sh
