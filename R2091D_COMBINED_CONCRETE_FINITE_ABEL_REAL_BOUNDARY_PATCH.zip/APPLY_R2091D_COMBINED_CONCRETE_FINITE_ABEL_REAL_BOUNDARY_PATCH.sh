#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"
cd "$ROOT_DIR"

test -f lakefile.lean
test -f Main.lean
test -f lean-toolchain
test -f R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge.lean

grep -qx 'leanprover/lean4:v4.31.0' lean-toolchain
sha256sum -c SHA256SUMS_R2091D_COMBINED_CONCRETE_FINITE_ABEL_REAL_BOUNDARY.txt

grep -q 'R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge' lakefile.lean
grep -q 'import R2089DLeanEndpointFirstConcreteObligationAbelBoundarySourceDischarge' Main.lean

python3 - <<'PY'
from pathlib import Path
import re

lake = Path("lakefile.lean")
text = lake.read_text()
text, count = re.subn(
    r"package\s+[^\n]+\s+where",
    "package «R2091DLeanConcreteRealAbelBoundary» where",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("could not update package declaration in lakefile.lean")

dependency_marker = "require mathlib from git"
dependency_block = """

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "v4.31.0"
"""
if dependency_marker not in text:
    package_match = re.search(r"package\s+[^\n]+\s+where", text)
    if package_match is None:
        raise SystemExit("could not locate package declaration in lakefile.lean")
    text = text[:package_match.end()] + dependency_block + text[package_match.end():]

library_marker = "lean_lib R2090DLeanConcreteFiniteAbelSummation where"
library_block = """

@[default_target]
lean_lib R2090DLeanConcreteFiniteAbelSummation where
  roots := #[`R2090DLeanConcreteFiniteAbelSummation]

@[default_target]
lean_lib R2091DLeanConcreteRealAbelBoundary where
  roots := #[`R2091DLeanConcreteRealAbelBoundary]
"""
if library_marker not in text:
    text = text.rstrip() + library_block
lake.write_text(text)

main = Path("Main.lean")
text = main.read_text()
main_marker = "import R2090DLeanConcreteFiniteAbelSummation"
main_block = """

import R2090DLeanConcreteFiniteAbelSummation
import R2091DLeanConcreteRealAbelBoundary
#check R2090DLeanConcreteFiniteAbelSummation.partialSum
#check R2090DLeanConcreteFiniteAbelSummation.finite_abel_summation
#check R2091DLeanConcreteRealAbelBoundary.geometric_abel_kernel_mass
#check R2091DLeanConcreteRealAbelBoundary.finite_abel_transform_identity
#check R2091DLeanConcreteRealAbelBoundary.finite_abel_boundary_limit
#check R2091DLeanConcreteRealAbelBoundary.finite_abel_boundary_limit_below
#check R2091DLeanConcreteRealAbelBoundary.realAbelTransform
#check R2091DLeanConcreteRealAbelBoundary.real_abel_boundary_limit_of_partial_sums
#check R2091DLeanConcreteRealAbelBoundary.ConcreteRealAbelBoundaryWitness
#check R2091DLeanConcreteRealAbelBoundary.concreteRealAbelBoundaryWitness
"""
if main_marker not in text:
    text = text.rstrip() + main_block
main.write_text(text)
PY

echo "Applied R2090D/R2091D concrete finite Abel summation and real boundary patch."
